Solutions to JIF exercises as found on July 2009 on this URL:
http://www.cs.chalmers.se/Cs/Grundutb/Kurser/lbs/JifLab2006/JifExercises.htm

Copy of this page is in the "JifExercises.htm" and in the "JifExercises_files" 
folder are the supporting files.

In each directory "exercise01", "exercise02", etc is the final code for the 
respective exercise. Code from 09 to 12 is missing since it all "escalates" to
code in 13th one. Time restrictions did not help to re-write them.
Also there is no code for the last one(14th), again due to time restrictions.
If you complete them or rewrite them and need some feedback, please do not
hesitate to contact: dimitrismistriotis@gmail.com.

Thank you.
