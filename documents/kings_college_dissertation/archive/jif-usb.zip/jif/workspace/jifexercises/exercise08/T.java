public class T {
    int secret;
    int pbl;
    
    public void foo() {
        this.secret = 1;
        this.pbl = 0;
        int[] larr;
        larr = (new int[10]);
        int i = 0;
        for (; i < 10; i++) {
            try {
                larr[i] = i + 1;
            }
            catch (final ArrayIndexOutOfBoundsException iobExp) {  }
            catch (final NullPointerException npExp) {  }
        }
        int[] harr;
        harr = (new int[10]);
        int iAl = 0;
        for (; iAl < 10; iAl++) {
            try {
                harr[iAl] = iAl + 1;
            }
            catch (final ArrayIndexOutOfBoundsException iobExp) {  }
            catch (final NullPointerException npExp) {  }
        }
    }
    
    public T T$() {
        this.jif$init();
        {  }
        return this;
    }
    
    final public static String jlc$CompilerVersion$jif = "3.0.0";
    final public static long jlc$SourceLastModified$jif = 1248526173000L;
    final public static String jlc$ClassType$jif =
      ("H4sIAAAAAAAAAK0Ya3BU1fnsZvNezPsx5A3BQJENyGOYxmkNMUDIQnaSSDUU" +
       "tzd3zyYX7t57ufds\nsomtg0VN1L6cSls7leKjikg7WDs4QzuWVludMtopna" +
       "qMU8RiKTPVGaVaYUpn+p1z7nt30x/tj3v2\n3nO+9/vssQ9QoaGjlj1SMkJm" +
       "NGxEtknJmKAbOBFT5ZlR2IqLZ+479NhvNl56JYgKoqhUSJNJVZfI\nDEGV0T" +
       "3ClNCdJpLcHZUM0hNFlZJiEEEhkkBwYrOupgjqiGpAakJWSTfOkG5N0IVUN2" +
       "PWHeuTBcMA\ntCK2a+xDd6FARkftFoYpFJeIAXOR1jy+uv65L56oKkAVY6hC" +
       "UkaIQCSxT1UIsBhD4RROjWPd6E0k\ncGIMVSkYJ0awLgmyNAuAqjKGqg1pQh" +
       "FIWsfGMDZUeYoCVhtpDeuMp7UZRWFRBZ30tEhUnUsI8iYl\nLCesr8KkLEwY" +
       "BNU7mnL9NtN9UK9MAsH0pCBiCyW0V1ISBLX5MWwdOwcBAFCLUxjsbbMKKQJs" +
       "oGpu\neVlQJrpHiC4pEwBaqKaBC0GL8xIFoBJNEPcKEzhOUKMfLsaPAKqUGY" +
       "KiEFTnB2OUwEuLfV5y+Weo\nKPzvB2KftgeZzAksylT+YkBq9SEN4yTWsSJi" +
       "jnglHXl44PZ0cxAhAK7zAXOY3mUv3Bq99Ms2DtOU\nA2ZofA8WSVy8tqG55U" +
       "zve6UFVIwSTTUk6nyP5ix4Y+ZJT0aDbKi3KdLDiHV4avi3t+8/iv8eREUD\n" +
       "qEhU5XRKGUClWEn0me/F8B6VFDyAQjL8gOZJScZU8yJ41wQyyd4zGkKoGJ7r" +
       "4CmgD0GFoxHIQXpc\nnaFrxXQgAKI0+xNBhhjaqsoJrMfFpy/87sv9g/fPB+" +
       "3AMMkTFBhFgQCj0OBVhlonQXP1/Z/2VH5j\nlXECknoMlUqpVJoI4zLIHBZk" +
       "WZ3GiThh3q9yRZqVreFxCBSIubgMhHjOamhKR0v8AeEkzgArCyK+\nc8MOdL" +
       "C1//vUd9TWtZQ6Fw0st5fLFl4xsnvbl+aXFFCg6RBYiGqyxFOkctCOizO/qv" +
       "vsyVNXfx5E\nhWNQioxbcFJIyyTWt0lNK5DftfbWMIbUV6LCOJajqJxnuABZ" +
       "auVZsSYyHIIaosDXjHyZwnczLDBD\nue4QoWitEI2d/90EcTFWU7fjR/9sep" +
       "YHsN9qMV0VcQIKk4MQX722Y8fhG6+CXpCbIC0BWWmqt/pz\n05NOPWbuEbQk" +
       "K9X9THqsMkY1CYFySVVPCTIlY9mkjEzq6rSzwwJ1EV2qeMzSZSl1qk8jVgb/" +
       "MTC3\n9eLp5buD7opZ4eogI5jw/KtyYmJUxxj2//y92LcPfjC3iwWEGREEmk" +
       "Z6XJbEDJOmPgABWJOjFkQa\nax/+zoofvGlFXI1DvVfXhRkacJm7z7Q88orw" +
       "KNQJyF1DmsUsRxHjhCwGdL2Bva9yHUKWOfydEO01\nDHAQlI2bGub/8vuW10" +
       "c5fz82CNTkILH4gm4n6Syo4uKp2gMH779WsSWIgmB/cHwS2rIkQu9tzgrL\n" +
       "PvuUxibtOBMWcEsW8IBzTEt5g18Gk3/NjvC1fzX98RbGvzyBDVGXNKqVWdSK" +
       "iLoNzEkbGeOgC4oh\nQ+vnOTLKDvszmt7jjhXqhaWMoQXuqOygxMX1+y99/P" +
       "yfTnTxNGnzYmRBd/yk5cPOY3css/zc6ldp\nGAtQNrnOQLzzwjMf3VvyFNOs" +
       "UJ1m6dTmspMGXVWUNAG6g/VGBxWdUaGKfB6EaszynUm+53BaUFuu\nilQal+" +
       "reMmaziIyqms0lLm5999fv3PvdxtNuxX0ILug1dY2N7ZdxGUss2yFLfQ6xEf" +
       "I4BSS73mth\nt0xuQ7919+JzK2/45qtcOr8jc2E88eynT852PTXhpMAmkyn9" +
       "2ZzLWV+ACdNx1j2fmX/745+tbXY5\ni3kA9J1mgNwfdL3ZVmdZLrttUglRUy" +
       "7r3fjq6obeI9ufsxzVZ+Ov8Grmw3Trtyb8+It/PfrMYYvG\nFqbXdpeOQ2xd" +
       "r5nq97D1cxo/3K65gbxfg+bXJs0ylufLLE20+fpHhc10QrWqe2r8zk9eOlTW" +
       "7nig\niRWgIJ0xPH3VgxYXg0fOz61orDgLlh9D100KxoACwxCdo7EOrpDdvc" +
       "8/2vlIzb5466Err5FzLE6d\nJkaxOzLZ8u8UXB1z4xtTVUXHf5gKomJo7Kxd" +
       "wyVjpyCnaXsYgwHb6DM3o2iR59w7LPPJ0GmMzf7G\n6GLrb4nOiAXvFJq+l/" +
       "IkYjCVtC/BUwsPtW6IzXN8qAsgjb5MMsBOtnZpZhOAVmZgEaYJw1OJWYnD\n" +
       "CT70/qF87Xz7+mQtS4FSZne4FbHpqxVmW4phfXORwh6RwjlE4jFpg4XygPlD" +
       "VkdduTKrPwN5qAiy\nK7eEdUerfvGV18/6B1SWZ4zSSm+OZdFwZ9mjDer5/U" +
       "8XD9lZBlNzL9QHnCNBBumyL+Pk4T5Pinl2\nsgMX2KcgyqfMO8lDrU9efP7C" +
       "cG3QdXFbmj1QuXD45Y27genZsRAHBv3yyo5jdw2fG+dVtdo7tfcr\n6dTfZl" +
       "7CXTd9/d0c034BNHs2gCG6cn+JHveXw1NIn+yInKPLHiCijcsMJ+XBLMqB+b" +
       "8WszwwdPmq\no8fXmP2uNyucM3w1OaNTS74bKDPp3G0fhe8TXt5tBcw9BJUS" +
       "VVsl4yksO4XTT2Q7u3BbReCxoupE\nKLqx0V85A1l/m3jx4uLpsxUf9q87ff" +
       "H/dxkxkz3XvaNtQSXiInkhfvnNDWeXs/LhLmRlnNiop5y1\n2yFQAo/1W+IK" +
       "AXvef8LlpDwT8oKHEHhJVWXb+81AOEBQaEqVEijgwlybm6xTvuhTn0NST5DS" +
       "5bir\nLBzPKguenUGbehU8dTmoc0QPWHU+sCEfcO1CNFk2jGToVV7jKtQQVM" +
       "nuLrSRRXgjc/X/lgXHxEd2\nPaQpq3ulvLeQBm8sp/lfc3Hxfe2OLW8Pv3PU" +
       "nPbsMMMZEmF/2lkBZ2Pc9uNd7ZkHR7/FhzVRFmZn\nKb9iiGN+p7T/5uvIS8" +
       "2iJZ1/I/nAgfcqfGM0iz5H9db8dOj7zkU9bw2ePHnEn8LIZT2X+gzHypx1\n" +
       "yz8pvvLa5Ztz2+0/56nGqD8VAAA=");
    
    public T() { super(); }
    
    public void jif$invokeDefConstructor() { this.T$(); }
    
    private void jif$init() {  }
    
    final public static String jlc$CompilerVersion$jl = "2.0.0";
    final public static long jlc$SourceLastModified$jl = 1248526173000L;
    final public static String jlc$ClassType$jl =
      ("H4sIAAAAAAAAAKVYaazk2FWu7ullpqaTmZ5MJpNkls6kQ2Yope3aXZmwlF2u" +
       "Kpe3WmyXy2H08F7e\nXd7K9oQIhJQJRGwigwBBWARCgvlBQEr+AVIikFj+5A" +
       "cRPwigRAEJ8gNQIEhAuK73Xr/Xr3smQnmS\nXff5nnvuWb5z7j3njW/UrsZR" +
       "7VYYuIXpBsmdpAj1+M5cjmJdw1w5jjnw4Uht/ib81Gd/6HM3H6o9\nJtUes/" +
       "xVIieWigV+oueJVLvh6Z6iR/FQ03RNqt30dV1b6ZElu1YJCANfqj0RW6YvJ2" +
       "mkx0s9Dtys\nInwiTkM9Oux5+pGq3VADP06iVE2CKE5qj1O2nMlQmlguRFlx" +
       "8jJVu2ZYuqvFu9rHa5eo2lXDlU1A\n+BR1qgV04AiNq++AvG4BMSNDVvXTJV" +
       "ccy9eS2vMXV9zV+DYJCMDS656ebIO7W13xZfCh9sSxSK7s\nm9AqiSzfBKRX" +
       "gxTsktTe86ZMAdHDoaw6sqkfJbWnL9LNj6cA1SMHs1RLkto7L5IdOOVR7T0X" +
       "fHbO\nW+y1G//zk/P/vHX5ILOmq24l/1Ww6LkLi5a6oUe6r+rHC7+V3vk0sU" +
       "mfuVyrAeJ3XiA+phl+4PM8\n9U9//PwxzXsfQMMqtq4mR+p/95559kvDrz3y" +
       "UCXGw2EQWxUU7tH84NX5yczLeQiw+NRdjtXkndPJ\nP1n+6eZHf1f/58u1a0" +
       "Ttmhq4qecTtUd0X8NOxtfBmLJ8nahdccEP0NywXL3S/AoYh3KyPYzzsFar\n" +
       "XQfP28HzUPUktavcHdsyqunH8+r9tv2lS0CUZy6GhQswNA1cTY+O1N/56p9/" +
       "DCd/4pOX7wLjhH1S\nu8TVLl06cHjXvcpU1tEqEP/LH7z8+E9/KP7c5dpDUu" +
       "0Ry/PSRFZcIPMN2XWDva4dJQfv3zyHtIOD\nATpuKAAoAHNHLmB0ACZQKYtq" +
       "L1wExFkYEWAkAy+/2mNqrz+H/3Llu8rWT1bcj0UDlnOOZbvx0uqV\n2Q9/8o" +
       "WHKqL9FWChSpPb35n7kTp/xzuZ3/6P9/7eMTYuCjSPAlXXQAY4W3AEt9/H/H" +
       "rrvy7XrgLY\ng8BPZOA6EEXPXYT9PUh9+QTWSe2F+6Lo4iYvn2aIylSXqdqj" +
       "RhB5sluxOQ3rerKNgv3ZlwMGHj2M\n3/7t47//PXm+DaIfC7wQICu6NdGBrH" +
       "Kia+ExaqrX85VZLyh+SET/Trw2/fpfvPjK5fM567FzyW2l\nJ8cRcPPMK1yk" +
       "6+D73/7i/Odf/8ZrHz245MQnSe1amCqupeYHQZ+8BCDwjgdE452nn/z0L7z0" +
       "K18+\n9fk7zrgPo0guKpfnP/alZ3/pz+RfBZEKoie2Sv0QJbXDTrXTDar39x" +
       "7GjXOTJ7MVAi/Gy7hK06d+\n8JRXv/mFz9RvHctRrXn3gUN1/lxMS/csPFLL" +
       "P+I/862/Sr5yMN0ZSioez+b3byvI5yCJ/HV289rv\n/5p3uXZdqj1+OFpkPx" +
       "FkN60MK4HDIcZOPlK1t90zf2+iP85qZ8h75iLyzm17EXNn6QGMK+pqfP08\n" +
       "zCqPgudJ8FRGuXLIRccJ6VItrAb9A+ELh/cHwhPjAxDEuhrpyQOMOI8sD6TO" +
       "7CS3/9xzv/X1P/zq\n8snL5w7A998fPefWHB+CBynrYQ52eN9b7XCg/mLjfW" +
       "98fPkV5TgBPHFv9sP91PvH4gv6Bz/yU//w\ngKz5EDimD2F0ULF9j10erYBS" +
       "PffbBateA7A8VA7H3Pef41G9buWXQKxcbd+B78DV/+P77VidAIbl\ny4f1H6" +
       "xserjeAOu+y3bV26fxLoAbDjiJboOj4rD6JricHIKpwsed44vAAzYHhnv7GR" +
       "kVgNvCp772\ns3/5M+//O2CEWe1qVmENWOscLyatrlOfeOP1Zx/99N9/6hAx" +
       "wA4vfPabPz6tuLLVawquGpV0qyCN\nVJ2S44QONAvcjLS7An4kPA7OH0jAkR" +
       "g8ULjkxu1pJyaGp38kvJHbKN80/FjKGL2cx3l32EYXM5wp\nJuwm9xyG5kfE" +
       "wpdXqxHPJ6XWLouN2E+6/dTQ4noceIkJC0yT6qkrN+67Omlbjtlfj+LOokzX" +
       "gptq\ndBKEvryjeWRpkdxcmMiCvOFDvxE2y76ftOEcSux21qq3fbYxgLI4Xg" +
       "wWgTyxXbu5op2Zx0xyPHH8\nmUcOFRYdc13JXbaIHSU1Ov0Bs80Yt9ubbUwy" +
       "2G351YyZCZJB1Ef4RIC5NuYymDYLKXUq8TS8Zcau\nNLNwHN86DrrfRGwamv" +
       "bOmoRD2ZmtV5zBOpMuAxMCz7Tm66mecqhKD+sJRrbkRj7SeuPh0jGScbAJ\n" +
       "xzOdGIrssmkXjTTrdaluLyCdobDpbTHekYkFtsq5Jk/E6HbUWS5Zez3Xejjs" +
       "1NUJQQsrZzOD5T1l\negUzTIc7m5zszGa42I6JdWxM6JHE65sAE7ZJONJTOu" +
       "zz0nI9XqJSG07wLe/zMYFYG7dOYXocIaRD\n4fsNyvB9z6cGTMIMeHJAD+Mp" +
       "HGKohRVrWGgSK5QSu/R6r7F7FR2OMYrP7VhRaJJczOJgEqZ1XXAX\nsyicWl" +
       "gnxPeovCNlFIMnFJIT4wCdMfhcJfFyy/IkbVCxPB+SO36yIS18zPloi+X3eE" +
       "oZQrdorPWg\nTs7LDG2RRmLqUjl04sLlGhsH3Q1WONMpuHW8mlm2b7pT0e10" +
       "5hKs5sPtkOyXwKabtsdnbUA6oOPW\nKGH5+rAlBcYQWa+EAkl2k26XLzO9x4" +
       "8FYr/iON7p+cW8a+WdTUOacbA8UkirTWrUyJoKHTmz2kkD\ngawM0Zc4P6rv" +
       "gAG74pKc8Ji7xn3Y06ExgvaE8agYLmwKMVlptlIlHilmneZ+URRap5w4ZDCZ" +
       "9aMO\n5pkjeDIO8imxEEO17svjKBcX5pAk4EbOoNutLe/iYBbRxjgsIKQfZw" +
       "MTMuZooz2kaYcbo9uxucBs\nmEWFLYjShThvQhLUEqZdu+6KOOb4Ae3yu1CY" +
       "BUSnpIgpKjlrqT2xuO22vRsUS2knRPo4x9AVkSom\nvZ3arOxtySWcIUMdd0" +
       "pzGGEF2airCM1qFNaEoIzXBtw6kRa98R6Ok65Bjd1OHvuZ4jZkcTzGzN4S\n" +
       "3ViTXZGPWUdNMNYqWWiXZXEhMKKRd/H6ds0srCBX1PGMKID3EthlyO7ISAxl" +
       "TRMKL/QojJ3J9m6W\n++kQleRUkOLVppgShBzEI9GeFtLeV0tqhI7qqd5ZBG" +
       "srwYmWBg1gXOXGa75v2EtoEOvhZhozgx0t\nwIK6IEinQy/Efqu1QYztpNfA" +
       "xBBTCAxG12tvl0BhWYe7DDtfKymuLBxyIA646S6mnU0T24yLlSDM\nMY5wNw" +
       "PPsfFy14tW5X4/a+JCa6fT5Upauc2dg9iCqUA0h7XrA50Ku0o66geh1NEDk+" +
       "jae4hMio03\n4/PcbkFQMWhR6tywsba1X+OTJY57jtQTZwo+mrHe3Byi6xlr" +
       "j52FXJdzqFEGgZFN3LFINEeZYIjb\npSOrM69f9hcIEkR7klnMinFz5MV8vM" +
       "yn9hbbTzSqhWbyoJjy5Jo1Cg1n4WZ9NB0uXKKlTFIFQrJ0\n3YTVrlEiLYzh" +
       "HIKadkyv4/dWRdBJybBl0tN+fwBCbE2YHgqp0/2qFRHOIh0kpRlR9XmW8rml" +
       "JCxK\nr1U8XiMEWnJ40jWbyMRpQ4ydYU2jFAfIUplkZYGOhInIkDthra1Iiw" +
       "qYEneUic6aWCfY1heNzGc5\nihxlceklfdveirutvKaDhZju2MLMabHZKAYD" +
       "aF4YnM/lzMQvN94S1aDC6apzEO1qHEOl2nO1sD4Z\nJgsm8tkFVZZ7mzbaQl" +
       "aMGTbmZ02vp3FeHNITUVjzzHDSMyFhguZrjZcnpIH2cDkuC5/3Gt02KvPj\n" +
       "NK1b7kJ2G5FOe3JpEcXOi2GX8rqDwcDI2vNMyxMmzUWYoFKzqW1aTF/S8gkf" +
       "x61iTBmLXo4bRAdd\nrfptL9nWEzhPF/1Bc9CYlWQL6nR3icpGiK22cATRC5" +
       "9Duq05J25Deug5hT9oSSW1FhpDTGPypt0y\nPBHqd7qNRBE33brVdoYDoJLJ" +
       "7A2NakuCp0lUlCS86S75oh+1DXvXCxSdGKRGnJeC1GAzZBJ5+zYX\nJYWCNI" +
       "gEmhsRvdlkk/p4p4gaqMMXrVyLuv5u0B811TyA2mSvayq5YTYUcRbDhZsaFI" +
       "W34IYRTrdq\nE15E653eipDSGeisy637vmXWreXaJGZwPp+2BTPfiCZssGWv" +
       "GUQjk3K3g1EThsk8GGL7HNOCPs5G\n4UjLVARqZS5RKt1Or4dHUXdcUnhPq8" +
       "8cOWdLSkJShBfRZtnJE07gxanRBae1Nwv6ZK7tC8EOC8yX\nxXhj7qdKb0S3" +
       "g5a17A72fWo+n8ETjy6N/qTem1CR0vFZayhm49mu4UKEs7ExIcEglN/H82Td" +
       "I0qR\nQXbD2LSVLk3HKJv4Uiht2aHgSSYub2b7Jjtbb/xRHeP6MLQbI32x7D" +
       "e8RbLqjFeSr3fGyjTc5YK3\n7oRbA5zu+21vubddvGOPQ7MjFubcHQmOpqUc" +
       "Gc33THc3tIo62ddxjdcjEOlCE4F6aHO1ljrlauU1\nWEkb76WBZ4/0qAvxiD" +
       "gauBLqMiU1WEx9jEHR1CuoxtzpcN255butemzSYotUzWJn0CzijiJ+oBvz\n" +
       "PqZO2gtNHCue3Vyk4qjT3bT6pu5L8XI4RbN2UQRdW9u3jElDExLgmsRQozoI" +
       "GUNy+5jIaQNIg1W4\n3UGZadwysUlP9RuzaaaL+yZD+I2C8Mk5BY5+y1Zjet" +
       "YQUYreoQ0FWccgZWpzb1cPEEP05q2UKVKV\nbgNTygy36ncUcjQP2xPY2OoI" +
       "JybdBFX3A3TGg+Qbu53CidmOyHGtRT9to8pSx/IgDfE6Se1yWEC6\nw6YLeW" +
       "0776RUGOe8MdghfcOYQlru5E7ZFjOZSRYr0SJ8Z2tkPjNa62IMUVvKW7o+Yw" +
       "Vht2jWQcAu\nhgHUXDcIEqBDNxDKDUd7DgnIKT7dzoS1qDSQ5pDF0YWM7wTc" +
       "ss29WyheL+eydMv5MLPiuqNVV7Gi\nOoWWc9JMdZ+fKPqWR0DWCVR4Aa6DfC" +
       "PGcENlmxgzdlr2hAsEoW+TyWIh0H5KRavlUjRtFRIh1xSn\nOa616nN5Ee7a" +
       "qZtR+gL1kDiEXENtT3NDb7HUGpmDPMT7cyWmaVrCvTHUch1Uas3VQcpofcmZ" +
       "LvvQ\neFsKy7En+XVSGVjWhGmEfQ7qphmxQlrWTGpCBOQPTUPdgXsjbJXd6U" +
       "BTEI21+6XDD5R9S59PfdxH\nKELiWmLDLKdFmDfrRYmEWUbJXSkpWw0Y6vb8" +
       "yW6ECKAq+L6qXFifVB03DzXR3U7pSeOMPhQXh2Lx\n9klH4Kxf8O7TRkJUe/" +
       "bN2paH+vE18V9vfEL+4itVyVMt/MGk9gioFj7k6pnunjUaLjKhD13a0+r7\n" +
       "N649oV2hkKcvdhqugO2ff8uVR2ry+aN/+3Lvb168fLFsr4MiO4187p7i/Zm7" +
       "RerD4Hn85Pfhc0Xq\n3b6Qds4yb9JJectJUOAaQXBfWZcF1nF3Wq1ej53t53" +
       "/X+13mbp8VjOpdTavW6feclOWgsI4PDhzp\nqssFM1DA4nlypN6pStlbL6qn" +
       "jTLztFH20ofb/c6Hb+1SObZ2aZDoLx73sG5VetwCULpt+Vng6CPd\nONdgfP" +
       "GlW68mWyu+w91+8aWXf+Slc+225LtW8+k327UidS4oX7n35pnyR/9P5Zvt9r" +
       "3KR1YGZs5r\nbyWVtrc++srq1j2Kfuz+tgUQ4PoJh7dW8jtY4OHTnQ8a51X/" +
       "Ogwf0OE47oDl/wcxVZ73NBoAAA==");
}
