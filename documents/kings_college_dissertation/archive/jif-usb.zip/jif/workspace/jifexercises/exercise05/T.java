public class T {
    int secret;
    int pbl;
    
    public void foo() {
        int x = this.pbl;
        int y = this.secret;
    }
    
    public T T$() {
        this.jif$init();
        {  }
        return this;
    }
    
    final public static String jlc$CompilerVersion$jif = "3.0.0";
    final public static long jlc$SourceLastModified$jif = 1248377301000L;
    final public static String jlc$ClassType$jif =
      ("H4sIAAAAAAAAAK0Ya3BU1flk81iSLOZNMuQNwUCRBOQxTOO0hhggZEN2kkg1" +
       "FLcnd88mF+7ee7n3\nbLKJrYNFTbQPdSpt7VSKShWRdmrt4AztWFptdcpop3" +
       "SqMk4Ri6XMVGeUaoUpnel3zrnv3dAf7Y97\n9t5zvvf77LEPUKFpoMbdcrKD" +
       "TuvE7NgmJ2PYMEkipinTI7AVl07fd/Dx32y8+EoI5UdRMU7TCc2Q\n6TRF5d" +
       "HdeBJ3pqmsdEZlk3ZFUbmsmhSrVMaUJDYbWoqi1qgOpMYVjXaSDO3UsYFTnZ" +
       "xZZ6xHwaYJ\naEV819yL7kJ5GQO12BiWUEIiDixEWvPE6kXPffF4RT4qG0Vl" +
       "sjpMMZWlHk2lwGIURVIkNUYMszuR\nIIlRVKESkhgmhowVeQYANXUUVZryuI" +
       "pp2iDmEDE1ZZIBVpppnRicp70ZRRFJA52MtEQ1Q0gI8iZl\noiTsr8KkgsdN" +
       "iha5mgr9NrN9UK9EBsGMJJaIjVKwR1YTFDUHMRwd2/oBAFDDKQL2dlgVqBg2" +
       "UKWw\nvILV8c5hasjqOIAWamngQtHieYkC0AIdS3vwOIlTVBeEi4kjgCrmhm" +
       "AoFNUEwTgl8NLigJc8/hks\nivz7gdinLSEuc4JICpM/DEhNAaQhkiQGUSUi" +
       "EC+nOx7puz3dEEIIgGsCwAKme9kLt0Yv/rJZwNTn\ngBkc200kGpeubmhoPN" +
       "39XnE+E2OBrpkyc75Pcx68MeukK6NDNixyKLLDDvvw5NBvb993lPw9hIr6\n" +
       "UJGkKemU2oeKiZrosd7D8B6VVdKHChT4Ac2TskKY5kXwrmM6wd8zOkIoDM91" +
       "8BSxh6LCkQ7IQXZc\nmWFr2VReHojSEEwEBWJoq6YkiBGXnj7/uy/39t8/F3" +
       "ICwyJPUd4IysvjFGr9yjDrJFiuvv/TrvJv\nrjKPQ1KPomI5lUpTPKaAzBGs" +
       "KNoUScQp936FJ9LsbI2MQaBAzMUVICRyVkeTBloSDAg3cfp4WZDI\nnRu2ow" +
       "NNvd9jvmO2rmbUhWhguT1CtsiK4V3bvjS3JJ8BTRWAhZgmS3xFKgftuDT9q5" +
       "rPnjh55ech\nVDgKpci8hSRxWqGxnk1aWoX8rna2hgikvhrFY0SJolKR4Riy" +
       "1M6zsC5xHIpqo8DXinyFwXdyLDBD\nqeESYWhNEI1t/90EcSlWVbP9h/+sf1" +
       "YEcNBqMUOTSAIKk4sQX722dfuhG6+AXpCbIC0FWVmqNwVz\n05dOXVbuUbQk" +
       "K9WDTLrsMsY0KQDlkpqRwgojY9ukhE4Y2pS7wwN1IVsqRMyyZSlzakAjXgb/" +
       "0Te7\n9cKp5btC3opZ5ukgw4SK/KtwY2LEIAT2//zd2LcOfDC7kweEFREUmk" +
       "Z6TJGlDJdmUR4EYFWOWtBR\nV/3It1d8/0074qpc6t2GgadZwGXuPt346Cv4" +
       "MagTkLumPEN4jiLOCdkM2HoDf1/lOYQsc/m7Idpt\nmuAgKBs31c795feNr4" +
       "8I/kFsEKjeReLxBd1ONnhQxaWT1fsP3H+1bEsIhcD+4PgktGVZgt7bkBWW\n" +
       "Pc4pi03WccZt4MYs4D73mJXy2qAMFv+q7ZGr/6r/4y2cf2mCmJIh60wrq6gV" +
       "UW0bmJM1Ms7BwKqp\nQOsXOTLCD3szutHljRXmhaWcoQ3uquyixKX1+y5+/P" +
       "yfjreLNGn2Y2RBt/648cO2Y3css/3cFFRp\niGAom0JnIN52/pmP7l3wFNes" +
       "UJvi6dTssZMOXVWSdQzdwX5jg4rBqTBFPg9C1WX5ziLfdSiNtcYr\nEpPGo7" +
       "q/jDksOkY03eESl7a+++t37v1O3Smv4gEED/Samrq6lkukhCeW45ClAYc4CP" +
       "M4BSS73m9h\nr0xeQ7919+KzK2948FUhXdCRuTCefPbTwzPtT427KbDJYsp+" +
       "Nudy1hdgwnSddc9n5t7++GdrGzzO\n4h4Afac4oPAHW2921FmWy26bNEq1lM" +
       "d6N766urb7yMBztqN6HPwVfs0CmF791kSeePGvR585ZNPY\nwvUa8Og4yNf1" +
       "uqV+F18/p4vDAd0L5P/qt7426baxfF9WaWLNNzgqbGYTql3dU2N3fvLSwZIW" +
       "1wP1\nvACF2Izh66s+tLgUOnJudkVd2Rmw/Ci6bgKbfSoMQ2yOJga4QvH2vu" +
       "BoFyA18+KtBy+/Rs/yOHWb\nGMNuzWTLvwN7OubGNyYrin7yg1QIhaGx83YN" +
       "l4wdWEmz9jAKA7bZY21G0ULfuX9YFpOh2xgbgo3R\nwzbYEt0RC94ZNHsvFk" +
       "nEYcpZX4Kn2prvwnyeE0NdHtLZywQHbONru241AWhlJpFgmjB9lZiXOJIQ\n" +
       "Q+8fStfOtaxPVvMUKOZ2h1sRn76aYLZlGPa3ECniEymSQyQRkw5YwTxgwZA1" +
       "UHuuzOrNQB6qWPHk\nFl53tOIXX3n9THBA5XnGKa3051gWDW+WPVarndv3dH" +
       "jQyTKYmruhPpAcCdLPlr0ZNw/3+lLMt5Md\nuMA+BVE+ad1JHm46fOH580PV" +
       "Ic/FbWn2QOXBEZc34QauZ+u1OHDol1e2Hrtr6OyYqKqV/qm9V02n\n/jb9Em" +
       "m/6Rvv5pj286HZ8wEMsVX4S/K5vxSeBezJjshZtuwGIvqYwnFSPsyiHJj/az" +
       "GbB4YtX3X1\n+Dq33/VWhXOHr3p3dGqc7wbKTTp720eR+/DLu+yAuYeiYqrp" +
       "qxQySRS3cAaJDPALt10EHi+qTBRE\nN9YFK2de1t8mfry4dOpM2Ye9605d+P" +
       "9dRqxkz3XvaL6mEnGJvhC/9OaGM8t5+fAWshJBbMRXzlqc\nEGCuZ78l7PGE" +
       "gDPvP+lx0jwT8jUPIfCSmsa391mBsJ+igklNTjiTNVvX5ia7ni2H/ZEottw5" +
       "47Cv\ndWbt9Ht2Bjzvg9k7bBnOsOu1LjhWUVTO7xOsuXSI5uLpyY3XHN0e3f" +
       "mwrq7ulue9GdT64yst/i6L\nS+/rd2x5e+ido9YE5rieZGgH/yPNDgIH47Yf" +
       "7WzJfG3kITFASQqemWH8whBb4p7n/PXWOi81m5Z8\n7o3kA/vfKwuMtjwiXN" +
       "Wb5qfD3ncs7Hqr/8SJI8G0Qh7redTnOHY0r1v+Sfjya5duzm23/wDrCm8R\n" +
       "0xQAAA==");
    
    public T() { super(); }
    
    public void jif$invokeDefConstructor() { this.T$(); }
    
    private void jif$init() {  }
    
    final public static String jlc$CompilerVersion$jl = "2.0.0";
    final public static long jlc$SourceLastModified$jl = 1248377301000L;
    final public static String jlc$ClassType$jl =
      ("H4sIAAAAAAAAAKU4Wawj2VXufcbTyXTPlkkyy5tJh3Rjpcu12GVnEsBL2S5X" +
       "uapcVXa5Kowetbmq\nXKtrtT0hgp9MIGITMwgQhEUgBMwHi5T8AVIikFh+8k" +
       "HEBwGUKESCfAACggSEW37v9Xv9umciFEv3\nvvvqnnPu2e89561vVq4kceUg" +
       "Cr2t5YXp3XQbmcldTo0T0+h5apKI4MOhDv96/Znf/8HP3bxUeVyp\nPO4EQq" +
       "qmjt4Lg9TcpErlum/6mhknHcMwDaVyMzBNQzBjR/WcHQAMA6XyROJYgZpmsZ" +
       "nwZhJ6eQn4\nRJJFZrw/8+QjXbmuh0GSxpmehnGSVm7QKzVXoSx1PIh2kvQV" +
       "unJ16Ziekawrn6xcoCtXlp5qAcBn\n6BMpoD1FaFB+B+BVB7AZL1XdPEG57D" +
       "qBkVZePI9xT+JbFAAAqNd8M7XDe0ddDlTwofLEEUueGliQ\nkMZOYAHQK2EG" +
       "Tkkr73tbogDokUjVXdUyD9PKs+fhuKMtAPXoXi0lSlp5+jzYntImrrzvnM3O" +
       "WIu9\nev1/fpz7z4OLe54NU/dK/q8ApBfOIfHm0ozNQDePEL+V3X2DlLPnLl" +
       "YqAPjpc8BHMJ0Pfn5Gf+OP\nXzyCef9DYFhtZerpof7fzeee/1Lna49eKtl4" +
       "JAoTp3SF+yTfW5U73nllEwFffOYexXLz7snmn/B/\nKv/I75j/dLFylaxc1U" +
       "Mv8wOy8qgZGL3j9TWwpp3AJCuXPfAHSL50PLOU/DJYR2pq79ebqFKpXAPj\n" +
       "3WBcLUdauSLeXTnLcvvGppzfVVy4AFh57nxYeMCHRqFnmPGh/ltf/fNPENSP" +
       "ffriPcc4Jp9WLoiV\nCxf2FN5zvzCldozSif/5D1658ZMfTj53sXJJqTzq+H" +
       "6WqpoHeL6uel5YmMZhurf+zTOetjcw8I7r\nGnAU4HOHHiC0d0wgUh5XXj7v" +
       "EKdhRIKVCqz8WpOpvPkC8Yul7UpdP1VSP2INaM494u36HeHV8Q99\n+uVLJV" +
       "BxGWiolOTWd6Z+qHNPPs385n+8/3ePfOM8Q1wc6qYBMsApwmEdfYn5VeS/Ll" +
       "auALcHgZ+q\nwHQgil447/b3eeorx26dVl5+IIrOH/LKSYYoVXWRrjy2DGNf" +
       "9UoyJ2FdTe04LE6/7H3gsf363d8+\n+v3v8fg2iP5e6EfAs+KDoQl4VVPTiI" +
       "68ppxeLNV6TvB9Ivo38vXR1//i9qsXz+asx88kN8FMjyLg\n5qlVxNg0wfe/" +
       "/XnuZ9/85usf35vk2CZp5WqUaZ6jb/aMPnUBuMCTD4nGu88+9cbP3fmlL5/Y" +
       "/MlT\n6p04VrelyTc/+qXnf+HP1F8GkQqiJ3F25j5KKvuTKicHlPP37te1M5" +
       "vHu6UHno+XQZmmT+zga6/9\n+xc+Wz044qPEee+eQnn/nE9L9yEe6rs/mn32" +
       "W3+VfmWvulMvKWk8v3nw2Ll6xiVbf53fvPp7v+Jf\nrFxTKjf2V4sapHPVy0" +
       "rFKuBySHrHH+nKu+7bvz/RH2W1U8977rznnTn2vM+dpgewLqHL9bWzblZa\n" +
       "FIynjnPTtX0uOkpIFypRucD3gC/v5w9Gx8oHTpCYemymD1EiFzs+SJ35cW7/" +
       "mRd+4+t/+FX+qYtn\nLsAPPBg9Z3COLsE9l9VoA0546Z1O2EN/sfbSW5/kv6" +
       "IdJYAn7s9+RJD5/7j9gvmhj/7EPzwka14C\n1/Q+jPYiovfp5TEwHinHg3rp" +
       "lVMboEfa/pr7vjM0yulgcwHEyhX0bv1uvfx/8KAeL4H9pROoe/wP\nlTrdP2" +
       "+Adt+z8vRbJ/E+By8ccBPdAlfFHvsmeJzsg6n0j7tHD4GHHA4U9+5TMDoEr4" +
       "XPfO2n//Kn\nPvB3QAnjypW89DWgrTO0mKx8Tn3qrTeff+yNv//MPmKAHl7+" +
       "7ae/sVcAW04j8NQouRPCLNZNWk3S\nSWg44GVk3GPwo9FRcH5/Cq7E8KHMpd" +
       "dvjLCE7Jz8qLqsot0ZvPTcFuwINKswk2zKFLMe32WnG5Fl\n67ZtWQrBIK5r" +
       "wQNaD4xWyx/UcNPEA7Sq0dQ4lpmBqE05Q4hSfC5Qgi3xhh+nWGeXSoMoNfQo" +
       "jFBh\nPXEx3mkuJvOhOVPDWRSYHrqLgxw1OktcbuPVdtrY5fkSx2mCm1GDKJ" +
       "xohh5TfTHLCZyx/DHCyRPC\ndSInEEm8M/fq+NKA+hsU2bZqREg2ZgY/meFi" +
       "T0em1abIDxrGyDC7YzRa+4lBKJ6LKoOZ5ie+LcTz\niTob92VNCtcOvLbYaC" +
       "LPVwtV6LPoLJEHYqBsFKW5GRWqPK6qxLwFt7c07o4bwykLI11HmhGk03c2\n" +
       "hJRzRNNdcMvlAONFbD2sz71kFU0miuSNXMQrhuSMn5MuM5MnyS7jqyTp8XOK" +
       "EFzb8u2wmJtTucMs\nZrO5Em8zMooQp+8TfQJWFLI7j6Io4B09wusKzw/GnQ" +
       "YySYkpPK1bZMtRvGroiEncolwrMRjHVhu+\nFbeZmGnPqDbRTYaT8VglV3Oq" +
       "4GFZHPRnowlfGAgUdjuDfp+a0ojhWfN110JmlFRUc5Ket/SGrSar\nNUt2JN" +
       "UPrGk6ckzZ7dU7pCGgecGSnjjvmoSDuSurF/u23wkHzIwoRMtrMbRjjfUWZL" +
       "tJ1cl3uGU4\nAS0QmY6NyV40gfqEzXTUqe060+FMmDlErxawGzzKdqhBECRp" +
       "DZNe0aF8s+3SaV3OoXisFIwYVK2u\nqyP1ujuMzEwDWuMYtL0IiBqBsN04cr" +
       "c63uD0TbM1MTOXajJ9xtlsKZru9/O8aDDdXGu3UY8r2jYZ\nN6uz8dClTH+G" +
       "hCblKHGYGHi/1W3O5wY16tki1tERMXEpueEuitifNAujtWNdMuxP2nCrK2zs" +
       "Jt1z\npzg5XSh61ZcGMTLnwTtxJRBEQXSlcbhuyq7THS6CFQ5lWwhtpy1ogJ" +
       "K9YjvmZgZGbpN8NRjG7e2q\nH48HTpbnkBjn47waryhuClNc6JMNbxaJHKV2" +
       "dt1hQjHhTNCnURttDsZtOtFIZDJVu53dZDYne/x2\n7ppi1wuFfsdC9WWESU" +
       "qfrAZ8hoQFw+RGe5X7LBL72syWbCsT4V6aOBQ2R7V8JaDjcasr8lLHVixf\n" +
       "QDcDylqmWV9srxsxF6zsRsPU7eq8b1GR7rRsgd9I6+EmcGFVChetOFAR23Lc" +
       "3I4Hcl0Yhx7FgzDf\nwpPmLuk1NiMyWoet/sIJtoNiYWzpfrdfXZuEIEs2Q5" +
       "BwCrXrhC540lzj2jZUS5awTOhMdz2ZsaLQ\nISkXS6YLHEGMZWYPm7XOIupp" +
       "ZK8+kOb+minmu2q9YbCLuZbNtKlLtaW+SMfJJJHr1LTvudGaL6xw\nJbcz1y" +
       "YwGYkEvCgYmJwna36y3SqCt1PdzmphaVBdNEEK0qmooaU9NIyURuZaBSZQEJ" +
       "UWMkITZEdE\nIGhnILTOLvs93C1MYsATM99VmuJ46PXHhj/jMUIeSKyUdvnq" +
       "HELJFDZaUL2OY+tIb6bI0FINpRgu\nMi5FsWYvxyaqJbp05nMEg60cmu0Z7g" +
       "QZhf0lDHmsPE10yMdJI0qrftaxqG6CwjrebixNJsZaJOQO\nEoJambxJb7oG" +
       "zDKBPd2okggvEw4d1WCNSEhb79cwznLT4VyxUlxzu5JU5XQscuqopOtKik3k" +
       "BOvj\nqD9ebJF1ZzLIa2tcGcZQM4awLaIvEb/nj0m7WS/iddOaz6S65o8n8C" +
       "TBuwW1jqpTNlmwIt3royC9\npSNvxS98W5X0cIpm62zrbKgFXNs2ahC3Xa5i" +
       "k2aGASIjfDeFmlhLZxEZ1ZMEQvXBgI+qzrAT+vVx\nQDINBIp8DvfQYsCYyW" +
       "ycO01DTBJlAqwtCcZ0ZxSLxsrC4u5a7A44q92DpUVj59BLQ3CYVJfjKhFx\n" +
       "wxBfQ6u+m7CuXEeB33m4WqvVUhTPYRYV/ByzCKIPCaoPhPNc4CY9U8IaPa8j" +
       "61iPm2BdQQC6advV\nuL4xp3gbbteoHYW0sdZgZi+MHp+JPXPJaWKx41IRQ3" +
       "BK64/lJKoxmbGFbcMqAsEw9HbQSPFabWjE\nw92OrWI21lmqOhZynZGEtBF4" +
       "4EtbpKkxxBr2JkaTwZvNLNbw7aS7S9dMc8QV82VS7/kDwIErmCY3\nzPlGq6" +
       "EwnFwt8pnaYi1syyzhbD2vDeAWFGF5v2PU6QYHrVMcA6TVzXLQllSJZpidtd" +
       "aGsrj2UGOG\nMOgyp4VCISW44OBq3ukNEHJnN5tJLaWtGRuMM8OdGwjvF1DP" +
       "aWoWpS2FcDJFtuzYUrFpPkLyrBsO\nth24VaPS7rYG8Qm0ZUeSVh1OmGwniX" +
       "ReMDibaUNmK4NXE7614Clpq8NNC5UZDysMifB37VWH6uCa\nIiPwsD6jl9mi" +
       "LQ8i1kY2lmaFKF8tdppMpHW+18YUZpTkAzcgZD1SFhgVIFGcF8HWJOqMMUpp" +
       "ZVtM\nRxrLxBmCwR3J9sbRwPJX3banOAt2TE6r01prKaRLNlU33DyfzChWQW" +
       "w44QO8qcq04g05FSV6gUNs\nfWG6nfJu0ZALcWMVSgeejbJsx8bMtNtcS9zI" +
       "rQ68Bpqy5GKBBm1x1O00FsGQUtF6A7akvlSTOFAr\nBAZ46IxW061IyX6c2V" +
       "zU0XsGzXlxXWEKCK159CRtTIxqNunUunOiphrweORjzSU7arTq3JzUoYEm\n" +
       "BciUXXQJRUexqZoptQxmR/3Qg01kFKdxk93Ka2o9h9Z+e15Hgiq00tqE70NN" +
       "Ps8b0QppNUdKqyAm\nyXyBCRDVyDeC2TV341ViK2kGnir5Wi6CgcAlW2c0Xk" +
       "Hqbqh1MTldoAu4WuuvURSaS/aCHcVohBrD\ntY4XGiWKEY7UTb4G9emstu1k" +
       "sunI6zhab6ZbgRdQvaOO+1yHTuE6MXJqIFx5osoA61KIYcJpy1/G\nW8wALz" +
       "BENttNkM9rXNvg1xt3hy5ylW76RDAc53YParPqcNJKG7VlR0rscVeb8Iudt9" +
       "arxLCXKXjL\nw7khYfW5nKt5m/qqEFurGUcue4KfqGgb9rvJuOZYrseIK0dk" +
       "5vmi4ah44CAjSCHCNC0aGN7Lq4ak\npe1RinRXu9xqu7jWDdiEzWB6ZUuzuc" +
       "jiGzbJFgLZyOhoK6OLEVM30aUPsiOegad9e2iITWybpJDT\npKtCDYoNZNMw" +
       "a44RtmWiETumMrRG0JZj+hY5wnB5iUu78XKIuqQ46AjTtelLo1ZhdzUswgOI" +
       "W0is\n04L9htKq4iHqdqB8SRXZJF0VzoKRtMZ62UcDPcFH6xhqCWOyNaxPbT" +
       "w2DTFgR3I9hvOasFxt1YaR\n7XwEhYp+3PNbfLW+mYIC4GMfK0sD6bjCuLmv" +
       "f+51RY+bZJN9IbEvDG8dV/+nvYH3njQN4srzb9ei\n3NeKry/+5fqn1C++Wp" +
       "Y3JeIPpJVH0zD6sGfmpnfaVDhPZLLvyJ5U2r929QnjMt169nxX4TI4/sV3\n" +
       "xDzU088f/uuXm39z++L5Er0KCuosDsT7CvXn7hWkZSF6A4xqOc4UpPd6QMYZ" +
       "zbxN1+QdN0ExuwzD\nB0q4PHSOOtF6OT1+el7wXZ93Ubx1Whzq9yQtWxHfc1" +
       "yCgyI62Ruwb+qeGI5BsUps0kP9blm2HtzW\nT5pi1klT7M5HUBz7yME6UxNn" +
       "nYWpefuoX3VQynEAXOmWE+Sha/bN5Zlm4u07B6+ltpPcFW/dvvPK\nD98501" +
       "pLv2sxn327U0tQ95zwpZlvngp/+P8UHkbR+4WPnRzsnJXeSUtpDz7+qnBwn6" +
       "CfeLBFARi4\ndkzhnYX8Dhp45OTkvcSbslcdRQ/pZhx1uzb/B55UBYQgGgAA");
}
