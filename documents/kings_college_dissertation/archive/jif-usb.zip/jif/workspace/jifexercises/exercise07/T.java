public class T {
    int secret;
    int pbl;
    
    public void foo() {
        this.secret = 1;
        this.pbl = 0;
    }
    
    public T T$() {
        this.jif$init();
        {  }
        return this;
    }
    
    final public static String jlc$CompilerVersion$jif = "3.0.0";
    final public static long jlc$SourceLastModified$jif = 1248525159000L;
    final public static String jlc$ClassType$jif =
      ("H4sIAAAAAAAAAK0Ya3BU1fnsJtklyWLejyFvCAaKJCCPYRqnNcQAIQvZSSJq" +
       "KG5v7p5NLty993Lv\n2WQTWweLmqh9OZW2dirFNyI6WDs4QzuWVludMtopna" +
       "qMU8RiKTPVGaVaYUpn+p1z7nt30x/tj3v2\n3nO+9/vs0Y9QkaGjpt1SspNM" +
       "a9jo3ColY4Ju4ERMladHYCsunr734KO/2XDxtSAqiKJiIU0mVF0i\n0wSVR3" +
       "cLk0JXmkhyV1QySHcUlUuKQQSFSALBiU26miKoLaoBqXFZJV04Q7o0QRdSXY" +
       "xZV6xXFgwD\n0EJs19iL7kSBjI5aLQxTKC4RA+YirX5sVe0LXzleUYDKRlGZ" +
       "pAwTgUhir6oQYDGKIimcGsO60ZNI\n4MQoqlAwTgxjXRJkaQYAVWUUVRrSuC" +
       "KQtI6NIWyo8iQFrDTSGtYZT2sziiKiCjrpaZGoOpcQ5E1K\nWE5YX0VJWRg3" +
       "CKp1NOX6baL7oF6JBILpSUHEFkrhHklJENTix7B1bB8AAEANpzDY22ZVqAiw" +
       "gSq5\n5WVBGe8aJrqkjANokZoGLgQtyksUgBZogrhHGMdxgur9cDF+BFDFzB" +
       "AUhaAaPxijBF5a5POSyz+D\noci/74993hpkMiewKFP5w4DU7EMawkmsY0XE" +
       "HPFyuvOh/tvSjUGEALjGB8xhepa+dHP04i9bOExD\nDpjBsd1YJHHx6vrGpt" +
       "M9HxQXUDEWaKohUed7NGfBGzNPujMaZEOtTZEedlqHJ4d+e9u+I/jvQRTq\n" +
       "RyFRldMppR8VYyXRa76H4T0qKbgfFcrwA5onJRlTzUPwrglkgr1nNIRQGJ5r" +
       "4AnRh6CikU7IQXpc\nmaFr2VQgAKI0+hNBhhjaosoJrMfFp8//7mt9A/fNBe" +
       "3AMMkTFBhBgQCjUOdVhlonQXP1w592l397\npXEcknoUFUupVJoIYzLIHBFk" +
       "WZ3CiThh3q9wRZqVrZExCBSIubgMhHjOamhSR4v9AeEkTj8rCyK+\nY/12dK" +
       "C570fUd9TW1ZQ6Fw0st4fLFlk+vGvrV+cWF1CgqUKwENVksadI5aAdF6d/Vf" +
       "PFEyev/DyI\nikahFBk34aSQlkmsd6OaViC/q+2tIQypr0SFMSxHUSnPcAGy" +
       "1MqzsCYyHILqosDXjHyZwncxLDBD\nqe4QoWjNEI3t/90EcTFWVbP9yX82PM" +
       "sD2G+1mK6KOAGFyUGIr1rTtv3Q9VdAL8hNkJaArDTVm/25\n6UmnbjP3CFqc" +
       "lep+Jt1WGaOaFIJySVVPCTIlY9mkhEzo6pSzwwJ1IV0qeMzSZQl1qk8jVgb/" +
       "0T+7\n5cKpZbuC7opZ5uogw5jw/KtwYmJExxj2//zD2PcOfDS7kwWEGREEmk" +
       "Z6TJbEDJOmNgABWJWjFnTW\nVz/0/eU/ftuKuCqHeo+uC9M04DJ3nW56+DXh" +
       "EagTkLuGNINZjiLGCVkM6Hode1/pOoQsc/g7Idpj\nGOAgKBs31M395fdNb4" +
       "5w/n5sEKjBQWLxBd1O0llQxcWT1fsP3He1bHMQBcH+4PgktGVJhN7bmBWW\n" +
       "vfYpjU3accYt4KYs4H7nmJbyOr8MJv+q7ZGr/2r4402Mf2kCG6IuaVQrs6iF" +
       "iLoVzEkbGeOgC4oh\nQ+vnOTLCDvsymt7tjhXqhSWMoQXuqOygxMV1+y5++u" +
       "KfjnfwNGnxYmRBtz3f9HH70duXWn5u9qs0\nhAUom1xnIN5+/plP7lnwFNOs" +
       "SJ1i6dTispMGXVWUNAG6g/VGBxWdUaGKfBmEqs/ynUm++1BaUJuu\niFQal+" +
       "reMmaz6BxRNZtLXNzy/q/fu+cH9afcivsQXNCra+rrWy/hEpZYtkOW+BxiI+" +
       "RxCkh2rdfC\nbpnchn7nrkVnV1z3nde5dH5H5sJ4/NnPn5jpeGrcSYGNJlP6" +
       "symXs26BCdNx1t1fmHv305+taXQ5\ni3kA9J1igNwfdL3RVmdpLrttVAlRUy" +
       "7rXf/6qrqew9tesBzVa+Mv92rmw3Trtzry2Mt/PfLMIYvG\nZqbXNpeOg2xd" +
       "p5nqd7P1Sxo/3Ka5gbxfA+bXRs0ylufLLE20+fpHhU10QrWqe2rsjs9eOVjS" +
       "6nig\ngRWgIJ0xPH3VgxYXg4fPzS6vLzsDlh9F10wIRr8CwxCdo7EOrpDdvc" +
       "8/2vlIzbx888HLb5CzLE6d\nJkax2zLZ8u8QXB1zw1uTFaFjP0kFURgaO2vX" +
       "cMnYIchp2h5GYcA2es3NKFroOfcOy3wydBpjo78x\nutj6W6IzYsE7habvxT" +
       "yJGEw57UvwVJvzXZjNc3yoCyCNvkwwwHa2dmhmE4BWZmARpgnDU4lZicMJ\n" +
       "PvT+oXTNXOu6ZDVLgWJmd7gVsemrGWZbimF9c5EiHpEiOUTiMWmDFeYB84es" +
       "jjpyZVZfBvJQEWRX\nbglrj1T84utvnvEPqCzPGKUV3hzLouHOskfq1HP7ng" +
       "4P2lkGU3MP1AecI0EG6LI34+ThXk+KeXay\nAxfYpyDKJ807yYPNT1x48fxQ" +
       "ddB1cVuSPVC5cPjljbuB6dk2HwcG/eqKtqN3Dp0d41W10ju19ynp\n1N+mX8" +
       "EdN3zr/RzTfgE0ezaAIbpyf4ke95fCs4A+2RE5S5fdQEQbkxlOyoMZyoH5vx" +
       "azPDB0+Yaj\nxzeZ/a41K5wzfDU4o1NTvhsoM+nsrZ9E7hVe3WUFzN0EFRNV" +
       "WynjSSw7hdNPZBu7cFtF4NFQZaIw\nuqHeXzkDWX+bePHi4qkzZR/3rT114f" +
       "93GTGTPde9o2VeJeIieSl+6e31Z5ax8uEuZCWc2IinnLXa\nIUBdX24GUKkr" +
       "BOx5/3GXk/JMyPMeQuAlVZVt7zMDYT9BhZOqlEABF+aa3GSd8kWf2hySeoKU" +
       "Lsdc\nZeFYVlnw7AzY1CvgqclBnSN6wCrzgQ36gKvno8myYThDr/IaV6GKoH" +
       "J2d6GNrJM3Mlf/b5p3THx4\n54OasqpHynsLqfPGcpr/NRcXP9Ru3/zu0HtH" +
       "zGnPDjOcIZ3sTzsr4GyMW5/b2Zp5YOS7fFgTZWFm\nhvILQxzzO6X9N19bXm" +
       "oWLencW8n7939Q5hujWfQ5qjfnp0PfdyzsfmfgxInD/hRGLuu51Gc4Vuas\n" +
       "XfZZ+PIbl27Mbbf/AJGSX9g/FQAA");
    
    public T() { super(); }
    
    public void jif$invokeDefConstructor() { this.T$(); }
    
    private void jif$init() {  }
    
    final public static String jlc$CompilerVersion$jl = "2.0.0";
    final public static long jlc$SourceLastModified$jl = 1248525159000L;
    final public static String jlc$ClassType$jl =
      ("H4sIAAAAAAAAAKVYW6zr2FnOOXMuM5nTzpyZ6XTazuV0ekpniHocx3EunQqI" +
       "E9ux4zh24tiOy2jj\n+H6J7fiS2J5SwUunpeImpggQlItASDAPFKT2DZBagc" +
       "TlpQ9UPFBArQoS9AEQUCSgLGfvffY++5yZ\nCjWSvdf2+te//sv3/2v9/5vf" +
       "ql1N4tqtKPQLyw/TO2kRGckdTo0TQx/6apII4MORBv9G8+nP//AX\nbj5Ue0" +
       "ypPeYEi1RNHW0YBqmRp0rtxsbYrI04Gei6oSu1m4Fh6AsjdlTfKQFhGCi1Jx" +
       "LHCtQ0i41k\nbiShv6sIn0iyyIgPe55+ZGo3tDBI0jjT0jBO0trjjKvuVChL" +
       "HR9inCR9haldMx3D15Nt7RO1S0zt\nqumrFiB8mjnVAjpwhIjqOyCvO0DM2F" +
       "Q143TJFc8J9LT2wsUVdzW+PQEEYOn1jZHa4d2trgQq+FB7\n4lgkXw0saJHG" +
       "TmAB0qthBnZJa+99S6aA6OFI1TzVMo7S2jMX6bjjKUD1yMEs1ZK09q6LZAdO" +
       "eVx7\n7wWfnfPW7NqN//kJ7j9vXT7IrBuaX8l/FSx6/sKiuWEasRFoxvHCb2" +
       "d33qBW2bOXazVA/K4LxMc0\ngw9+ccn84x+9cEzzvgfQzNauoaVH2n93nn3u" +
       "K4NvPPJQJcbDUZg4FRTu0fzgVe5k5pU8Alh8+i7H\navLO6eQfz/9k9WO/Y/" +
       "zT5do1qnZNC/1sE1C1R4xAH56Mr4Mx4wQGVbvigz9Ac9PxjUrzK2Acqal9\n" +
       "GOdRrVa7Dp53guda9aS1q8Id1zGr6cfz6v2O/aVLQJRnL4aFDzA0Dn3diI+0" +
       "3/76n30cn3z6U5fv\nAuOEfVq7JNQuXTpwePe9ylTW0SsQ//Pvv/L4T304+c" +
       "Ll2kNK7RFns8lSde0DmW+ovh/uDf0oPXj/\n5jmkHRwM0HFjDYACMHfkA0YH" +
       "YAKVdnHtxYuAOAsjCoxU4OXXOmzts8/jv1T5rrL1UxX3Y9GA5bxj\n2W68vH" +
       "iV/pFPvfhQRbS/AixUaXL7u3M/0rgn38X+1n+873ePsXFRIC4ONUMHGeBswV" +
       "ETeT/7a63/\nuly7CmAPAj9VgetAFD1/Efb3IPWVE1intRfvi6KLm7xymiEq" +
       "U11mao+aYbxR/YrNaVjXUzsO92df\nDhh49DB+53eOf/978nwHRP8w3EQAWf" +
       "Et0gCyqqmhR8eoqV4vVGa9oPghEf0b9fr4m3/+0quXz+es\nx84lt4WRHkfA" +
       "zTOvCLFhgO9/8wvcz332W69/7OCSE5+ktWtRtvYdLT8I+tQlAIEnHxCNd555" +
       "6o2f\nf/mXv3rq8yfPuA/iWC0ql+c//pXnfvFP1V8BkQqiJ3FK4xAltcNOtd" +
       "MNqvf3H8aNc5MnsxUCL8YL\nUaXpUz9s1q/9+5c+V791LEe15j0HDtX5czEt" +
       "3bPwSCv/cPm5b/9l+rWD6c5QUvF4Lr9/W1E9B8ne\nX+1uXvu9X91crl1Xao" +
       "8fjhY1SEXVzyrDKuBwSIYnH5naO+6ZvzfRH2e1M+Q9exF557a9iLmz9ADG\n" +
       "FXU1vn4eZpVHwfPUSW66fshFxwnpUi2qBt0D4YuH9wejE+MDECSGFhvpA4zI" +
       "xc4GpM7dSW7/2ed/\n85t/8PX5U5fPHYAfuD96zq05PgQPUtajHOzw/rfb4U" +
       "D95cb73/zE/Gvr4wTwxL3ZDw+yzT8UXzI+\n9NGf/PsHZM2HwDF9CKODisg9" +
       "dnkUPA9Xz/12GVavPlgerQ/H3A+c41G9buWXQKxcRe407zSr/4n7\n7fgQmD" +
       "edQD2s/1Bl08P1Blj33a6v3T6NdxHccMBJdBscFYfVN8Hl5BBMFT7uHF8EHr" +
       "A5MNw7z8iY\nENwWPvONn/mLn/7A3wIj0LWruwprwFrneLFZdZ365Juffe7R" +
       "N/7uM4eIAXZ48fPfrMsV11n1GoOr\nRiXdIsxizWDUJJ2GugNuRvpdAT8aHQ" +
       "fnD6bgSAwfKFx64/a4nVCD09+kuVIRbAmbQUKnnl9IjOEW\nxG44UCf0cMit" +
       "5tuA1fgBxe+UxYLeTkh0141QlkmLfh9hdvWWxAvS3mA2W7s/U6SW7sQEW1Ad" +
       "aZS0\n+TKTRD/Tp2kYBep2uuzNnYnAiaQqqqtlFDQiuOwGKdLModRFdq06Es" +
       "wafWiXNFd93lNJN0rhRRKx\nU7Xvhgg49ldtOmvj86mv6uPVMMmCuIu0JzOo" +
       "JY/ydDHYOhPaoZbNjUg0nXpzvxDniMZ4TVreeHYh\nwnyxGGtLf5lNeH5BLA" +
       "YM5ixbnY0zCRk1xLYyodBis813wyY/1xfyKlfETi4T1n5Ub+J0Avcdpust\n" +
       "MJdCVYbPhcmwPR80Vk4so4loNBm59I3lajSZ+6QSDfaCtbSduBPyqxE5oZyN" +
       "RiazTlNhqXp7yodb\nv6LIXXlOeyq/GojScinO40U2nPAp1WEpqQh7Dk/EI2" +
       "FBpitFaCWl40ycoRtHqkKGs0jjURye1CUc\nXclNkZbmFjKcRDA7kztrlemG" +
       "RIfGKCZaLMc44cX22PNpnBWcvIvBa6w3GOADNipHq1ZLEbcDZ28t\ntmgdlU" +
       "SMNHoqHW89d8CGnhKSjMWnhZcsLUwJLcCHnOq5lcV9bUQ0MGJElNhgaasDlc" +
       "sdFyNQFeVm\ni6JsjOqh5kDdNoCJHXlTx9hPCA7dt0fLLj5V994mWTVlfMwR" +
       "Rbab2VC6W7hLEh8wLon1ctuI1IY+\n5pptp7+e4fmoPopcLNHhFT0e551dTE" +
       "bptD/OeXk5wiV1EtpLQ++ypImRJctl7lRV8FkqKLih+9sx\n3dYbRj9rUJC7" +
       "4+fCtj4viLmvT6No3hNXhTxXu51xW2huJ2vLJLR4P0DDgJ77Qrnk9rHle1YM" +
       "Byw1\n50kajduDYG53ho637FK8HGn1jUrELZG3BhOq2bBZzLZdNUxCOp6aRN" +
       "SDoO4m7Q8gk8UMZDCdegKB\n2ZjFD93lTBdtEKW8zMF7tN/ykX63Hsm45gXh" +
       "klhmkUiH1KpkqDFGeJKCDB3BtpFtfz9XtmKs4PkQ\nW1DZ2praY3embuzFvL" +
       "3rDwzcE9xePCwmjfoKglv6ZIh2m+ZS7wsSrPAdYt9M0rbJEL7X2JG7WGxo\n" +
       "EgEPre1yssdZ0UtUHcB7oBMdHRJNjsALYweNCqrueKpNYB7SVhe8D7ynd2aq" +
       "6AyhbaOVUnwRxc0F\nMV3k4+Ui4LQBWcDTbZkMV8WYYrZhMpLdcaHsAy1nRt" +
       "iovjXafCi5LE4hKdRv4ppASOKa6xdyr8VN\nk1GLbMCbSWcyG5BEsSSpGI6F" +
       "dIfwfVEfMD2b9Wh1ACJD3EAttN5ZboK1yyFDYqv5RtSgU1gi1ZlK\nUHSxEE" +
       "VuKFD+qg9SAF6GnWhR7vc0TInNrTEtFwrvw1uv54rWGmoKjW4d1SaRss6G3T" +
       "BS0Cy09qi7\nhybpfrWh8Tx3WxBUjlqcNjNHi663l3ByjuMbT+kI9Bof0bMN" +
       "aw0wiZZcIhCkulhCTchYQmaaTbLh\ndmyEjWzYnzbbIxoJJLTTGMk2rlqCx2" +
       "QkS7GK6zDkUPSmnXGoGzAUzUI+0SCrS+mRWydnA2uCJQg8\nRfqoqbPrNrqH" +
       "AjTBJy7GS0yO6fCs6ft8rkkCbCYcMjbg9XjKY9q40eYsLyVF2ma76w0mSfWd" +
       "uYrc\nJaJq2iptT1ZJe9wNNvS6mMW9Kb1rbLsKGUOtuN1utqZmyxuSHSpTRT" +
       "5OOg7hMKFY4t6aNGbWsB3a\ndb6xC2YCMxztkmKTdlPXlrf2QpqGvJxtZ4WV" +
       "T0W4UaCNRjYx3cDcs2SQrzZzLC0Rsz8ed5t6JksB\nmvW3SbNuD5bhBs4Dik" +
       "UbUORzXT/YE+wsWdCw09EFJ4mmpAyyJTsgOxYkklgu6UuVnJjYBt8mUBEs\n" +
       "N40GjKlLOsvqDsGrfiM2phu17GD5nFVSRmbLAtpCZtbQxn3V1JxdwsvsMFYb" +
       "cSwVkI1Hyir1ZlID\nyx2qMc+Hnt2KdXNYX0eBZgfdIPbEQIRLJNANVB+jYz" +
       "Sh2xAbcAHqRgYZa4sVydI+1wHGkJNWBxvq\nbA6nsLkZ75Am2khVmUfrDuIN" +
       "+kAli92bOoPMxY0eMXGaigN/viy6sWxCnW28Nfb91EiwUlQb012/\nFW/2iB" +
       "CnZVy0pinEmcyUWu3IurJdyyyow61WrkdosNW7HLzIQwiZqKi1zs1BYy3Pk2" +
       "bhZybD4K1m\nw4zG9hJu8rG0NVpx4iZ9Yya6i07gWHVrLlkU3cy5MSJa+Uq2" +
       "2iZXLjo7pkxGvt0n4Oaemse94T4f\n6mEXn8XRSN9pPai186lynfd6vTGzRo" +
       "clg3f0Ojjc8lbJKL2sx8sYXO7hTCBUwuWaHrGcW+qstZO1\nabCiNDtq2Si5" +
       "0gYtI0HYCRGHM1ObFci+0LHIDbu9vJ6lbkfqUOUqwbu2ut7lQkGT+B7tLnd7" +
       "kd6V\nsuKyGlKEw2LI7rz9fj9WW/rG3uBtTFI2g3lkBaNl21ccbUrXuZ3QCG" +
       "WBlWdZRxmJjCXRG71riYmx\niUlJWTsboq+huDOOcGe2FJyptBkRxgrrtY3E" +
       "daNCERUT29E8Ls3l+tryYxcWeu0s3QU7nNsOS46c\nLEXELpkwG88Sz9zCY6" +
       "4bWG2u5XvkEply8MDQqCZOdhgKaTcEW/YaE0NWi/ogB8FZjCZ0r9ktVhwr\n" +
       "wHm7Z+a8rmOwJmYLThyiGuf67jrDOrrXGu81EjK2k3TLIqOoqbdhCW66Gdwv" +
       "gqgOs42N3MN1Filj\naF4KpoU3jVIdUOuoMNueAVLJMGkPGq05ji5AWuFxfu" +
       "3l/qwIp0oRjtFdrpbcCGs2Vqpbz0tDgdQ2\nPEH3pQlMGcKssLOTcNoIkljp" +
       "A6+IBiItiZJt4sScFaUicBeLfdfWWU7Bsq5GpESbJXhFpfb1DORD\nufRGkt" +
       "xYG9zYaW+9UplDSCzAcNvsI6RACpxu9MOWaNAG5RgLv9ExEFhB1byX4ZkylL" +
       "QW5QQBI6t1\naonpcqtNLidejM1yFEJI2YPoacFNDT4b+KIipt1yOloJfcxW" +
       "ZlsfH2BEQ1URcqH3PMls2cXCCCdL\nJtG1umIQKxGkne6gXMHDnQWOFSxYsJ" +
       "39MC4tHulYk10Q9jbFSrBHMUSpYoechGO6pXdINqanyNQ3\noTUaIcI4b9fR" +
       "9kxNttG4CBJma3KkFsUQO9dkrj/PEKjMmuN0XJIBN3JnGqUgiVAmcZssphIK" +
       "rVtK\nhK5mi65JWIIiEZu6vaPAzbMsZx25z8L9tbwJwYU90KRe0O0jfR61M1" +
       "cyeXTrmkHU5Ey9KBNzY1o5\nFYwge04yWYbCpNYWMzWpy6aiNDhq7be60/Xa" +
       "hAY0uZD7FkTwg0FVLkgnVcfNQ010t1N60jibHoqL\nQ7F4+6QjcNYveM9pIy" +
       "GuPfdWbctD/fi6/C83Pql++dWq5KkW/lBaewRUCx/2jZ3hnzUaLjKZHrq0\n" +
       "p9X3r197Qr/C9J652Gm4ArZ/4W1XHmnpF4/+9audv37p8sWyvQ6K7CwOhHuK" +
       "92fvFqlVcfr4SaH6\n6Lki9W5fSD9nmbfopLztJChwzTC8r6zbhc5xd1qrXo" +
       "+d7Rd8z/tdFm6fFYzaXU2r9sT3nZTloLBO\nDg4cGZovhDQoYPE8PdLuVKXs" +
       "rZe000aZddooe/kjSLf9kVtbgDdnm4Wp8dJxD+tWpcctAKXbTrAL\nPWNkmO" +
       "cajC+9fOu11HaSO8Ltl15+5UdfPtduS79nNZ95q10rUu+C8pWbb54pf/T/VB" +
       "5GkHuVj50d\nmDmvvZNW2t762KuLW/co+vH72xZAgOsnHN5eye9igYdPdz5o" +
       "nFf96yh6QIfjuAOW/x+uO8j9NBoA\nAA==");
}
