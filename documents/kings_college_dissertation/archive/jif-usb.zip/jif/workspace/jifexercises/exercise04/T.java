public class T {
    int secret;
    int pbl;
    
    public void foo() { int x = this.pbl; }
    
    public T T$() {
        this.jif$init();
        {  }
        return this;
    }
    
    final public static String jlc$CompilerVersion$jif = "3.0.0";
    final public static long jlc$SourceLastModified$jif = 1248374217000L;
    final public static String jlc$ClassType$jif =
      ("H4sIAAAAAAAAAK0Ya3BU1fns5kWSxbxJhrwhGCiSgDyGaZzWEAOEbMhOEqmG" +
       "4vbk7tnkwt17L/ee\nTTaxdbCoifahTqWtnUpRqSLSTq0dnKEdS6utThntlE" +
       "5VxilisZSZ6oxSrTClM/3OOfe9G/qj/XHP\n3nvO936fPfYBKjAN1LhbTnbQ" +
       "aZ2YHdvkZAwbJknENGV6BLbi0un7Dj7+m40XXwmjvCgqxmk6oRky\nnaaoPL" +
       "obT+LONJWVzqhs0q4oKpdVk2KVypiSxGZDS1HUGtWB1Lii0U6SoZ06NnCqkz" +
       "PrjPUo2DQB\nrZDvmnvRXSiUMVCLjWEJJSTiwEKkNU+sXvTcF49X5KGyUVQm" +
       "q8MUU1nq0VQKLEZRJEVSY8QwuxMJ\nkhhFFSohiWFiyFiRZwBQU0dRpSmPq5" +
       "imDWIOEVNTJhlgpZnWicF52ptRFJE00MlIS1QzhIQgb1Im\nSsL+KkgqeNyk" +
       "aJGrqdBvM9sH9UpkEMxIYonYKPl7ZDVBUXMQw9GxrR8AALUoRcDeDqt8FcMG" +
       "qhSW\nV7A63jlMDVkdB9ACLQ1cKFo8L1EAWqBjaQ8eJ3GK6oJwMXEEUMXcEA" +
       "yFopogGKcEXloc8JLHP4OF\nkX8/EPu0JcxlThBJYfIXAVJTAGmIJIlBVIkI" +
       "xMvpjkf6bk83hBEC4JoAsIDpXvbCrdGLv2wWMPU5\nYAbHdhOJxqWrGxoaT3" +
       "e/V5zHxFiga6bMnO/TnAdvzDrpyuiQDYsciuywwz48OfTb2/cdJX8Po8I+\n" +
       "VChpSjql9qFioiZ6rPcieI/KKulD+Qr8gOZJWSFM80J41zGd4O8ZHSFUBM91" +
       "8ITYQ1HBSAfkIDuu\nzLC1bCoUAlEagomgQAxt1ZQEMeLS0+d/9+Xe/vvnwk" +
       "5gWOQpCo2gUIhTqPUrw6yTYLn6/k+7yr+5\nyjwOST2KiuVUKk3xmAIyR7Ci" +
       "aFMkEafc+xWeSLOzNTIGgQIxF1eAkMhZHU0aaEkwINzE6eNlQSJ3\nbtiODj" +
       "T1fo/5jtm6mlEXooHl9gjZIiuGd2370tySPAY0lc8sBKBLfEUqB+24NP2rms" +
       "+eOHnl52FU\nMAqlyLyFJHFaobGeTVpahfyudraGCKS+GsVjRImiUpHhGLLU" +
       "zrMiXeI4FNVGga8V+QqD7+RYYIZS\nwyXC0JogGtv+uwniUqyqZvsP/1n/rA" +
       "jgoNVihiaRBBQmFyG+em3r9kM3XgG9IDdBWgqyslRvCuam\nL526rNyjaElW" +
       "qgeZdNlljGmSD8olNSOFFUbGtkkJnTC0KXeHB+pCtlSImGXLUubUgEa8DP6j" +
       "b3br\nhVPLd4W9FbPM00GGCRX5V+HGxIhBCOz/+buxbx34YHYnDwgrIig0jf" +
       "SYIksZLs2iEARgVY5a0FFX\n/ci3V3z/TTviqlzq3YaBp1nAZe4+3fjoK/gx" +
       "qBOQu6Y8Q3iOIs4J2QzYegN/X+U5hCxz+bsh2m2a\n4CAoGzfVzv3l942vjw" +
       "j+QWwQqN5F4vEF3U42eFDFpZPV+w/cf7VsSxiFwf7g+CS0ZVmC3tuQFZY9\n" +
       "zimLTdZxxm3gxizgPveYlfLaoAwW/6rtkav/qv/jLZx/aYKYkiHrTCurqBVS" +
       "bRuYkzUyzsHAqqlA\n6xc5MsIPezO60eWNFeaFpZyhDe6q7KLEpfX7Ln78/J" +
       "+Ot4s0afZjZEG3/rjxw7Zjdyyz/dwUVGmI\nYCibQmcg3nb+mY/uXfAU16xA" +
       "m+Lp1Oyxkw5dVZJ1DN3BfmODisGpMEU+D0LVZfnOIt91KI21xisS\nk8ajur" +
       "+MOSw6RjTd4RKXtr7763fu/U7dKa/iAQQP9JqaurqWS6SEJ5bjkKUBhzgI8z" +
       "gFJLveb2Gv\nTF5Dv3X34rMrb3jwVSFd0JG5MJ589tPDM+1PjbspsMliyn42" +
       "53LWF2DCdJ11z2fm3v74Z2sbPM7i\nHgB9pzig8Adbb3bUWZbLbps0SrWUx3" +
       "o3vrq6tvvIwHO2o3oc/BV+zQKYXv3WRJ548a9Hnzlk09jC\n9Rrw6DjI1/W6" +
       "pX4XXz+ni8MB3Qvk/+q3vjbptrF8X1ZpYs03OCpsZhOqXd1TY3d+8tLBkhbX" +
       "A/W8\nAIXZjOHrqz60uBQ+cm52RV3ZGbD8KLpuApt9KgxDbI4mBrhC8fa+4G" +
       "gXIDXz4q0HL79Gz/I4dZsY\nw27NZMu/A3s65sY3JisKf/KDVBgVQWPn7Rou" +
       "GTuwkmbtYRQGbLPH2oyihb5z/7AsJkO3MTYEG6OH\nbbAluiMWvDNo9l4sko" +
       "jDlFvzXDWzLHv4PCeGuhDS2csEB2zja7tuNQFoZSaRYJowfZWYlziSEEPv\n" +
       "H0rXzrWsT1bzFCjmdodbEZ++mmC2ZRj2txAp4hMpkkMkEZMOWP48YMGQNVB7" +
       "rszqzUAeqljx5BZe\nd7TiF195/UxwQOV5ximt9OdYFg1vlj1Wq53b93TRoJ" +
       "NlMDV3Q30gORKkny17M24e7vWlmG8nO3CB\nfQqifNK6kzzcdPjC8+eHqsOe" +
       "i9vS7IHKgyMub8INXM/Wa3Hg0C+vbD1219DZMVFVK/1Te6+aTv1t\n+iXSft" +
       "M33s0x7edBs+cDGGKr8Jfkc38pPHnsyY7IWbbsBiL6mMJxUj7MwhyY/2sxmw" +
       "eGLV919fg6\nt9/1VoVzh696d3RqnO8Gyk06e9tHkfvwy7vsgLmHomKq6asU" +
       "MkkUt3AGiQzwC7ddBB4vrEzkRzfW\nBStnKOtvEz9eXDp1puzD3nWnLvz/Li" +
       "NWsue6dzRfU4m4RF+IX3pzw5nlvHx4C1mJIDbiK2ctTggs\ngIf9FrPHEwLO" +
       "vP+kx0nzTMjXPITAS2oa395nBcJ+ivInNTnhTNZsXZub7Hq2HPZHothy54zD" +
       "vtaZ\ntdPv2RnwvA9m77BlOMOu17rgWEVROb9PsObSIZqLpyc3XnN0e3Tnw7" +
       "q6ulue92ZQ64+vtPi7LC69\nr9+x5e2hd45aE5jjepKhHfyPNDsIHIzbfrSz" +
       "JfO1kYfEACUpeGaG8SuC2BL3POevt9Z5qdm05HNv\nJB/Y/15ZYLTlEeGq3j" +
       "Q/Hfa+Y2HXW/0nThwJphXyWM+jPsexo3nd8k+KLr926ebcdvsPNuyffNMU\n" + "AAA=");
    
    public T() { super(); }
    
    public void jif$invokeDefConstructor() { this.T$(); }
    
    private void jif$init() {  }
    
    final public static String jlc$CompilerVersion$jl = "2.0.0";
    final public static long jlc$SourceLastModified$jl = 1248374217000L;
    final public static String jlc$ClassType$jl =
      ("H4sIAAAAAAAAAKVYaazk2FWufr3MTE0nMz2ZJJNkls6kQ3qw0q4q15oJi6vK" +
       "dtlll13lpVwOo4f3\n8r67XE5A8CcJRGwiQYAgLAKBID9YpOQfICUCieVPfh" +
       "DlBwGUKCBBfgACggQEu957/V6/7pkIpaR7\n332+5557zrnfOfee85lvNK4n" +
       "ceN2GLh70w3Se+k+1JN7jBwnujZx5SThqg/HavvXW2/7/R/47K2r\njaekxl" +
       "OWz6ZyaqmTwE/1IpUaNz3dU/Q4gTVN16TGLV/XNVaPLdm1yoow8KXGM4ll+n" +
       "KaxXqy0pPA\nzWvCZ5Is1OPDnmcfycZNNfCTNM7UNIiTtPE0acu5DGap5YKk" +
       "laSvko0bhqW7WhI1frhxhWxcN1zZ\nrAjfRp5pAR44gmj9vSJvWpWYsSGr+t" +
       "mSa47la2njpcsr7mt8Z14RVEsf8/R0G9zf6povVx8az5yI\n5Mq+CbJpbPlm" +
       "RXo9yKpd0sY7X5dpRfR4KKuObOrHaeO5y3TMyVRF9cTBLPWStPHWy2QHTkXc" +
       "eOel\nM7twWvSNm//z48x/3j46yKzpqlvLf71a9OKlRSvd0GPdV/WThd/M7n" +
       "0S32TPHzUaFfFbLxGf0MDv\n/RxP/uMfv3RC865H0NCKravpsfrf/edf+CL8" +
       "tSeu1mI8HgaJVUPhAc0Pp8qczrxahBUW33afYz15\n72zyT1Z/uvmR39H/6a" +
       "hxA2/cUAM383y88YTua5PT8WPVmLR8HW9cc6s/leaG5eq15teqcSin28O4\n" +
       "CBuNxmNVe3PVrtQtbVzn7tmWUU8/XdT9m3ZXrlSiPH/ZLdwKQ7PA1fT4WP2t" +
       "r/75R5D5j3386D4w\nTtmnjStc48qVA4e3P6hMbR2tBvE//8GrT//k+5PPHj" +
       "WuSo0nLM/LUllxK5lvyq4b7HTtOD2c/q0L\nSDsccIWOm0oFlApzx27F6ADM" +
       "SqU8brx8GRDnboRXI7k65Q/3F41PvYj8Yn12ta2frbmfiFZZzjmR\n7eYr7G" +
       "vED3785as10e5abaGK9M63536sMm956+I3/+Ndv3uCjcsCMXGg6loVAc4XHL" +
       "egdy9+tfNf\nR43rFewrx0/l6ugqL3rxMuwfQOqrp7BOGy8/5EWXN3n1LELU" +
       "pjoiG08aQezJbs3mzK2b6TYOdudf\nDhh48jB+87dOfv972r5Vef8k8MIKWf" +
       "FtTK9klVNdC09QU3cv1Wa9pPghEP0b/rHZ1//i7mtHF2PW\nUxeCG6unJx5w" +
       "6/xUuFjXq+9/8/PMz37qGx/70OFITs8kbdwIM8W11OIg6LNXKgi85RHeeO+5" +
       "Zz/5\nc6/80pfOzvwt59zhOJb39ZEXP/rFF37hz+Rfrjy18p7EKvWDlzQOOz" +
       "XONqj77z6MgQuTp7M1Ai/7\nC1qH6bNz8JQP//vnP928fSJHveYdBw71/XM5" +
       "LD2w8Fgt/4j/9Df/Kv3KwXTnKKl5vFA8vK0gX4Dk\n8K/zWzd+71e8o8ZjUu" +
       "Ppw9Ui+6kgu1ltWKm6HJLJ6Uey8aYH5h8M9CdR7Rx5z19G3oVtL2PuPDxU\n" +
       "45q6Hj92EWansejZqh3V7RCLTgLSlUZYDwYHwpcP/XvDU+NXIEh0NdbTRxiR" +
       "iS2vCp35aWz/mRd/\n4+t/+NXVs0cXLsD3POw9F9acXIIHKZthUe3w7jfa4U" +
       "D9BeDdn/nh1VeUkwDwzIPRD/Ez7x/2n9ff\n98Gf+PtHRM2r1TV9cKODitAD" +
       "dnmyalfr9rBdJnU3qpaHyuGa+94LPOrudnGljvDQvda9Vv0/+rAd\nr1bzhu" +
       "XLh/Xvq216eN5U1n277ap3zvxdqF441U10p7oqDqtvVY+TgzPV+Lh38hB4xO" +
       "aV4d58TkYG\n1WvhE1/76b/8qff8bWUEonE9r7FWWesCr0VWP6c++plPvfDk" +
       "J//uEwePqezw8m9//ct3a6503c2q\np0YtHRtksaqTcpJSgWZVLyPtvoAfDE" +
       "+c8/vS6koMHilcevPmrJvg8Nlv3trI0JhvG37Sc9ZsoRTE\nNt5tsYnFmtM9" +
       "JkvlGoFpRKG2NBJ5WDdXnEHqO7u0PSBBXW9ynFxoyiSwDHnLRevU58NVxJIs" +
       "F7U0\nf45obD9Lua2fukhPKKzqBpNYqR8UbMxNXAqEaNrQRxgY2aA4Y5qQn9" +
       "MjqG8wxmY8t+FFm9wqnK8s\nZamzmWm5I8E7hXB8ZIEJ/TGpWK3MH0ztAeB1" +
       "W6K48+x8YkaF5/SDlbNv+rIcMGSgcABJL4i1UEbb\npBV1g3moCU5nLuxDiy" +
       "0wacq2ZzyWrsdt0rJafJ8NpFZ/4U8ip2Rim+GDznQ5bsbSNPf8fCWyFk8J\n" +
       "E9JeIwTBctYOmTsLHkjEnFPR7kjszbE9Lyy9aEjxfNuPWsJyTiLSikAEdjNc" +
       "7rKCIprOdouibLC1\n1qi1R62VtBsv+Za2ClmPiXqWN13jNCIsOGLrmqHkry" +
       "0V7XXCdIUSSKtFuTjbXpZbfGkqbdxrsgkJ\nzB0z0hd7RyawONLGOTVKZiM+" +
       "dBCqwDeBv5kz7kCaCmNepJa7EVbEqyEMk3ywUqf6NEqHqEph0ZZd\nN4UB3I" +
       "dsl5oKjjYewRNy2VbnaDAk2wi8jsa2vBzqBITN+wGxo0QE4SlRReA9GoSBic" +
       "1VRHQDdUiQ\nM6ZLo01HHIIIk7UItXC57ZjYGLgICwQHYx5O4O5YwB28oPLQ" +
       "doy+4gyh7RiZdIkATvBpKObKJNYw\nMu/s1hTD95obWJlpW5ooonWMFYHMQT" +
       "oo9MpZgVqm3FconwY5H9bychqH+8xaTjeJamX73a7sDmmD\nUzqgqhHikAmG" +
       "ONAUJtuQtSN3FKFWYEn9mFEtHQfn88ydAst4aNISsWZRatgiuu0S07r0UJqx" +
       "KD+m\nRu0hzm2W7dmYhQ0Hn2ZZsyQn7coBeNhFZDPwzCVcpG1piVA6ybYADR" +
       "wBog7mub9zeuaaXoaToGPy\neOUsDB/v+ntuQ/p90AEG+xjoNff2jma5ztzK" +
       "BH7uQIUH4/vVYGLJKOUgsqECxVpnSbpccDhmLvEC\nbeuwQ22lGd+SZcTZ4Y" +
       "sS6esLd8kSUFNJLXpqc20jAHt26vU9FxGDYOaOTFvCrQzTOtCgle5ZBt60\n" +
       "XHWYjOdj0kD4aAx0ugumE3sJoNMz3+11UL5JwZG7J/coMUPlQMF0TgjlrbHP" +
       "tFjGJnMWwBLBXuGe\nxYezLUaSfBlTlqjjXXQhYKY8FIBlNB0Aq80Gl9jmbi" +
       "9OWkSFmTQHsp1v8dE+kvKEAds+GMO2GSwE\na2vJq/F46aF7DNA9KB45FCSa" +
       "2AifauO1Ge0Td5VPMtlrkr1OP17sbRlx15GpS9rCdW3MY6fDwF2w\nNIryCp" +
       "Y6DuFzk9Zc1GdjIJykLot7mEjymcKbiDycMn1bgZS4uRUYUuuuR6jCUK0Whk" +
       "1WYk8AZliB\nb8cTugQBJatiJNTdzDb+dGfGuGW2bIPd4E4ikUnHQuCVKWx6" +
       "cgtFxSaoWpAAlSDH5VbklhG0kcdh\n24clvQtAhh3MQbOIxvQy61exAbJoPO" +
       "kSnWW50c0FKAJ8bzspSkBJth2vIze7EzjASkMoc8gddTu5\nvbOB5Xq3jBY9" +
       "tJsjKMR3Ozo6RUOJEYAdqBoDIWELC90ZAxOYsC1J8CZQmi1RaTNqlpZHcppU" +
       "FB5k\nFlZpMrm+cQ1SDuDdGuzHqSPnYJSDNikVoLyZbxxrVkXsLI7GAqusso" +
       "1T8vsymcFR5MLNfqH2qARn\n9JLut/T1AtXlSor9dqr3o0EV/kJDHJD+YAgS" +
       "AJ12k5ZsSLaEYBAY28VuINnafl+C2o4XqsDQ3Ews\nZempJuQrgLcBM9GA+X" +
       "a/gD2ADNv0vnB2PU2QiPZ0AY0Nj55aCRZSCA9MW6QgGT6Np6P2HO+0Cyth\n" +
       "m85QtrMYoGh211/ZnNZdzcU0Hgz6kJGB/ECby6AFL5fMiIjkSrk122cRoqfY" +
       "zpwfb0sTH5YmSpC5\nrnSwvMmhvWkOiVA3pmIFsncCi2otAutRRG84SpkpBb" +
       "QZW0nChHKtvd/t9CByjXamE41ot8uO4UH5\noCt1kgpYA6s5M8ejsLTMIawp" +
       "FfD4taSQSpi02HjNF1AA5XHUT/Mc383oTgAFKjgWgHI534g5tF4R\nve5QHs" +
       "380nVaI3vSHK2qSDK18Ta47odiVxRLwLeG1Bha5g4IRFBuK2Eao0OxLYWbpA" +
       "XRkzCRtnQk\nam1uA2nAMCXHzlYRYXA9bMK4KNn0LI7KfisbLwHV63VWAiRh" +
       "ynQ4J8MMDtPR3CymCt71xvF2MjRk\noIuZIj4Vy27UmpGDEVaCeFeTkk1z1x" +
       "ksJCoDYSjp95INRFjJ3ADn1V1kCss14w9WQYZx2c7xlHSz\nWmIKycw6wd7a" +
       "Kr0SHMAJ4dAQxW0QrE/PmooCu5lFrfPpIhi53cQJ7KmL5qU4XZfkLO8yEx3L" +
       "tlO2\noybIuFPa8iDNFks0kFh5tSGCnSGtN25psQjC5M1ZKxbLeJ1wbaVEJ7" +
       "anBZqCSADgeZOOtLI7aQGH\n3S0VOk4VeSWKXjPd4YbClgthPIiTMip5WI9c" +
       "u+iNJb2pDTgLbY96IF/slrTQKywvHdHaBjXbuWu3\n11EPUkYQtwqIRX25Qk" +
       "uoZdKruePv2wOq09UH+dr1sKFPQ5Nx01hGlrGY952yVDXGngwBfRYltG6N\n" +
       "cnaAz+bmnsqUIb4QKXAtQzOzNQFyZdrutEdTiRJQYQ62Ob0PyFzeTpuAJbJG" +
       "SkFQ0ioGujZOAHWK\nYfN4SBiOCg1DZuYn+80AXytKMrbIvkcRBW8PqN12vw" +
       "E7SeHtdIwURu2RYfab6QhsC4FQbvujvgat\nIp8eYnun1ddH6cwx8t1+kCcm" +
       "6c0Cbx715YSnHIdPIRizluVuMtC08bibx0jprEpj3RyzqT+n0xwp\nR7o4Dd" +
       "thVk4hf+2TeQmS1mKdZHpfK1cG3/W6KxTARSgsdz3fzWdFd9L2CHyqWPOOmn" +
       "KmmTRN3Bih\nMTNDdiSdM4BTtPySo2yRwTmY7QQyNOr5Y5UArBz3F5y/5RZS" +
       "IkqZMphFnRkjzYJ0u+91y2meylIz\n1Zi8s/J3OTzyBoOxS1N01h7E5hoRVr" +
       "QyYhJaYXEpIsO9Con+oqVDnL8bRP2setePOtKy3wXylLEG\n5KQ/asYjoOjp" +
       "na3W7clIz7b1cL6dGXtmMU3wGV4qRsyWhEG3nY2BwBM+1DEZG7LZpDMmIYbW" +
       "83Qk\n9SLNa/Vmi7xJjMEN2O5JG5JzER2LIHsJzir/23Rm4hps+dx2R4Rbcb" +
       "+mAJtJ9CKAfG3oAHMyHnX6\nuqJq1R27yPaGsaD4ZvX6/546LVifZhe3DrnP" +
       "/YroaYGMOiQRh6Twzmnmf14XeMdZwSBuvPB65clD\nnvgx8V9uflT+wmt1al" +
       "Mv/P608UQahO939Vx3zwsKl5lQh2rsWZb9azee0a6Rw+cuVxSuVdu/9IYr\n" +
       "j9X0c8f/+qX+l+8eXU7Pm1UyncU+90CS/vz9ZPTxqj1dtSfqdiEZvV//0S5Y" +
       "5nUqJm84WSWyRhA8\nlL7lgXVShVbr7qnz/fzveL8j7s55Yqje17QukX7XeY" +
       "k0ORzgVFddLiCqRBUp0mP1Xp2y3r6rnhXE\nzLOC2CsfgAbdD9yOMjmxoixI" +
       "9bsntarbtR63Kyjdsfw8cPSpblwoJN595faH062V3OPu3H3l1R96\n5UJZLf" +
       "2O1Xzu9XatSZ1LytfHfOtc+eP/p/JtCHpQ+djKq5mL2ltpre3tD73G3n5A0Y" +
       "88XJ6oBHjs\nlMMbK/ltLPD42c4HjYu6Th2Gj6hknFS6iv8DwiSgwBwaAAA=");
}
