public class T {
    int secret;
    int pbl;
    
    public void foo() {  }
    
    public T T$() {
        this.jif$init();
        {  }
        return this;
    }
    
    final public static String jlc$CompilerVersion$jif = "3.0.0";
    final public static long jlc$SourceLastModified$jif = 1248374057000L;
    final public static String jlc$ClassType$jif =
      ("H4sIAAAAAAAAAK0Ya3BU1fns5kWSxbxJhrwhGCiSgDyGaZzWEAOEbMhOEqmG" +
       "4vbk7tnkwt17L/ee\nTTaxdbCoifahTqWtnUpRqSLSTq0dnKEdS6utThntlE" +
       "5VxilisZSZ6oxSrTClM/3OOfe9G/qj/XHP\n3nvO936fPfYBKjAN1LhbTnbQ" +
       "aZ2YHdvkZAwbJknENGV6BLbi0un7Dj7+m40XXwmjvCgqxmk6oRky\nnaaoPL" +
       "obT+LONJWVzqhs0q4oKpdVk2KVypiSxGZDS1HUGtWB1Lii0U6SoZ06NnCqkz" +
       "PrjPUo2DQB\nrZDvmnvRXSiUMVCLjWEJJSTiwEKkNU+sXvTcF49X5KGyUVQm" +
       "q8MUU1nq0VQKLEZRJEVSY8QwuxMJ\nkhhFFSohiWFiyFiRZwBQU0dRpSmPq5" +
       "imDWIOEVNTJhlgpZnWicF52ptRFJE00MlIS1QzhIQgb1Im\nSsL+KkgqeNyk" +
       "aJGrqdBvM9sH9UpkEMxIYonYKPl7ZDVBUXMQw9GxrR8AALUoRcDeDqt8FcMG" +
       "qhSW\nV7A63jlMDVkdB9ACLQ1cKFo8L1EAWqBjaQ8eJ3GK6oJwMXEEUMXcEA" +
       "yFopogGKcEXloc8JLHP4OF\nkX8/EPu0JcxlThBJYfIXAVJTAGmIJIlBVIkI" +
       "xMvpjkf6bk83hBEC4JoAsIDpXvbCrdGLv2wWMPU5\nYAbHdhOJxqWrGxoaT3" +
       "e/V5zHxFiga6bMnO/TnAdvzDrpyuiQDYsciuywwz48OfTb2/cdJX8Po8I+\n" +
       "VChpSjql9qFioiZ6rPcieI/KKulD+Qr8gOZJWSFM80J41zGd4O8ZHSFUBM91" +
       "8ITYQ1HBSAfkIDuu\nzLC1bCoUAlEagomgQAxt1ZQEMeLS0+d/9+Xe/vvnwk" +
       "5gWOQpCo2gUIhTqPUrw6yTYLn6/k+7yr+5\nyjwOST2KiuVUKk3xmAIyR7Ci" +
       "aFMkEafc+xWeSLOzNTIGgQIxF1eAkMhZHU0aaEkwINzE6eNlQSJ3\nbtiODj" +
       "T1fo/5jtm6mlEXooHl9gjZIiuGd2370tySPAY0lc8sBKBLfEUqB+24NP2rms" +
       "+eOHnl52FU\nMAqlyLyFJHFaobGeTVpahfyudraGCKS+GsVjRImiUpHhGLLU" +
       "zrMiXeI4FNVGga8V+QqD7+RYYIZS\nwyXC0JogGtv+uwniUqyqZvsP/1n/rA" +
       "jgoNVihiaRBBQmFyG+em3r9kM3XgG9IDdBWgqyslRvCuam\nL526rNyjaElW" +
       "qgeZdNlljGmSD8olNSOFFUbGtkkJnTC0KXeHB+pCtlSImGXLUubUgEa8DP6j" +
       "b3br\nhVPLd4W9FbPM00GGCRX5V+HGxIhBCOz/+buxbx34YHYnDwgrIig0jf" +
       "SYIksZLs2iEARgVY5a0FFX\n/ci3V3z/TTviqlzq3YaBp1nAZe4+3fjoK/gx" +
       "qBOQu6Y8Q3iOIs4J2QzYegN/X+U5hCxz+bsh2m2a\n4CAoGzfVzv3l942vjw" +
       "j+QWwQqN5F4vEF3U42eFDFpZPV+w/cf7VsSxiFwf7g+CS0ZVmC3tuQFZY9\n" +
       "zimLTdZxxm3gxizgPveYlfLaoAwW/6rtkav/qv/jLZx/aYKYkiHrTCurqBVS" +
       "bRuYkzUyzsHAqqlA\n6xc5MsIPezO60eWNFeaFpZyhDe6q7KLEpfX7Ln78/J" +
       "+Ot4s0afZjZEG3/rjxw7Zjdyyz/dwUVGmI\nYCibQmcg3nb+mY/uXfAU16xA" +
       "m+Lp1Oyxkw5dVZJ1DN3BfmODisGpMEU+D0LVZfnOIt91KI21xisS\nk8ajur" +
       "+MOSw6RjTd4RKXtr7763fu/U7dKa/iAQQP9JqaurqWS6SEJ5bjkKUBhzgI8z" +
       "gFJLveb2Gv\nTF5Dv3X34rMrb3jwVSFd0JG5MJ589tPDM+1PjbspsMliyn42" +
       "53LWF2DCdJ11z2fm3v74Z2sbPM7i\nHgB9pzig8Adbb3bUWZbLbps0SrWUx3" +
       "o3vrq6tvvIwHO2o3oc/BV+zQKYXv3WRJ548a9Hnzlk09jC\n9Rrw6DjI1/W6" +
       "pX4XXz+ni8MB3Qvk/+q3vjbptrF8X1ZpYs03OCpsZhOqXd1TY3d+8tLBkhbX" +
       "A/W8\nAIXZjOHrqz60uBQ+cm52RV3ZGbD8KLpuApt9KgxDbI4mBrhC8fa+4G" +
       "gXIDXz4q0HL79Gz/I4dZsY\nw27NZMu/A3s65sY3JisKf/KDVBgVQWPn7Rou" +
       "GTuwkmbtYRQGbLPH2oyihb5z/7AsJkO3MTYEG6OH\nbbAluiMWvDNo9l4sko" +
       "jDlFvzXDWzLHv4PCeGuhDS2csEB2zja7tuNQFoZSaRYJowfZWYlziSEEPv\n" +
       "H0rXzrWsT1bzFCjmdodbEZ++mmC2ZRj2txAp4hMpkkMkEZMOWP48YMGQNVB7" +
       "rszqzUAeqljx5BZe\nd7TiF195/UxwQOV5ximt9OdYFg1vlj1Wq53b93TRoJ" +
       "NlMDV3Q30gORKkny17M24e7vWlmG8nO3CB\nfQqifNK6kzzcdPjC8+eHqsOe" +
       "i9vS7IHKgyMub8INXM/Wa3Hg0C+vbD1219DZMVFVK/1Te6+aTv1t\n+iXSft" +
       "M33s0x7edBs+cDGGKr8Jfkc38pPHnsyY7IWbbsBiL6mMJxUj7MwhyY/2sxmw" +
       "eGLV919fg6\nt9/1VoVzh696d3RqnO8Gyk06e9tHkfvwy7vsgLmHomKq6asU" +
       "MkkUt3AGiQzwC7ddBB4vrEzkRzfW\nBStnKOtvEz9eXDp1puzD3nWnLvz/Li" +
       "NWsue6dzRfU4m4RF+IX3pzw5nlvHx4C1mJIDbiK2ctTggs\ngKfcCoNCTwg4" +
       "8/6THifNMyFf8xACL6lpfHufFQj7Kcqf1OSEM1mzdW1usuvZctgfiWLLnTMO" +
       "+1pn\n1k6/Z2fA8z6YvcOW4Qy7XuuCYxVF5fw+wZpLh2gunp7ceM3R7dGdD+" +
       "vq6m553ptBrT++0uLvsrj0\nvn7HlreH3jlqTWCO60mGdvA/0uwgcDBu+9HO" +
       "lszXRh4SA5Sk4JkZxq8IYkvc85y/3lrnpWbTks+9\nkXxg/3tlgdGWR4Sret" +
       "P8dNj7joVdb/WfOHEkmFbIYz2P+hzHjuZ1yz8puvzapZtz2+0/Ej18V9MU\n" + "AAA=");
    
    public T() { super(); }
    
    public void jif$invokeDefConstructor() { this.T$(); }
    
    private void jif$init() {  }
    
    final public static String jlc$CompilerVersion$jl = "2.0.0";
    final public static long jlc$SourceLastModified$jl = 1248374057000L;
    final public static String jlc$ClassType$jl =
      ("H4sIAAAAAAAAAKVYaawj2VV2v15mxtPJTE8mySSZpTPpkB5K6XK5vJQzYfFW" +
       "5bKrXLZrsyuMHrW7\n9r1croQI/iSBiE0kCBCERSAQ5AeLlPwDpEQgsfzJDy" +
       "J+EECJAhLkByAgSEC45fdev9eveyZCsXTv\nu6/uueeec+53zr3nfPYbtetJ" +
       "XLsdBu7edIP0XroP9eTeQo4TXRu6cpJw4MOxivxa422/9wOfu3W1\n9pRUe8" +
       "ry2VROLXUY+KlepFLtpqd7ih4nfU3TNal2y9d1jdVjS3atEhAGvlR7JrFMX0" +
       "6zWE9WehK4\neUX4TJKFenzY8+wjVbupBn6SxpmaBnGS1p6mbDmX4Sy1XJiy" +
       "kvRVqnbDsHRXS6LaR2tXqNp1w5VN\nQPg26kwL+MARxqvvgLxuATFjQ1b1sy" +
       "XXHMvX0tpLl1fc1/jODBCApY95eroN7m91zZfBh9ozJyK5\nsm/CbBpbvglI" +
       "rwcZ2CWtvfN1mQKix0NZdWRTP05rz12mW5xMAaonDmaplqS1t14mO3Aq4to7" +
       "L53Z\nhdNibtz8nx9b/Ofto4PMmq66lfzXwaIXLy1a6YYe676qnyz8ZnbvU+" +
       "Qme/6oVgPEb71EfELTf+/n\neeof/+ilE5p3PYKGUWxdTY/V/+48/8KX+l97" +
       "4molxuNhkFgVFB7Q/HCqi9OZV4sQYPFt9zlWk/fO\nJv949SebH/5t/Z+Oaj" +
       "fI2g01cDPPJ2tP6L42PB0/BsaU5etk7ZoL/gDNDcvVK82vgXEop9vDuAhr\n" +
       "tdpjoL0ZtCtVS2vXuXu2ZVTTTxdV/6bdlStAlOcvu4ULMDQJXE2Pj9Xf/Oqf" +
       "fWQ8+9FPHN0Hxin7\ntHaFq125cuDw9geVqayjVSD+599/9emfeH/yuaPaVa" +
       "n2hOV5WSorLpD5puy6wU7XjtPD6d+6gLTD\nAQN03FQAUADmjl3A6ABMoFIe" +
       "116+DIhzNyLBSAan/OHOvPbpF8e/UJ1dZetnK+4nogHLOSey3XyF\nfW36g5" +
       "94+WpFtLtWWQiQ3vn23I/VxVveOv+N/3jX75xg47JAizhQdQ1EgPMFxw303f" +
       "Nfaf7XUe06\ngD1w/FQGRwe86MXLsH8Aqa+ewjqtvfyQF13e5NWzCFGZ6oiq" +
       "PWkEsSe7FZszt66n2zjYnX85YODJ\nw/jN3zr5/e9p+xbw/mHghQBZ8W1CB7" +
       "LKqa6FJ6ipupcqs15S/BCI/o38+OTrf373taOLMeupC8GN\n1dMTD7h1fipc" +
       "rOvg+9/83OJnPv2Nj3/ocCSnZ5LWboSZ4lpqcRD02SsAAm95hDfee+7ZT/3s" +
       "K7/4\n5bMzf8s5934cy/vqyIsf+dILP/+n8i8BTwXek1ilfvCS2mGn2tkGVf" +
       "/dhzF0YfJ0tkLgZX/BqzB9\ndg6e8uF//8Jn6rdP5KjWvOPAobp/LoelBxYe" +
       "q+Uf8p/55l+mXzmY7hwlFY8Xioe3FeQLkMT+Kr91\n43d/2TuqPSbVnj5cLb" +
       "KfCrKbVYaVwOWQDE8/UrU3PTD/YKA/iWrnyHv+MvIubHsZc+fhAYwr6mr8\n" +
       "2EWYncaiZ0E7qtohFp0EpCu1sBp0D4QvH/r3hqfGByBIdDXW00cYcRFbHgid" +
       "+Wls/+kXf/3rf/DV\n1bNHFy7A9zzsPRfWnFyCBynrYQF2ePcb7XCg/iL07s" +
       "9+dPUV5SQAPPNg9Bv7mfcP+y/o7/vgj//9\nI6LmVXBNH9zooCL6gF2eBO1q" +
       "1R62y7DqemB5qByuue+9wKPqbhdXqgiP3mvca1T/4w/b8SqYNyxf\nPqx/X2" +
       "XTw/MGWPfttqveOfN3AbxwwE10B1wVh9W3wOPk4EwVPu6dPAQesTkw3JvPya" +
       "gAvBY++bWf\n+ouffM/fAiNMa9fzCmvAWhd4zbPqOfWxz376hSc/9XefPHgM" +
       "sMPLv/W17d2KK1N1E/DUqKRjgyxW\ndUpOUjrQLPAy0u4L+MHwxDm/LwVXYv" +
       "BI4dKbNyethOyf/WaNjYwOeMTwk7YjsoVSTLfxbksMLdYc\n7QlZKsVxnxkr" +
       "9JYZRx7RyhWnm/rOLkW6FKzrdY6TC00ZBpYhb7lITH0+XEUsxXJRQ/NnY43t" +
       "ZCm3\n9VN33BYKC9xgEit1goKNuaFLwyjDGHqPgCMbXk8WddTPmR7aMRbGZj" +
       "Cz+3OE2iqcryxlqbmZaLkj\n9XfK1PHHc0LoDCjFamR+d2R3Ia/VWK93np0P" +
       "zajwnE6wcvZ1X5aDBRUoHEQx86kolNE2aUStYBZq\ngtOcCfvQYgtCGrHIhC" +
       "dScYBQltXgO2wgNTpzfxg55SK2F3zQHC0H9Vga5Z6fr9asxdPCkLLF8XTK\n" +
       "ctZuPHPmPJSsc07FW711e0bseWHpRRjN84gfNYTljBpLq+lYYDfYcpcV9LTu" +
       "bLc4zgZbS8StPW6t\npN1gyTe0Vch6i6hteSORZMbCnJtuXTOUfNFS8XYzTF" +
       "f4dNxo0C7JIstySy5NBSG9OptQ0MwxI32+\nd+QpEUfaIKd7yaTHh86YLshN" +
       "4G9mC7crjYQBv6aXux5RxCus36f4YKWO9FGUYrhKE9GWFetCt99B\nbZceCY" +
       "426PWH1BJRZ3iAUci4L0YDW15i+hQlZp1guqPX4zFPr9Vxf48HYWASM3W8dg" +
       "MVm1KTRYvB\n684ag8eLrDFVC5fbDqYbg1z3hSnXJzxySroDgXTIgs5D2zE6" +
       "ioOh28F42JoG/YQchetcGcYaQeXN\nnUgv+HZ901cm2paZFpEYE0Ugc6gOC+" +
       "1yUuCWKXcU2mdgzu9reTmKw31mLUebRLWy/W5XtjDG4JQm\nrGrTNbYIMBKq" +
       "C8NtyNqR24twK7CkTrxQLZ2EZ7PMHUHLGDMZaSqyOI01pi2kJLQWg0kTFucH" +
       "dA/B\nSG6zRCYDtm845CjL6iU1RIAD8H13LJuBZy77RYpIyzGtU2wD0uAetN" +
       "bhPPd3TtsUmWU4DJomTwJn\nWfDxrrPnNpTfgR2ou4+hdn1v7xiWa86sTOBn" +
       "Dlp4fXK/6g4tGaedsWyoUCHqLMWUc44kzCVZ4Ije\nd+itNOEbsjx2duS8HH" +
       "f0ubtkp2hdSS1mZHOIEcBtO/U6njteB8HE7Zm2RFoZoTXRbiPds4v+puGq\n" +
       "WDKYDShjzEcDqNmaL5qxl0A6M/HddhPn63Q/cvfUHp9OcDlQCJ0TQnlr7DMt" +
       "lonhjIWIRLBXpGfx\n4WRLUBRfxrS11skWPhcIU8YEaBmNutBqsyEltr7br4" +
       "eNKcBMmkPZzrf4aB9JebKAER+O+7YZzAVr\na8mrwWDp4XsC0j007jk0ujaJ" +
       "HjnSBqIZ7RN3lQ8z2atT7WYnnu9teeyKkalL2tx1bcJjR1jgzlkG\nx3mFSB" +
       "1n6nPDxmytTwZQOExdlvSINcVnCm+OZWy06NgKqsT1rbCgtJbYw5UF3WgQxH" +
       "C1bgvQhCjI\n7WDIlDCkZCBGoq3NZOOPdmZMWmbDNtgN6SQSlTStcX9lCpu2" +
       "3MDxdR1WLVRAS5jjcityywjdyIMQ\n8fuS3oJQww5msFlEA2aZdUBsQC2GTF" +
       "rT5rLc6OYcXkN8ezssSkhJtk2vKddbw35AlIZQ5qjbazVz\ne2dDS3G3jOZt" +
       "vJWPcZRvNXV8hIfSQoB2sGp0hYQtLHxndE1oyDYkwRuiabbEpU2vXloexWlS" +
       "UXio\nWVilucj1jWtQctDfiXAnTh05h6MctimpgOXNbONYExCxszgaCKyyyj" +
       "ZOye/LZNKPIrdf7xRqm07I\nhV4ynYYuznFdBlLstyO9E3VB+AuNdZfyuxg8" +
       "hZi0lTRkQ7KlMYHCsV3supKt7fclrO14AQSG+mZo\nKUtPNVFfgbwNnK2NPo" +
       "90ir4HUSHC7Atn19YEaYqM5ujA8JiRlRAhPeahUYMSJMNnyLSHzMgmUlgJ\n" +
       "W3cw2c5iiGbYXWdlc1prNVuncbfbQY0M5rvaTIat/nK56E0jGSgnsh12PG0r" +
       "tjPjB9vSJLHSxKdU\nritNIq9zeHuUo2u0FdOxgto7gcW1xpRo09M21ksXIx" +
       "pCFraShAntWnu/1WyjlIg3R0NtiiBl0/DQ\nvNuSmgkAVteqT8xBLywtE+tr" +
       "CgAeL0oKpYRJg41FvkADNI+jTprn5G7CNAM0UOGBAJXL2Wado+Jq\n2m5hcm" +
       "/il67T6NnDem8FIsnIJhFY7ITr1npdQr6F0QN0mTswFKG5rYRpjGNrRAo3SQ" +
       "NlhmEibZlo\nrSHcBtUgLKUGzlZZ92ERq/fJtWQzkzgqO41ssIRUr91cCahE" +
       "KCNsRoVZP0x7M7MYKWTLG8TbIWbI\nUIsw1+RoXbaixoTq9ogSJlualGzqu2" +
       "Z3LtEZ3EeTTjvZoFMrmRnwDNxFprAUF353FWQEl+0cT0k3\nqyWhUItJM9hb" +
       "W6Vdwt1+MnUYlOY2Y6LDTOqK0nczixbz0Tzoua3ECeyRi+fleiSW1CRvLYY6" +
       "kW1H\nbFNNxoNmacvdNJsv8UBi5dVmGuwMSdy4pcWOx4u8PmnE6zIWEw5RSn" +
       "xoe1qgKWMJgjxv2JRWdjMt\n+mFrS4eOAyKvRDPiooVtaGI5FwbdOCmjku/r" +
       "kWsX7YGk17UuZ+FIrw3zxW7JCO3C8tIeo21wE8ld\nGxGjNqr0UG4VTOfV5Y" +
       "ou0YbJrGaOv0e6dLOld3PR9QjMZ9DhoG4sI8uYzzpOWarawh5ikD6JEka3\n" +
       "ejnbJSczc09nCkbO1zQsyujEbAyhXBkhTaQ3kmgBF2YwwukdSOZyJK1D1po1" +
       "UhpFk0bR1bVBAqkj\ngpjF2NRwVBQLFxM/2W+6pKgoycCiOh49LXi7S++2+w" +
       "3cTApvpxOU0EN6htmppz0YEQKh3HZ6HQ1d\nRT6DEXun0dF76cQx8t2+mycm" +
       "5U0CbxZ15ISnHYdP0T5hLcvdsKtpg0Erj8elsyoNsT5gU3/GpPm4\n7OnrUY" +
       "iEWTlCfdGn8hKmrLmYZHpHK1cG3/JaKxwi12hY7tq+m0+K1hDxpuRIsWZNNe" +
       "VMM6mbM0Md\nBvMhtzNbGNzhJsCC9B43sAI8YjpuaEwyA1/a3ZkaGQjDjmnE" +
       "KzURyZIsl9TUNCyRonyOZiAk9OuI\n04GlptHHys4mVxmxtdx311k23BQC3j" +
       "Z20E4KqW3TzPywq+o0uupqhDaC8qjjtdtomA5iDoIaGZUn\nsd2o53534sb6" +
       "BDyrIk4cggjpEVrehxvZzlRHgwzqTRg3KderbYvtt1mnNXWkIsLIjZOrWHsP" +
       "o27s\nh6LCOQnUA0+qwoTR1DU1Qly1WJAHLjBtbnftQNAUWDSYydjxcIXclM" +
       "0FtC0ndiYh+xILs7yUQykt\nm1ADHtsIJvRovg5e/99TpQXiaXZx65D73K+I" +
       "nhbI6EMScUgK75xm/ud1gXecFQzi2guvV5485Ikf\nX//LzY/JX3ytSm2qhd" +
       "+f1p5Ig/D9rp7r7nlB4TIT+lCNPcuyf/XGM9o1CnvuckXhGtj+pTdceaym\n" +
       "nz/+1y93/vru0eX0vA6MmMU+90CS/vz9ZPRx0J4G7UbVLiSj9+s/2gXLvE7F" +
       "5A0nQSJrBMFD6Vse\nWCdVaLXqnjrfz/+O9zvi7pwnhup9TasS6Xedl0iTww" +
       "GOdNXlgilIVMdFeqzeq1LW23fVs4KYeVYQ\ne+UDaLf1gdtRJidWlAWpfvek" +
       "VnW70uM2gNIdy88DRx/pxoVC4t1Xbn843VrJPe7O3Vde/aFXLpTV\n0u9Yze" +
       "deb9eK1LmkfHXMt86VP/5/Ko+g6IPKx1YOZi5qb6WVtrc/9Bp7+wFFP/JweQ" +
       "II8NgphzdW\n8ttY4PGznQ8aF1WdOgwfUck4qXQV/wfWMOgPHBoAAA==");
}
