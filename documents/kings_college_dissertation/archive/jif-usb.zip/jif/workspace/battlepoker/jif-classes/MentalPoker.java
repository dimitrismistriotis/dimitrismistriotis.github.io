import java.io.PrintStream;

class MentalPoker {
    final public static int NUM_COVERED_COORDS = 10;
    
    public void play(final PrintStream output) throws SecurityException,
        IllegalArgumentException {
        if (output == null) throw new IllegalArgumentException("Null output");
        output.println("Playing battleships, with each player having " +
                       NUM_COVERED_COORDS + " covered coordinates");
        output.print("  Initializing....");
        MPElGamal p1Crypto;
    }
    
    public MentalPoker MentalPoker$() {
        this.jif$init();
        {  }
        return this;
    }
    
    final public static String jlc$CompilerVersion$jif = "3.0.0";
    final public static long jlc$SourceLastModified$jif = 1246795259000L;
    final public static String jlc$ClassType$jif =
      ("H4sIAAAAAAAAAK0aCXQU5fnfzUUOzEFCAuTYYCCcCSAiEKyGXASWsCaEaqis" +
       "k9nZZGR2Z5yZTTZB\nW6iVQ19rrUI9qqKiKFIV7UOL1eJR5BW1L1rF46Eo1v" +
       "rwqFIUedVnv///597ZxR68N39mZ77/+7/7\nGnZ/ijIUGVVczofr1CGJU+qW" +
       "8uEAIytcKCAKQyvhUZB9ZeMdd/1p/kcveFGaH2UzMbVflHl1SEUF\n/suZAa" +
       "Y+pvJCvZ9X1AY/KuCjispEVZ5RuVCrLEZUVO2XAFWfIKr1XFytlxiZidSTw+" +
       "oDTQKjKLAt\nkzxVrkA/Rp64jHz6Do0oShEBpiTNvnvW2D0/2luYhvJ7UD4f" +
       "7VIZlWebxKgKR/SgvAgX6eVkpTEU\n4kI9qDDKcaEuTuYZgR8GQDHag4oUvi" +
       "/KqDGZUzo5RRQGMGCREpM4mZypP/SjPFYEnuQYq4oypRDo\nDfOcENJ/ZYQF" +
       "pk9R0ViTU8pfK34O7OXwQJgcZlhO35K+lo+GVFTl3GHwWLMMAGBrVoQDeRtH" +
       "pUcZ\neICKqOQFJtpX36XKfLQPQDPEGJyiovFJkQLQKIlh1zJ9XFBFZU64AH" +
       "0FUNlEEHiLikqcYAQTaGm8\nQ0sW/azIzPv22sApn5fQHOJYAdOfBZsqHZs6" +
       "uTAnc1GWoxu/jtXd1H5JrNyLEACXOIApTOOkx7v9\nH/2xisJMcIFZ0Xs5x6" +
       "pB9pt55RWvNH6QnYbJGCWJCo+Vb+OcGG9Ae9MQl8AbxhoY8cs6/eX+zgOX\n" +
       "rN/FfexFme0okxWFWCTajrK5aKhJu8+Cez8f5dpRugB/gPMwL3CY80y4lxi1" +
       "n9zHJUT/FcKVhS8V\n5S/noiojBMS1nFwH3qiiMYrM1juexvH+/EGPB6gsd/" +
       "qIAOa1RBRCnBxkdx7785Uty7Zs9ho2o52s\nolwLTuTxEFyldo6xCEPYoT95" +
       "tKHgFzOVveD5PSibj0RiKtMrAGN5jCCIg1woqBITKbSYo+7Seb1g\nTWCYQQ" +
       "EQUceW0ICMJjqtxvSudhI7WG7dvA60tbLlVqxgrJBijJ2SBuJdS2nLm9p16d" +
       "LLNk9Mw0CD\n6SBGzMlEWyRzwR1kh54pWbhv/+knvSijB+KV0syFmZigBpoW" +
       "i7EoBIFi41EnB/Eh6md6OcGPcmkY\nYMCVdWfMkliyR0WlfjhXcw8Bw9eTXS" +
       "CGXNlEgrdVgcnWnFkEQTYwpqTj3q8mPEit3Cm1gCyyXAii\nl7khOOuc6o7t" +
       "c04DX+DAQK0KtOJ4UOl0YJvPNWgOqqKJCfHAeUiDHuswJ+nAXFiUI4yA0egy" +
       "yVH7\nZXHQfEJMdjReCqn14qUGK9XBEYmV/2zftOTDQ1Mu9VrDar4lzXRxKn" +
       "XSQtMmVsocB8+P3By4ceun\nm1YTg9AsQoXMEusVeDZOqCn1gAGOcQkYdWXF" +
       "N22b+pvDusWNMbE3yjIzhA0uvuGVilteYG6HYAIO\nrvDDHHVkchLSD8DrTH" +
       "JfZ3kJXmaeb5poo6KAgiC2LCrd/P5fKl5eSc937gaCJpibiH1BSuRlYlRB\n" +
       "dn/x1Vu3fJPf5kVekD8oPgy5m2chQZcnmGWT8RbbJk5LfTpwRQJwu/kax/tS" +
       "Jw3a+WM68r7514RX\nm8n5uSFOYWVewlxpkS9TFZeCOHG2IyfITFQRoD6gPr" +
       "KSvGyJS3KD1VawFs4mB+rgJsvmliB77vqP\nTj722t5a6iZV9h0J0NUPVXxe" +
       "s3vNJF3PlU6WOjkGAijlGZDXHHvgi2tG3Uc4yxAHiTtVWeQkQepl\neYmBFK" +
       "Lf4WpGJlgwIxcCUWUJutPQN2yPMWLFaRZTY2HdHsaMI+pWipJxSpBd8t6z71" +
       "7z67JDVsYd\nGyzQs0vKynwnuBziWIZCznYoxNiQRClA2WS7hK00WQX9xobx" +
       "70yfcf1BSp1TkW477nnw1I7h2vv6\nTBdo0g7Ff9rclPVDKENNZf1s2ua3T/" +
       "7unHKLsogGgN9BAkj1gddGg51JbnJbLKqqGLFIb87BWaWN\n9y/foyuq2dg/" +
       "1c6ZY6eVv9l5dz/9t10PbNdxLCF8dVh4DJB1nqSxv4isF0j0ZYdkBbL/8mu/" +
       "miRd\nWLZfWmjCyddZNLTiMlaP7pHedV8+d0eOz9RAuZFXy2151bYtyHrvP7" +
       "ppaln+myD5HnRWP6O0R6Fi\nwsU2J4MqBGvuc9Z/DlTDT3ff8fVL6jvETs0k" +
       "hndPjCfSv4qxZMz5rw8UZj5yZ8SLsiCxk3QNncgq\nRojh9NADVbjSpD30o9" +
       "G29/aKmpaPZmIsdyZGy7HOlGgWW3CPofF9NnUiAlMAEi2DayFco/GFHxbh\n" +
       "ZUycFGM0s2FC6kgA5uSi97fvOLVh03wvzjwZA5hgkEWBCdcRw+3Oxt1bK3Jv" +
       "Onod0R9gzsFIeXLo\nJLJOoVkxTQWS+ShDdDINUqRCuqc4CKGje3mwacWqls" +
       "6WZvi7orO5S7HFfRJQuRCtw0dyz9nsOzdc\nTBwum2gZGjVS61VBuY136L+p" +
       "APJsAqh2EQD1AANsQhIwm4PgZTBuetOgzVESnvgN7OVw+ZIR0WQD\nq0gG1u" +
       "YArkqFkwSxhEKOj4CzDGj9zw2VOz587FhnsdfSJJ6dWJdZ9tBGkcpXwiGpOt" +
       "UJBPr56dW7\nf9z5Ti8NzkX24r8lGov8feg5rnbRz99zaR/SoGYgdRypdAbi" +
       "ieall0LILIXKzUKmIlnTSCjbdPEX\neRuZ5y/Vg+S1KspWRWmmwA1wghnGnE" +
       "iWkx5Zd8m7MotC6f75ZW5xzD7psO8LsofezP+8Ze6hD/9/\nrYHmDG5dQFVK" +
       "JoKs+njwxOF5b04h7mUNKzkU2UpbcKk2TDAXrmK48vFlMUGj+r4VL7Wu9apH" +
       "ExT+\nrRgYa+Fa4oIR5DnemZMb5T6tLNxyyfhHtz9b8qkXh0Uvy+MK0zmYEE" +
       "PW3sLGZEySONkqQ+8Aj+/6\nCSMLbMStcCFORZfh0yKiLPXzrI9Q5xPDPtqy" +
       "+Bi5LxaBTtgnxlQppuI3dNLikwRmyDelF5/MhXxM\nrzjA+XqHfOsCs6sX+g" +
       "CIU32BOXB71VSjfjDyfxMTjYpqQtl5fMVn+4cl7qBu1ucT6m/Gy23/uV7w\n" +
       "cid1su14uYeg2IGX+/5bxImptTu6NgpFFA1Lc15/6cVXm+MP6QxApHFveLwE" +
       "nxf/fIQsoId0LFHy\nAyHLprlufU5CjaeRodnUsT1zX47evPn3Oh0LKKfUy+" +
       "8l617bI8huVMGOzDIviUknZJanLJnlqYTM\nYjyBsOukfDlYiqWDCrJP7Oye" +
       "8d66KZ/RsFvuBq+DNgdQ19PFB1pJAD4L21yTGJHEKKdFmMm0jDXY\nOQ+uNn" +
       "cPnWS2sk2iIEBhA52ZUtMdjYghPszjeQ5UR+srfjVy/W3ruyltM868x3w+bj" +
       "Faf2jNqUpC\nq4fFY1CzXzfBaNte6hzlLGGUfjj/DeFwz9Yj0yrp+ZbmXnu/" +
       "r/mardueeHwunfbkAZsFF1xIhmhe\nR1bHoljkLooa1yYJT54ttf6kE+sHRt" +
       "5a81fCzmgyl9ZDlIrGWXq/gPUVTcDNNioWuFNR5exqAY01\nWGy4t+/Ut8/s" +
       "+lLvUceZVNuODLIvZPWNWrhj3sk0UoBZJj5lFjLxGMwy/9VqispkjFjKibDB" +
       "TRFc\nlfqw0sINQhK+eculxsT35OU0vFwBYcAbmE0gNmp9yRbI7YYaSKyisc" +
       "NZfzUkU6hZf5naX5zMEfCf\nERtYczKw18h62ADG9dyM5Nwf/57cz8G376Zg" +
       "tDUV7W3xhC7ML7KMYFpD8VWLz9t5hNtDZ2cpmy7H\nzgPb+ube+fDDGXpUDd" +
       "Os4qEsnEzkj8RvKW4PrinzEl524uUUXv5A8TrLsa5Yr6JaviIUL7piQTe/\n" +
       "4iIaFKYaTHBxtY44prbVuW/b1I8Hps/66e20cuplFFJUZIFUFAypIl/yT1IE" +
       "F7X/HEMzWVrLko0v\nFeXjcKF2qTIHJJBhfZXC983EA3sS+Xix3gFB8H1L8B" +
       "Wr2nSRF+ssUGTMnSCMIPvkkRM3frZq+Eqi\n1XxCP8mFXZSTyXZP1zbVdNnh" +
       "Gmzf1FzFB4HvaME/vvrJ+9PJxxJdUtbZ63JGSpi94vAMzzOy3nrm\nubGXjU" +
       "AkakU5gsiEWhkyzgZx9cuc0i8KobikRey8wVE4fhsFjelp4zRvI3LGD7+DxY" +
       "M0T/PkpOhl\njUmvtZ/1+J0Rx/ALj8farPwPQ5ckMHFHwkmunNbs7xpezT2y" +
       "XBvN9fNKzSySRF0UC/LHtJModJrY\nVMoyzFHHZ2lhXDPjki6OjeEvuS1xli" +
       "MDW2rMtTZjpt8Y3SCd3TrOd8s0zRakqKk8082aSr8PJHny\nvIEdz0uWumAn" +
       "AAfJ+mLKwgAjuCAZghEb2KJkYK+Z6c6M2z9IhdiZoFpSsTFiA2tLScVxBxXt" +
       "qRBr\nM0CIPRPMqVGCUh3mUp1En1hJ03R8Ey3TKij1+hihUeusDLQk+D3m9M" +
       "T0AZEPIf27CF7NhsDsSiz9\nZWNM7W8yGu0gG30yMpR2YFwd8Zsco5KgHbhj" +
       "4JanWT7+4lroFA75KlPhWhvqd7esvkGKzmrk7d9n\nrF5mqq5UC2SuZ1kMyN" +
       "yBx1wVKXccjzudDXf4k12KhQRnC1qcLZjgbEF3ZyuBa1KyUuT7OBtGMP7M\n" +
       "dViJJi/3OszN2calQux0Nl8qNkZsYBNTUuF0tppUiNuoh6goi1ZHtfghLXnw" +
       "8n1CNkZQS9HgpdV8\n2m4+XUodC9/6z+BIGOYivHRZDvesch6OH16Ml9Vxcs" +
       "waclbc/p8GJEn3fcsEmo7MLZO/ROQOoeNs\n0YASq+rkbnK+FmeT7zget4+r" +
       "8YgvRv+TUZD9RFrT9nbnu7u0T1JJyyFzx8W/Xe2LX7fyl/SLEisw\nw8P4FC" +
       "gks+gUSYs11pmrE5uOiz/6evjaqz/Id3zrw2u+JrUBa6GegAffrxrd8Mayff" +
       "vud042jZHr\ngI19W2M3d8qXWV+/dOJC1xBGxE0l+G+1nQqwEyYAAA==");
    
    public MentalPoker(final jif.lang.Principal jif$P1,
                       final jif.lang.Principal jif$P2) {
        super();
        this.jif$MentalPoker_P1 = jif$P1;
        this.jif$MentalPoker_P2 = jif$P2;
    }
    
    public void jif$invokeDefConstructor() { this.MentalPoker$(); }
    
    public static boolean jif$Instanceof(final jif.lang.Principal jif$P1,
                                         final jif.lang.Principal jif$P2,
                                         final Object o) {
        if (o instanceof MentalPoker) {
            MentalPoker c = (MentalPoker) o;
            boolean ok = true;
            ok = ok &&
              jif.lang.PrincipalUtil.equivalentTo(c.jif$MentalPoker_P1, jif$P1);
            ok = ok &&
              jif.lang.PrincipalUtil.equivalentTo(c.jif$MentalPoker_P2, jif$P2);
            return ok;
        }
        return false;
    }
    
    public static MentalPoker jif$cast$MentalPoker(
      final jif.lang.Principal jif$P1, final jif.lang.Principal jif$P2,
      final Object o) {
        if (jif$Instanceof(jif$P1, jif$P2, o)) return (MentalPoker) o;
        throw new ClassCastException();
    }
    
    final private jif.lang.Principal jif$MentalPoker_P1;
    final private jif.lang.Principal jif$MentalPoker_P2;
    
    private void jif$init() {  }
    
    final public static String jlc$CompilerVersion$jl = "2.0.0";
    final public static long jlc$SourceLastModified$jl = 1246795259000L;
    final public static String jlc$ClassType$jl =
      ("H4sIAAAAAAAAAK16Wazk2Hledc+mqRlpVskDSTO6Go2VHlBuklXFIksTPbC4" +
       "FbdaWFyqKA86LG7F\nncWtSCoSohePYyNxAkuGEySKEzgwkOghC2C/JQFsJM" +
       "jiFz/ECJA4iw0nQOKHJEjsAEkcVt17u2/f\n7rFi2Bfguefy/Oc///L9/zk8" +
       "//3+7/Sey7PeRZqEjRsmxf2iSe38/tLIctsiQiPP5e7FAxP+G9Bn\n/u6P/u" +
       "Jrz/Re0XuvePG6MArPJJK4sOtC770c2dHOznLcsmxL770W27a1tjPPCL22I0" +
       "xivfd67rmx\nUZSZnUt2noTVifD1vEzt7Lzm9Uuh97KZxHmRlWaRZHnRe1Xw" +
       "jcoAy8ILQcHLiw+E3vOOZ4dWfuh9\nq3dH6D3nhIbbEX5GuNYCPHME6dP7jr" +
       "zvdWJmjmHa11OeDbzYKnpfuD3jocbv8R1BN/WFyC72ycOl\nno2N7kXv9UuR" +
       "QiN2wXWRebHbkT6XlN0qRe+zH8u0I/pEapiB4doPit5bt+mWl0Md1Ytns5ym" +
       "FL1P\n3yY7c6qz3mdv+eyGtxbPv/x/fmL5uxd3zzJbthme5H+um/TOrUmS7d" +
       "iZHZv25cTfK+9/h92Wn7/b\n63XEn75FfEmD//AvKcJ/+odfuKT53FNoFjvf" +
       "NosH5v8ef/7tX8N/68VnTmJ8Ik1y7wSFxzQ/e3V5\nNfJBnXZY/MxDjqfB+9" +
       "eD/0j6x9s/87fs/3y39zzbe95MwjKK2d6LdmwRV/0Xur7gxTbbezbsfnWa\n" +
       "O15onzR/tuunRrE/9+u0d/nzWve8cHqK3iuiHRdGuEwCO7vve07ReyPPTPDW" +
       "2/o0/5PHO3c6KT9/\nO2LCDl6zJLTs7IH5C7/5z/40xf/ZH7/7EDNXKxe9l2" +
       "7w7N25c+b1Q49rfDKhdUL6f/l7H7z6538k\n/8W7vWf03oteFJWFsQs7xV42" +
       "wjA52taD4gyR127A8YyCDkIv7zo0dcB8EHaMzujt9K6y3ru3UfMo\n1tiuZ3" +
       "RQ+MZ43vvuO9RfPjn45JA3T9wvRevMG1zK9vL76w+5P/Xj7z5zIjo+25nxpM" +
       "l7P5j7A3P5\nxqfnf/N/fu5vXwLotkDLLDFtq0sTjyY8gIZfnP/c4H/d7T3X" +
       "xUaXHQqj828Xau/cjo3H4PzBFfaL\n3rtPhNrtRT64TiMnU90Vei85SRYZ4Y" +
       "nNdez3i32WHB+9OaPhpXP/U79/+fN/r57f71IEkURpB7/s\ngrE7WY3CttJL" +
       "/Jyai5NZbyl+zlb/nf1o9tv//N6Hd28mtlduZMC1XVyGyWuPvCJntt29/zc/" +
       "u/zp\n7/7OR18/u+TKJ0Xv+bTchZ5ZnwX99J0OAm88JWTvv/Xmd37m/b/y69" +
       "c+f+MRdzzLjObk8vrbv/b2\nX/onxl/twrkLsdxr7XMo3T2vdPfM//VO8S5Q" +
       "7p+g2HnSi00vNc7J5/61AKcWOPe/cgrC8+RefTV6\nQujtyKJPuf7aT9HuG/" +
       "/jl7/Xv7iU8zTns2cOz+dP5rbHJj4w23+gfO/3frX4jbNpH6HoxOOd+sll\n" +
       "VeMGZLF/Wb32/N/5a9Hd3gt679Xz/mTEhWqE5cnwerfD5MTVS6H3ycfGH98t" +
       "LlPjI2R+/jYybyx7\nG5OPEknXP1Gf+i/chGFniLe656vd88nTc3r56ql5rT" +
       "4nmkvMnJ3Ddluia2ev/4ef+/nf/fZH2N2T\nT5+rTgJ3tnj1Ed28PG3sP/b9" +
       "77790nf+3U+ezd5x7p+YfvW86JfO7Zcv8fZM0YnsxZcuv9eBLz+f\nE+rOCH" +
       "NFfEAsVEqiyO73QiLXT3FZB5moy/bV1Xb0F9/5+d/++78pvXn3xp79pSdj+c" +
       "acy337bJN+\nWncrfPEPWuFM/SvAF7//Lek3dpfp6PXHczEVl9F/bH7Z/hN/" +
       "8s/9+6dk82e6k8U5qM9GGJ+aL3am\n7qwwvA/dh05/80+x0qmPn010aqadeX" +
       "7ID833rlOG2p2kuh3vvS6SrqPqhkcuDxxPWbXT9lOPyISk\nO5X85G/9hX/x" +
       "U1/6t53k3LV3T9Rf6zLDu9w//dfnP6RTI3bnlpMI66TMTFsw8kJMLK87ZlkP" +
       "pSDT\nyyBlim5/TZ4qQfFGOBvlLH79w0MGsVkpiBM7raIsWoom8FLebgnCJN" +
       "a4R/ENs8HXWk4YlHHw8mAS\n6zojDXSk0WVZn/a1saeu4EmWKezkcOA9nmZV" +
       "VFkIsM1JyFSDBTijR2MqgavseKBZxbbUuAJBEJmg\nei2NsflwEukoCgIoiP" +
       "aZWAc9n1UYVTXbxMlgguEU4KBhJYWzTWHyBM6vmmqv6NOJbouWBcIpGJiV\n" +
       "TTPGbKC04k51wlkIrymF7oN5qePGFkgrjqj0yQbGtyBfEr6Xp5SqI1KpEplA" +
       "6Yq6GGxwWnNYPoM3\ndFOEtad71lo+Agkpr3ifF/CiH7S1mgU4KKXjkT9rx2" +
       "QCJes9NU09eV7FlTYgIXAQltt9xaEKOXJQ\nldVDzd7VvMtL4NqtcHczttUg" +
       "lSmlPwo6W5EkbxpUKZdb3ZUwZkXODHeUKJUH8geS0ZU2QSRpxYgM\nIVGpOI" +
       "r0Jl2Ca39JbzvAr7aHUdKkEpn0SWdhUnMO1LcrOg0mEqR6soKlDj8cLdDF5r" +
       "jiXFMP94sh\nwgNhAjAqLYdDZnbUBFHEmWmmJivSlopZqph632YJ/rBY0VyR" +
       "bobjDe8Iq+WKXFIM13hJRXPBSljx\nbLiHW26yoae0roxH+AyilXlIUTNP8I" +
       "KDucVXssFEWH8F5RpotGy7rAaDHE9jxFnNFtwWtxbOVM8P\nMz0flzIemzCj" +
       "JXUJ+sXGgmcIl80bgcKJzYLFU3mxCGq0mvRn4KD2ck40WVqHNjlSj9PpJC0Q" +
       "RNKq\n+Wy8irc7jiE0jkgAdQcsTIaZ4PZEXIUYvqv3yRYz8zFob4DWXWz62R" +
       "ykHbumIxtKglqjNUI2/IxH\nDH7PlRhA2C3mIFYqle4UdJfiURgSWwxqRh00" +
       "4HjSzjhFBmmTV/drTO0jazBOvMSfims4po+z4cHz\nxG0mwn4XytUMAClmOR" +
       "27uQUeWHxhwNJUIuJpHVg1imKIUjSonk/2ySBBBnk/CY+CXMo1RTehlYxr\n" +
       "glpuE3mCFPzMpduFWtkkslx7Ox+SPL4QM5yZIz5BsC58TA5TVuZ3620CoGt7" +
       "B7t9WSO2qxW1Ukxb\ng1hC5PxDUVfr0tqzqMagVoWPoWInhOqhdjNu6vncYD" +
       "0tOWs9iIVoksJjSxDmwUQ8QgTZH6+nTCuG\nlNZI7VGCgz0ySrXdvgKBIK7W" +
       "nj8FeBXKGzrSPXeaJpqHUsmUpb0RTMVTkNqPI2vcuWVpRsG2vxUJ\n1dIcMQ" +
       "i9RoK00PH3G/OITY8TW96sCWbT4cnNLNU1Yy2mA2olb4/pQfaHByxaUl4xJC" +
       "LYJZpmg3te\nP0SD/WJRmuMELUxoRG4AEl/xEF8suJGyCKEtVy3nmrvo0hNH" +
       "ODPcVjxyVuZHDojxDe0p7KjBIdtt\nGnWG9vXNbOVQnGj5kk0cYnh0UBh+sp" +
       "lS20gFB61TLGRyBYvlRM1IIxuF7Uaq+XizXhVipOaJOcWA\n5XDajEy7jPsR" +
       "vJXdCZ6vko1Ilblqk/riQMSwizMLcxVsLW1DzweDXZejyDLX5uKOGjY+2+5x" +
       "qKxK\nRvXCwt4y49kWZxf9rCLJ2UwNzL2wJjEyk2ecow8DbhMZ9g5Jk2TM46" +
       "5HDAQis8Al4vAhYq/NyRB1\nDYJLvZ03g6frUgq3oTTtWzFYw2o5dLilgwSq" +
       "HZBYsnQbJBqY+5VuxhGjyZi023EBIjhyepRW3LEE\nA6MGizV3HBqAJo6xDE" +
       "XgkbTpR1iMlGt6sdVU+xjWabCeyLRuE4sZM2Abh5XplZSQY3eZ8euKabj1\n" +
       "kCdh1TjS+SiaApnL5VUUelMUrQ7Lvuyjg0GBGGNPVyd7iIPmylLd1HY+rOYc" +
       "PVyGylhb+AGDe37I\n6ORmNqtcb1AwQ8UcNTU+8+RC1exVsLLTsG9voynNC8" +
       "5ISxkudI9sbRKKpnBlsVzNB81S1ATakHR5\nO5hZs9wQWSDVvJSr1+nUwopx" +
       "i8JoO0Y5Us23Vp9p2lUOVXwTH+Ny2noaqxNtvE3qubeSiBAfaGt0\nz0OQtt" +
       "pM6mRXo1DjmE5n9BSWA22EonF8hFl0P6iqcV+eWgnkorQzycxwqZI8NZ/rDp" +
       "wPSmMog2gZ\nz3ghT1zGnU+meODDrmUxLgJzu5jbCfzhwAg0u8PQqWZo8/6k" +
       "AZ2kKQ8DywVhc6xvu62mmoSI1YKT\nAoaWu7lVCwSNWep+RHJTOD6s62rk5T" +
       "TkQ/rWCqY7AcSiEow8yeprgu5okU80lqXPBdkTQ2OJprNu\n48YAC7IX7UTC" +
       "S53eNAMYgXfbopllVUfQfUTEQNSQyCyWtOV4AUlj2usfc2XAjcTDlKlKc6KD" +
       "ZCiT\n8tBxMEcVxn5FyTkU7GNr6RPOuhodal1skeyIKbrfHTCwtZB7RB0MV/" +
       "PYdA99KfH3kzlOqjt/nZJD\nKJkwgwlo8FFqLPWIza1GZxp0tggZV9OGxDJx" +
       "6Mk8Vjw8FHHKG5BGQ5sJyNCzerfv60pj0owI5QOa\nGAcu3iHYm6BOtRDUPT" +
       "Q8Vq1/1HFk7waUNiUsUzoCw0VdwDt+yFWLOLEgaeK2Oc3aGyHpcwK3SNSg\n" +
       "llfaGljvSYtk58pBIsqDOSJ4xreH0dEwtUOYjzW98tAkWyBrdEY7ErcqJaI4" +
       "QlbTTuJ80VpmB41j\nGQ1cnfHV9RhWp+UWHo4FIMWXXI4f9gNqRcI4Ps9Xe/" +
       "YYjZauLk+7b5iF26rUOq7cObpQj4DOdnl1\nRfYPkMvA5RbPggMdHNf1nuIX" +
       "/ohoScaftMeBumgRDKX3cW45a44bWxpn6ZNiygRmujl6TLooFG66\nzJBuBO" +
       "07kxaRPWzeBpvBKMNCJqkwx3aRLN5J7WTSGt1RJ2G2riU1qYXvPM82whASWI" +
       "Hd8K3CR2wY\ny2vC31lLatO3pbI7RYKqC6xhPk81SYuiIw4f3X3MxJSnBTWi" +
       "W1iEiklBjB0U0TWkbkk0zRdYFxmO\n3S4BTLfHexKcgP1sO4tIBrFWtMpzCZ" +
       "8DsX+sFzSyg0Z7NFLmfBsoAyXdmXwwkEl8k0X8CKvoUFQY\nH8hGqoBq5cRI" +
       "Z1QtA/1McrcGQBujhJUQMrYjXdwh8rgQ5nXTOPtZ0U522CHY7CGlagCRh9po" +
       "S1FL\nbZgLjE4168U8OKwADPcBcNwn1qKwE9eFSdALSXf2UMN7wnLTZuxkhd" +
       "RLclkcGmDqIUJtTOXCjetw\nlaYlO7Tm3WnqKHURZYc0Aor7TS32s9bHgc1h" +
       "5ixyIh/nG8AlWGU4mC42UxRW177jk41Ti7K/TQ+r\nIkQcUY2BkRmih2kJl6" +
       "Y8jkCmGQzBUkWPfdOz4LyER+XWdgcsswFAZFezUVrI5XjupjSNw4IJI+DY\n" +
       "VDcRIC7HqxpPZ3RlC0cqrh3QYVd5wlqQQM+aPt7MhDQLS0dBCN+wpcSKlVyG" +
       "280ItatlPFzsIYHn\nHaUBsHAMozsW25eqyCxakq08JYh1zogFLg4PW1nsb/" +
       "1mmi/KwCHDrXfQSCLjluiisTFrPOZ1UMrp\nqpweAHLuWt23x5KewimHkyNh" +
       "ADcyw80onrfoSIwgn9xs+4sVUHb5Yxlr60EeDDyWmu5xZKArRbfJ\nb939Mm" +
       "99e4UoEpBnjq82oDbMyiYsRGyM1cMjsPNpwxn484OSEv3DyKG3MNFuWmdqzI" +
       "sOfm0oMIzi\n+D5I2vSxnWx9qMlSQN9Fm7gEMzAyMqu07dmxjJ1dgOs5TcM1" +
       "u4/2dl+Cd7Mk9AMhSQy42XIyMioK\nZxxQQD6Tui0Qgx2ijdwmnOhkyGaMtj" +
       "l0x1FFlU1yPvcSraTnEtJ9LuJbCO5rTDMqAFApMDAHQqHq\nDn26Oi8XpMBW" +
       "+lKba9neH+YBpCRTnfORkPaFmhGPDThRu++6NPBpn/d25FSWaLMfOocjlLPz" +
       "1Z4H\nbLMM61weIgsFqujjdGviu4iC3HmUThppx6LbrbHmGy83uw2sVQJlvN" +
       "cdJDY2SCtSDuH0KanYmi1/\nhLH9eICTzMRqRGR+dEAENVuMGaJj3S1IRUW1" +
       "Yb0nUFFAeXFLpySmakI7KZD9vCD1gZlGXW7vt+5y\nB5Q7G3BIktmkCmkt8t" +
       "GBymOqDXxMqnhtdLrUaqkQGYxKRdlUCI7JmZAbyDYbc0blsYqApt5KtsH+\n" +
       "yGMNmt8a8qz7wN+ORmm2U0sN3MEsNktzcDy2B5BZpiFNc4rO0gqNNykbgo0M" +
       "sxSNbsAZJbaamglB\nAlV92t74Jk8PDjI747jp3tE3xAQbUvgwXwMbrx669B" +
       "SbwQI21bJBvJZoIM8VRhbjNSGyyyoIJHHo\nZPoBoA5eH97UxBKL6I2+lpuN" +
       "voTbnWrN4z0TtQ5Mt/R0NKsMkQKrKuOAyZKra85Sip0+HnLMOvUm\nowoX23" +
       "bRDOMs6pc7ZuMreGAECuLmHqXtg6Z19XpilibkYXyy8wLJbrCjSo2cfU77dp" +
       "iOWqlihwJD\nogBZb0VIBpdButiHfV+JqkIHYYCDpBrEBR9zjGx5XK4QMxBn" +
       "9OwYRGU83+VondqtPGg202o+cboE\nvG46nSGFAIVZwYmJxWXbviomTUvPZv" +
       "og3G/IpR9444VvU1W5huvQE0ltkImFrPtpgW2Ha8IaytnC\nwnKolYzgwAcY" +
       "hA2MdYYtuVnc9CuWslqo1MoIj3Hc4YBI4I8u7pcErrt7ajfguWDLA/rYHIuD" +
       "dsLu\nLU9P6HSdy7SHDwphbar1tN4UB2ma9UWIYJfSUjyoDKHsh5GSdt8x8J" +
       "6DhhJGNUOZ93wY2Ht7xS5z\nUlgFADmMJqIM4Tq1ZJ0BStDofJ+T+dprJ329" +
       "O9qjGtYwZbcbD6FGTKXBlj5amJ6bCcK7s93eH3UJ\nUJNRYBRmCY2jCB8u99" +
       "q+OlionVcBw7dRFqDWJO5nNBIdDohCDNalDgdiM2+mNXxU+Y1p+m1pkRtn\n" +
       "FMADfr+SYgI+mILuuzuKHupNOTVgvlFKGV1MC0ZcomLfUj2O88DhIm/nA9MI" +
       "V2UNzUPsMA/0fDud\ny0pJQ0WaKt68TPZjN/FgfVY47l7YxEcshomObrWezN" +
       "y0Ox32B9EI2CiJRUzAcQtMWWax9aqZpJOV\nnZv78WIGj8VwotZm3h2Gwp0J" +
       "phjDUfHQMXMqSrrA1xegtFgtEnue96Etvj4AWbCLeaD7UJfR1rWL\nEZBhW7" +
       "eSKkBWdHIi0Zk8iXdxiZaQDHNc09BtjWngxh4IG9RpQnAtUF5+7B+x5Ygm3C" +
       "AHXGW9zWE4\njTIKKRdeC47tyjcOLchawzY7DkqAy5SpMWZsF3ecrM4sTDQa" +
       "x6lKCxoNfH2W9V0WnmgDcWhhh42m\nAqC14Ai4njI1BYUAA8Dx6nCkmi2O41" +
       "/72unabXt1e/fa+QLxYfnS95zTwPLJS7peeur86JO3knfP\nt5JF74U08yrj" +
       "VNc93+W/d6Ng9WAJn+/yP46r8XFcT82DpzIcPGJYPzm7d10XeFQ1+Oz1QNZ7" +
       "++Mq\noOd73Y82//XlHzN+5cPTve5p4qzovVgk6Y+EdmWHj8oNt5mI54Lv9R" +
       "38X3/+detZAXvrafWGL/yB\nMx+YxS89+G+/Pv5X9+7evrzvZ3ZRZrH82BX+" +
       "2w+v8F/qnje755XTc+MK/2H16HBqfvip9ZQ7V6W4\nq2vjyzKOl5xrMcW6yG" +
       "wjenoh5lYV53M37pu7PTrzioaqTTs9VWKvad69UU0IQ9s1Qjxzy6jz7kPS\n" +
       "zuXPpqHRPHGBXCXeZVH9jJtXHun27Y/XrfcYJD5msOi9fANf7z1CavrQvqea" +
       "75dPVroskH3zDBvS\nNkM56bZwg6qLB+b9k24X98zrIp57XcR7/6tDdPTVi0" +
       "Np5N6hTAr73mV97eKk0cUJ3l5cdUuTtnOj\n+Hnv/YtvFHvvhJFHst17/4Nv" +
       "vn+jKPjRH1n1tz5u/RPpt26Z4fS8/dAMd371D2mGwRh6zAyXlZ6L\nK2vski" +
       "S0jfhskOuISJx7Xz8Xhy6eLBF+w4h23zxTL+GvXPx/UA2uqS4rapcjyYd0Z2" +
       "jPubiXXHgP\nV724YfRu+OafF+bF1y7u3RxPPngoexJ0g50B7Q/Ova758pef" +
       "IpRyqhPZh7JLmmHHSE7umfefzJtf\nudTt/T8GXoNLXoP3P7jMIx23D7551X" +
       "WMMLcfh9VPfUxSvqo9PRVSzzyqU51z8/2n1KEuDf+DIPmp\nxxFwOxG8cGXs" +
       "m9g8FdCvKpl3Tv3Ty3dvKPS9Pw6FTs3P/CDh3zwJbxp5cdMBT0spn7j6d5Kr" +
       "lPLg\nDxlL8HD4eEq53IFv5hSvOOWQi69/uL54zLu/8KQx7lzutn+URPKJ60" +
       "XPiaN+/N9W0vTSeP8P08s3\nVTwmAAA=");
}
