import java.io.PrintStream;
import java.io.FileOutputStream;
import jif.principals.Examiner;
import java.io.InputStreamReader;
import java.io.BufferedReader;

interface IStudent {
    
    int getAnswer(final String txt, final String[] variants);
    
    void passResult(final int x);
    
    void writeResult(final FileOutputStream output) throws SecurityException;
    
    void tellResult(final jif.lang.Principal p, final PrintStream output)
          throws SecurityException;
    
    String tellResult2();
    
    void tellResult(final PrintStream output) throws SecurityException;
    
    String jlc$CompilerVersion$jif = "3.0.0";
    long jlc$SourceLastModified$jif = 1227640386000L;
    String jlc$ClassType$jif =
      ("H4sIAAAAAAAAAL1bDXRVxbWeexMS8kMJEJLwk3CBYAQkiRgoJa62IYCgAdIE" +
       "qETg9uTck5sj555z\ncs7ccAOoWEXRt3zoo2gtilStPzyxpXZpq21F8anrUa" +
       "HqU1EXVavP53oFW1Ee9qmvb/bM+Znzc8mP\ntax1du6du2fP3nv2fHvPnOGh" +
       "k2iYaaDKy+WuWtynS2btxXJXq2CYUqJVU/pWkqa4+NJ1e378b/M+\neC6Kcl" +
       "pQgZDG3Zoh4z6MSlouF3qFujSWlboW2cSNLahEVk0sqFgWsJRYbGgpjCa36E" +
       "RUUtFwnZTB\ndbpgCKk6Olhda7MimCbplkdbzR50JYpkDBSze1hKMY0oM1Pp" +
       "/Lvryw6sfXRUDhrZgUbKajsWsCw2\nayomQ3Sg4pSU6pQMsymRkBIdaJQqSY" +
       "l2yZAFRd5EGDW1A4025aQq4LQhmW2SqSm9wDjaTOuSQce0\nG1tQsagRm4y0" +
       "iDWDaUj07ZIlJWF/G9alCEkTozLXUmbfYmgn5hXKRDGjSxAlu0vuBllNYDTJ" +
       "38Ox\nsfoSwkC65qck4m9nqFxVIA1oNPO8IqjJunZsyGqSsA7T0mQUjMZnFU" +
       "qYhuuCuEFISnGMKvx8rewn\nwlVAHQFdMBrrZ6OSyCyN980SNz8r8oq/uLH1" +
       "TCxKdU5IogL655NOVb5ObVKXZEiqKLGOn6Zrf7B0\nTXpiFCHCPNbHzHiapj" +
       "22quWDJycxngkhPCs6L5dEHBc/nzux8qWm9wpyQI3humbKMPkey2nwtlq/\n" +
       "NGZ0shrKHInwY63948G2Z9ds3Sf9KYrylqI8UVPSKXUpKpDURLP1OZ98bpFV" +
       "aSnKVcgfYnmXrEhg\neR75rAu4m37O6Ij9G0OefHgwKl7ajtMJScW1ZCkC1+" +
       "gM0JEbIxGi0UT/elBIKC3RlIRkxMX73/33\nLYsuuWF71IkPaxSMhttSUSRC" +
       "BZV7TQNfJWDlnvh5Y8k/zzIfJUu8AxXIqVQaC50KsaBYUBRto5SI\nYxoLo7" +
       "i4s9ducScJGxKBcYUIYitYR70GmuIPD3cZLaUgIUqb5y5Hu6oW/QhmEjxfCt" +
       "KZasSPG5hu\nxdPb1138ve1TcoBpYy44LkOXQxmM4nfNYliYtvxU5+bTh/YU" +
       "xph86DPBFkAG8/eExfrx0uuXvH/4\n3HVRfl2P5HCuXcIsSka5uq40JIm0H/" +
       "9h685dJ6+/jCrKNI2SORA6idmCiDFxrA0DnAFjQuK3tqL0\nB7dOv+O1UL0r" +
       "sy07ChnXX/pR8XXCM+vY4hjtne9Fajr1X32HpJoLb3onJFwKsKbPUqReSXHV" +
       "84+2\njMKR7eAf541O5LbMq/ArmhdIKt5+cfHw6yP/sqjh8PtRNKyDZA1zod" +
       "QlpBXc2rxAS6sEikudpjaJ\noLTaInRKSgsqYmAsEE/akJivi7QPRuUtZEgL" +
       "pBTgr6O9SIwWGa4Q6DaH+GbSWS2Li/ix+KnX5r5+\nbhRFeUcRNGfCwOXQUp" +
       "AJxnqroYlSgiQXV1y8/oLJy/fO/isxmOArMQMTIwCuq/z46oHERgs/MZoS\n" +
       "gGv/II12yIJaucTqLs1ICQqIsZ1ViLsNbaPbQlFmBP1cQuYN5u488gyHh8IQ" +
       "h0VA5lPWyZRWWzEO\nn8/BJIenOxVZtEI7AnQGCYMx7jppMgyhD5Z05uqXKm" +
       "9/TriT4DLBSlPeJFFMjDJ5gFNu7NA5kxIM\n+l8sumB7bE5XKZ2TAjrHpDag" +
       "qDOHIDz0sL8XUKWLHdPyyFNBngJ4ONPIaOPd0ahIomiSDhsXb1gz\n/ud7nx" +
       "57Mgr+jIoyRpWB7Kol+BnwREpaJ2mURqelYrSXiJjoF7FacCAREmu5Xx9LmT" +
       "HLiz//bMLL\nC6n1RQnJFA1Zh9RkDZeHtYuJs6GsoAvBEFRTIYUYWwYr6Y+L" +
       "MrrR6Jt1cM3EENdgtA4UTWmG3i2L\nMapLTOuKsbCKCUYynSLJJYYzGJpZpR" +
       "JLSrhJNTdKRuzcTrBcSsSETq1XinX2xTYvyggpCPv5sfYr\nphPXT6Om2orW" +
       "NguqqmGfunHxv1d8eHCTLj3PQG2St0+Ae/LDlX+pfmj9NBeUGoA0clEM5EJP" +
       "oAL9\nNheD8H0BkIUsoBcBuYSKaAGyYqiCgylrlbpB1TaqLMJnv/rC715emH" +
       "kYlKcBrNM/azKhQpGVFgh2\nO26n7AhZ/JBh3HBqMk0COSRiLizf/sejlUdW" +
       "uj7ixRElq/wxaGlpheK7BxqOqD/c/itbzSXMEUzU\nMkoFTxNGOSRMiOAJfs" +
       "GtgmxYUg+WXrPrhs9HXkQDvJBgZBfZhchiHywZP7Q3O78CvkNmTdrMlQHm\n" +
       "pe7PbLaWOMFfnAUXIMdP9UaaoykfbXO2fvDJI688WmN7YnmY89okgdRqTAHS" +
       "pfrdBz/aNvw+auYw\n4lRIA5M4pXVS0YuyLpDK1P4EmySDSoFBNLIMKgKOtM" +
       "Q37k0LWuVfRVsjd6GPIE95OAbWuNKc0WsX\nZUi9ogqKo0VcFBr2jfr1FUde" +
       "95cP9rL0SeB6nj+2oiJ2SiqkPR2omuqDKqdDAK50UHOmd0YCCvIz\nc2e59v" +
       "bW+/NXMNTwz2VYj3v+9cy9m2ruS9JVQUo3G63IwNWh1sGulTNx2qmtvS++sf" +
       "4/qIkj6J7W\nxnWMxnET3Mr/xOzDziyVZZ+lSf6AJGJ4A67+SfLMF0/tO20X" +
       "1ONcrT1DxsXn8pPD598795Mcmkm5\ncqSCU5PUbfze0dq0VmUzhO1ZM0GE4/" +
       "JbXJz3au+ovJ/dlYqifFL50XpOUPFqQUlDEd1BNstms9VI\nnOj53bvxZbu8" +
       "Rm6DeZGvAOJzcS526jXvoiglzyR7J8a5GyEdPlwXrHhyMBlGJmEHbd8klY9J" +
       "jx8I\nCkfazeAWlwRIiuwge60t7i1V977/yLttpVHuHGBqsLbj+lh+tdIBGW" +
       "Hy2Uag3M/MnPzQlW1/6LQx\nYBbJEE7csp0lTUehUP9dQ8YuWl07Y/ubn/zi" +
       "gokcWlEIIot4I2VkgASUOmxDxsnrvuWyQMNY49fL\n7Ofry5seWHbA1hI7/a" +
       "d7A93Xkw/584vv/u1/7ntwry2DJcpdliT4cxvkXM9mpEUTBcWNyNIrFnz9\n" +
       "/uPSAbbpU/hNgn8ufT2fvTXZcNdPfzrMHvxaViVEmCfuDIYOzd83Zqxs2G+R" +
       "AaQVyF4gl7tCx2BU\nQgtrWAm17AgI2u8Gcg8T7KnvqslTCA8PKHRMD9usED" +
       "aMOgdUBvYKhkxWqjm0WpBWCUBWEeC1RdHW\npKNhRRZDWI3Bdq2qwz2OPFOz" +
       "mW3q7O9GHuahYbPTf8rZ+l/lYsNOIPu5uNtvx114y24gD9hB8msg\ne/w206" +
       "i4j4uKB2hUPAhknxMVvwHyEJViBs/j6HaLYc7aD8uF32g3ldBtTG6nYDIk9B" +
       "9kBs8pPceP\nVIWiwI4q1D/e6CsLYQP6JA1XXaeeeJJ2OQjk6YzrhWfO4gU+" +
       "Vlxf2ELPXjPD97U+XXOtaffvf8Pq\n1os12a6GZ2y5tvsRdLiDAgipW1O6pk" +
       "qWSlN89WZ+liFC6k1nBB7vDr+y48jJTx+/hq83p7l77GZN\nUUhWJCW+Wb1K" +
       "TWkJuUuGozySWrdW/suLO3ZvXcXqofP67+O2j1uAth5ef6aKGhgR4ajbPRJz" +
       "2djJ\nWLn/FG+JYHaT8Y8pr3XsOj6jio3PnZ9Zvz++cNuuW3/5WAM76IO6vO" +
       "RbdMJQTnZ0XMWg1AePgwgW\nBjFAjmbBEajFJocFhRcuyq3lEMrGwUVW5NnJ" +
       "lHBR42gAR+wW9ucmS9LNxAcyHPJy8R4Pbuq8WArH\nPPNC4zDMB5AXvt6/D4" +
       "Ct9kv74BTng1MBH3hakrpXYUvuLt3TzfNtJy2hpoQVKCs1natOlrzz9Fvb\n" +
       "bqs47FQntOM53jXKd+GX6bGrx/9h5nk7nveUJZECpkmkCJN6NINr3LClmDVA" +
       "6Ce1nB3HNb5AHhR6\nZhE0aPgE8jvG/QK/kH5P6UuUvjrQBd0acM2QDDhOWU" +
       "/0sybg+0cwIYytwZMI4PVMETxcIAOFk55I\ndbC2YwehQL4Z7roIKwF9OSdG" +
       "nrqQoXzVGbCdH8KG0doBVWcZrizTyZ6uTTLTCg6ry9rnx+w1addl\nzDtg9z" +
       "TOBUDO6d9SYJvphmFkFoiI1AKpG6Jg+NrvkVihaybld87EwmOBNghMFf85lt" +
       "tEUNaPpFOz\nTGA4klZbEBk63Zs9bNOysQ0USSPNLpLan2/L0rKbTQ2rSiNt" +
       "0LTHMfascwikHkg7kAVO9xPwaRX9\n1C+UROb7M1puryYnBpfSYMFOGvBEwL" +
       "6/qv+JALaxX3oi1nMTsT4wEXYLfI5gsiuv8XlyAP4Dcmn/\ncBdZ15MF7sBQ" +
       "OCAcwRnpLEnj7wZ35VaZ4B/KB3fA1hDChtF3BwR3Whrraf61BD2ryA56QaQz" +
       "OeuB\n4IEhXR+3SjZTj28BcsUQBfdkRzoPB0ZFnIU9g8I7M4h3pot3ecyVX6" +
       "bc6o9nN3OWhT139DDs4Qc+\nq2uBXAkEqqjIzVRG4AV0e7rTxNwVldILe76x" +
       "Sl7xHbYbme7snaUMrqUnt1ZXf79bp/+pd2b99+9k\nr4XtrXR+CxpmAidGse" +
       "z3nagsdpBX6EQ6bAgrkXXci1HpYlmRVlDL27EhET2IGRhVm3JylmmIdXTf\n" +
       "JWt1YWzUJ6yKHINRBd1hyVqtn5XetAj4Ji4+cfzUzg9Xb9pCd3kjqTl0+9nO" +
       "DDvHezJsdapu9/I1\neu5vhXozLk57u+TP/3PVH2fSizm24/hrFssEPXDNAr" +
       "aJpH1Y/htPHSr73os5KLoYFSqakFgs0Esl\nxHvdhmR2a0oio1uFZvFG2IqU" +
       "OEv0asftVVaCtU/ZIz8Bcp917Bv5WRDwnGNf51235+i3xZ/BnJPE\nyP0c/t" +
       "6cyXhfJ2R35eKCvzW+XHR8mfXGpFs2q+vp1jtkGoi3QPp+IHfRMBgMKOdbDr" +
       "FicGy7JKbh\njt+ijCjRN8wsCGs8Qchun4VxMkPtOJzAHVT6uSnndpa7zg5X" +
       "ztImns1nyFDjLveBWgx8T7mynhnK\n+CG5EyqPr8HDZSoH5I8MIXd6XkM7Q8" +
       "Ex2uSQoXy5s8wqSv1sGH1nQLlT59ImlhRlMFnzKGc3kN/3\nbx6wvcJB+2vU" +
       "18eAvD5EwfB1Tc+AU2eha2XPoDLn0WDmPMrtFHQ3XnYzy6wUd8JKcRG9fxcA" +
       "eQPI\nSScEafcd8OnP9JMvTADW5vUfJsD2rdAwWT20EmtgsQJqv+Vkd5+HPr" +
       "Y9dKYnSxHwEeemj6mbPgFy\n2nHTp46bzgBnZK8H5ZxX/STfwMGNJ8lO8idZ" +
       "Hwcd7jMb18bY+ZXjoiM+SOnD/aYgeEER41PQF0D+\nz0pB0ZyhpyCQ8ysgfw" +
       "vfKcFBwpyQqfcXd/Zxl++cbGGfSjY4IndWdvre+rZDOw5cxV5qwlXXsDsb\n" +
       "TaIomWYr+dX/zns2eS4IC1kDzfAeuPnH5g/d3jg0qv6iquSN7qGb51qCdbnL" +
       "UYK+zBvfdVN+/Zu/\nnMKuvqpSr2QsTytKC4oqcsjlPM8LwEbfFYjAm1R3rD" +
       "ZNw9tmV209pizsZSVn8NaZw1xVMeadsqaC\n/VHPvWUY5Ws0zUfHIBsGIidp" +
       "sDkHi86WMzrC3XLan28LtmRYvyegDeAu8r9s0QD5HJwYnUrjyArs\nLKf7pC" +
       "xrOLh8bYly8DOicwcqEqgtK4yEZGSyLAY3xJNMoZCdRbSEWss+l1JaxtlvQW" +
       "x0ApDKDOJs\nqR5qMfBezyCLkaju1iEnODjuF6xC6pgzfufP450PDdO+Ikcy" +
       "K8I8+Y1/kCdDyqrx5BkJD4cIPVYV\nEF0yhLLKk8GznxwWuZlsti+35log5V" +
       "fLB7CFWdjCds/uWROcMRVnE+6eNYWt9pXcal8ZWO12C5B7\nssyIPaEeZGpK" +
       "4+5m58p1XFSfSPXlPDuulr3pdDICFeK/TDwDsXdGodbQm4mVYcnFQfbbL7tF" +
       "V+ub\nZO8dRT7uXM9BMpt7ds9l/HME0VU16DmagNhl2SHMkcrNkRqYI9Wdo6" +
       "x7DPhcErYYNg9hMYRvBWHz\nUBMylK94BLbaELavuHhkfgGLt3DGA7liQCgV" +
       "/b6LyNFrKcRuA3LdEAXD1692j0H08e8x3KYsZTSx\njJXR0duhKaSMzuoHIN" +
       "cD+VGPhczR2/1JiR6zcUkpa3bvsc47euxcsgfIHVTGELNK9JaeL3lYQH3y\n" +
       "Dxs/w/0vLJ3NmvfuFrvFaGkD2Tja3Q/WwZt7OEH3X1jksc77fyjg/9+k2X+2" +
       "jIsn9PUXvdn21j7r\nWmzWozq3x6X7L4tl/mnlzewGoKgImzbBKPktKJ8taw" +
       "v++YuJfmm2LPntV7tuvOa9kc7lZCCj2JKz\nfNDLX7sLyIHPq0c0Hrvk8ccf" +
       "CPn/UY4IznzPJdWGc0/nf/rCqW+HZhXmvP8HGSoJ0BY7AAA=");
    
    jif.lang.Principal jif$getIStudent_S();
    
    String jlc$CompilerVersion$jl = "2.0.0";
    long jlc$SourceLastModified$jl = 1227640386000L;
    String jlc$ClassType$jl =
      ("H4sIAAAAAAAAALV6aczsWHZQvdfbdHXPTHfPZGaYzJ4OTFRMu2yXl2IIkrcq" +
       "22WXXXa5vJBR490u\n72vZFTQifzJZlABiJgEEISAkJDQ/CEjJLxYpEUgsEo" +
       "oEET8IoEQBCYJEECJIQHB9771+S78Zhoko\n6fq7zz733LPfc9853/zt2UtN" +
       "PftcWaRjmBbtO+1Y+s07sl03vkeldtMcpxfvuuBfW37sF37oF998\nYfZha/" +
       "bhOFdbu41dqshbf2it2euZnzl+3RCe53vW7M3c9z3Vr2M7ja8TYJFbs7eaOM" +
       "zttqv9RvGb\nIu1vgG81XenXd3s+einMXneLvGnrzm2Lumlnbwhnu7eBro1T" +
       "QIib9svC7OUg9lOvqWZfnd0TZi8F\nqR1OgB8THnEB3GEENrf3E/g8nsisA9" +
       "v1Hy15MYlzr5199tkV73H89m4CmJa+kvltVLy31Yu5Pb2Y\nvfWApNTOQ0Bt" +
       "6zgPJ9CXim7apZ198lsinYA+UNpuYof+u+3sE8/CyQ8+TVCv3onltqSdfc+z" +
       "YHeY\nhnr2yWd09oS2pJdf/18/If/3z92/o9nz3fRG/0vTos88s0jxA7/2c9" +
       "d/sPB3u3e+zpndp+7PZhPw\n9zwD/ACG+P5f0oT/8Pc/+wDme58DIzln323f" +
       "df8n+qlP/yrxm6++cCPjA2XRxDdTeIrzO63KD798\neSgnW/zYexhvH9959P" +
       "EfKP/Q/FN/0/+P92cvc7OX3SLtspybvernHvVw/so0F+Lc52YvptOfifMg\n" +
       "Tv0b5y9O89Juo7v5UM4e/D4yjVduo529zqlt5/l5+845Dm5Qbwy35wcv9+5N" +
       "FH3qWe9IJ1Nii9Tz\n63fdv/Eb//hPMrsf/7H779nHw13a2QceYZ3du3eH6O" +
       "NPs3aTlXcz6f/0t7/8xk9/qfnF+7MXrNmr\ncZZ1re2kEwev22laXHzv3fbO" +
       "Ft58wu7u1D3ZyuvOZDaTBb6bTojuzHRisK9nX3jWPB47FTfN7Enn\nP4zuZ9" +
       "/4DPMXb5q8Sf6jN+wPSJvkmDyg7fUfUL/C/4kf+8ILN6DLizfBDXfu8NHbLs" +
       "+KZnNzzEf4\nM+eH/9sv/9z8cw/w39b8gTsELzTvN8SnFr7rXv+e9nO/+8/a" +
       "X7+T6qtTQGjtSaWTd33mWXd4yoJv\nfvEsSSe7fowX/5f9my//rb+S3Z+9Ys" +
       "3euAs0dt6e7LTzVX8KZPO4oR6+FGYffOr7027/wMa//NC9\n2tmnnqXriW2/" +
       "/ChG3URw/0krmeY36Nv8lTuLe+0O5kO/9+D3vx+O35v2poqsnMy5/tzWnwRh" +
       "t75X\nDvfutbOX4HeW7yxvq96+qfBZsd62/a/c19jf+idf/Mr9J6Plh58Iqx" +
       "PrD3zvzccWcKz9m0j+9Z+X\n/9w3fvtrf/xO/Q/0/8K0aRDn9sT1y2XnpLE7" +
       "TZq7A2FoZx8/p+7bj4g9TWfC5LtvT151x9ibUzi/\n2+Imw3cehM47R7v7+t" +
       "nb4/uHO1f50GMwoZji60/+5p/5p3/6+/7NxAI/e6m/6WNS9RO49t3tAPrR\n" +
       "b37j0699/d/+5J3FzWb3Pv0v3vyFf37DCt9t8MW75+IhG7f5l26Pd24PYKL9" +
       "kzfa1aKrXV+wm1Ys\nvHg6abw78t9vsnIdZ1No6h/Gzj/7mb/+W3/nN5SP3n" +
       "/igPm+98X4J9c8OGTu9D4vh2mHz3+7He6g\nf2Xx+W9+Vfl150HwfevpeMLk" +
       "Xfbvx1/2/9Af/al/95xw9GJaPFfa7Sd+h101HPHoJ4AObSinwdF9\nfxBVPB" +
       "F5hhcuCUyRJnFIYiUseBuFOJMKCY9jKuYYrrujmyDNGUGQ69xtMNclpEJnDK" +
       "WFr0UBhRN1\naitfx6E0rLKCwA1u57Vms5UGMsbJ7mUELjY6yPjrKusdwBEX" +
       "Vn518Uyet/YAeh3qdVAgw3kPBWwv\n59I2SqDYtG16Ny70Tm/HXIWcdjB4o4" +
       "IoU6v4kwaUelLZq8WeB30Ywx1AXMx9Ct25aXkILXoLW0W0\nuqKimhbdBq42" +
       "3VnVU6fQIVfdC3bEnJJlU21CveEV09mG5ZmyYZRRNK3dXHLrSM49pwypXYJK" +
       "aeTZ\nmBhnlFOmiedcFWTJm2VCk+rVB6OdaC4LEZRLQOjr8YI2gaFodFRboe" +
       "bs7HOjN9QFmttjkR1gNVyV\nqoaWB7EZMyUhOc/mD5VqptBoERvFQ5gtrYPE" +
       "agkh9qFaCYco0yG1UrP1hT7bR6lTD66/nG/B9tDY\noZKtxmVM67StnZeYxa" +
       "W8vgG2azulmORYXAVDy5zAzMIciYydQm/P6kCk3bLvyDTdm/SRh3FpmDdB\n" +
       "oV4SCkUqN1ll67zaDCeOAIu9LOFcdea73GrGbaU2BHZcZgftLFr5RqvMqOuo" +
       "jtlwar4Vd/2A1/4l\nn1/SE8EeNp5I1rWFSupIjfs1vlT3V7zGiwroBBY8Us" +
       "PO0xCuCAUUQfbSyUEk57QzLCaudsJWylGr\nDjByOT8aZbyhWEreO+yVje3y" +
       "DEFVp9P86A55mEQy1aAC4jEs6QL5tRvwSp8EVY4HDo6maLET5cQf\nofzSph" +
       "Uw32+tZRPVO5bLLyYKr1f4FrLWXgOrwXpn1mNacbh2ktWdoZW7ktYUQQYla4" +
       "075eZkq/nu\n5IaBmWdGzUTh3FcwpCa6VQZjEsqd19ul5AdseNmlmH1uRV51" +
       "ddCiEgpchOKSZxxu2MZL7Qj4Kcnt\nKFhJOSUZRAODARieC2bTdfoGA7lEtg" +
       "dVjNpW1VSFIq0TdjzsA16n07yPEBNPgOuVC3itw4nB4KrT\nwaaQ5a6xSVMj" +
       "lbZAVG5uDoVQYPGqWXudq7r8dtiRrqlxZtyaCrbcZh0n07BrCbYWclrlICPC" +
       "dmih\nA5OpMechoNqdZTeqvEWibj54sgOCMN774NEtyNIcVyshkYzDkImrPN" +
       "ibaWy2/aAhC+cYAaY2lBGO\n0jK5SYgtDvjMENTDsuuMngVWc5g9KUEKyQhL" +
       "dYbLNWpiI121WvJctmSBdYTiiMejC+BM1bs9B6mS\nQqCxl1ExvRlqYknnxO" +
       "Z86HZwWwnLOYl5Ur+QQE1Y1s24xKgoNwygVHDDoMRFb66ic5v76419rkED\n" +
       "htiSLwQHLnJ+c9k1O0fWKsVXDfaErxbQ/CzuFMwnAmQFSojgiBVA1FnkcbsW" +
       "WbgBe0FHGWiqc4TL\nrbLfjbRFgNfCO6QlabhQPRAq2jBx0nnl2ebnhXC0uV" +
       "zZqVM2YGZEwzCAnfBxH2MHWem01mJCoSSP\nYY1Ka5W76Ft7dUBpm11sHVVX" +
       "ISEG4mGxyw2kRhZzJ1I2vuYq+21AXSa5ayXBD3lVF2aqhvHBOIEj\nDhQCPw" +
       "KBBMTNkElELR7EI3ehugq4rtCCZZSwAUSrUOfhtgc4DoRGjrc791gJDchRh4" +
       "prLPAUC83e\nsWXnkG4yUgbdQ2fukW6F4+HIRjh3iJYnAkllfbQUXb8y0jzH" +
       "AZLn/FwaTlbLcBiRH7aUKQ7YuSzF\ncIxoxFpO6jV22Ro41vFxRQukmso+v9" +
       "mIZ5pHws2+w/YEkgycOF+keNNlJOYwiLGzoCNxrtmStsOK\nlliOvi4bATe0" +
       "nS6wnjyOmz2Zh/xK2sucLcne0o64IotVOmoMBwyvc6DzsHxAMDGsF2euGJVS" +
       "J7Fd\nkS7I/KIwpc1DmaZUfmrWqhHz52KDbWyXIhQm6xBjWAvZkRXiKzCdUY" +
       "Iwp9AcVA6T2RCgFa2VhLZ8\ntjU7vkG3TUH0JLNRjpypmfrFrFFzIYh1raB8" +
       "C7oizDB7L2yJlXbUsy0cQ8JctEthiuG7xqF2lGZO\nZ5rA86Z53fKlVSq8oN" +
       "YRvz96O6W7useadNVGZY4VaMS5AQ1Hsx/DsKTkHmkCs56XkWwcUSmDilrf\n" +
       "h11VZdugy9mhBz3cZ6mjcIblwxZS2+WC8AGBTo1FGWTn9Z70tW1BLN2UERGG" +
       "lwtCWM/3kU/j7JJM\nOK0pSJfsTHVnE9vRrGIqHNM6dUoSPNqVIPJ5D9QUBi" +
       "J+xiZmunPJei8C9nUXHcrtaRNG0FyC0Bwj\nIgvgyQhmyUpMlpSkKvEk1QBo" +
       "/HOqeXp3xuJBYabAfBnsbVpG/g4jh0qqaMAF4ta5qobIaFdtLibF\n5jjstx" +
       "MCMZYIPmi2bZgNphYudKOW66hZs0ZyoHueDC0ysCI3itnxYsnYAZYwnOqTfX" +
       "b0ajE9sNm8\n9DHZEWxdEjdBTmgGJ3ryWrPtYkwCx5CgoKd5DsVxPdtjU6w3" +
       "8XWRhJ5SHQlWLYPaI6+Ave8vC7sz\nL/NVqnAEIq5K46QuzW4USnoHyismG1" +
       "VaLTbkXuDEXbiTWvEAY8lS0LtToJyas4duZY5ZIxLh6N1+\n5y71xphbWrwu" +
       "wmpXLE/uhqyhc1CDG83z14grr2thqfokmp8XUBHzkBpXiaxARdZV9K7yaGKH" +
       "LDVW\nyrylSVE9N+VnkI+se0dfAHtD3B8vV+hknuF+sXbHdQbVnbrmTwetgL" +
       "cozF32egQ22y497geoytpe\nXSyaYAVUXHJGeUyfD7kuDjlzhMUaGKQrfY3H" +
       "k2UtUjVACX7LrwgUW6iBIG6WQCtBSwOU9m59BOmh\nMXK8lGlkjWNrRHSzJE" +
       "PmbqVSGiJrTnD1l161PGXaNZJAS1xumRXAOwZ/he1uUfQ84KWT8QUbAVka\n" +
       "paTJm+qgpTTjgeS+abNmfeLmuXRGYKcfLKfDlQylfWvbExJ/dVUEQs9GX8Rh" +
       "eh0VjMdtZDsynpxe\njJqNRpFMt3zGsI6HJ6m55s8Dzs2pJLCvPqGnF4WLu0" +
       "voo8sWi8HTGsOAUWjb8sR27JasGsE5L9Jo\n0XocudXZEdLsEBYBMZevh1QH" +
       "AVQ4DHOTdHiGwdymXKZHzY80ee0dcLPT0yVmAp2TA9c4LBJXTxmO\nK9oVB5" +
       "2SkFA1KRsmueV13+njQdybq3UgzDEpqEek8XXWIcCIwwDbw4g1bCQXAMFXfQ" +
       "90IIDl7aUe\nIZp3Sy+dgq079IkhrrOS0Y6kq+/HPVdv8ut6Co6ySjhOqQHR" +
       "PszxLjhORn80LHfvycG1Ftl+sE/x\nicmooKM5U7p6OGxVQwNtFwphH07jZh" +
       "WmWEsNEKnND2Fb60QGYkTIQR2+dUP8iO3yvmrSI0Xg8o5V\nRHrdNQxti1Lo" +
       "aWRv7qJk0KtzttRLUqc0Umd8ClQ8Vp+Xu32kKBatczDpVVA1Wa0kb6RrpsMV" +
       "Jq23\nbGdHpiMfA7yerA9IzWYvcXKHdPspAwHB1QitQnodkXjWTPkZcIGWaL" +
       "w6r7odCU3yJ6IkH8RTf2FH\nhj/FZAOcUdYWTBezaXy6HkAhnHpke9yiuUlz" +
       "yZpcJ2Qzma/ry/MTp8cXblWBNOCjVCOYBxnlCdAw\nbN/3eR6SDucENa91pA" +
       "fSKtQWp3QIIEaQjbNMrzFtYRhSawdBH+ByNQeLBoRsdGtBI9L2jeIJMU2E\n" +
       "camDElomla6me3ytTxxOmS+agDlJYj1dL8YVfuaPwwKIKhwusRTDttZ+rmmR" +
       "zlP6QnfA3VFP+E7r\ntsV1VPXa04GmEyTY6g3XqIpAnrxUgs5gR7QR4geovd" +
       "tGobKyz46s8FfIO/NzXciBzXbBm6x9xE28\nrGGjkc7oOS5gObfWVn9dLNz9" +
       "lKnCAKITIoZyEtpLiuOJ/OGYW0tD1EOQ8OXwEupz8rwhzplDMvZ5\nwxfuJl" +
       "Lcbqzg6cyptxftpCP7nE9ZUllBIaEsLvq6czN1LewHwh1ZmR9xZSU7XYXrRM" +
       "3OZXlPra60\nSCKE0bcoQK+odp302Io85iEokiwc2UldGqbWd0ILH6/BvuVH" +
       "KCqLw2lHNWBut1JaX6/rTe/MnapZ\nYZtD3koiAp+NnbfYGqizrYcpBUXyBM" +
       "t7X+MthiqTLKH4Pbrn9jUsUGlGnwiU8ieNwOzeQQg2UtC5\nFTFLWw4Z/Nxv" +
       "gcMOSFhERrVO68/1gZxSE1eEDjQdSboGLJvRCRdL98KZY3uxRG4ln0TmOLgc" +
       "IW0S\nBOGm+yYFmRc/OggrC6sLbnfZrCXV2+Z1dSiM62nrUB6L77ZLryBPum" +
       "vV8fU4Wmh3PApHKkTrcV3n\nw+IC2p6Xzq90G66vR4nUaAn11qrJ92WUbZJN" +
       "EXMgsSu3KB8u9nWfnOLIHp3UwzHmkknkPoymwxFH\n0rZltL0tl5MLzo9bYp" +
       "WklsOQCQpbzdrZS2NzWGqqKu+FUrBzCJjy8J1zPEC1Gu/bpXBkxcBu3Euc\n" +
       "sEmIJcRJWg/yxVaM9RykFpoiOZgIll09mjlZBqopbqTtlE1dBBSo+gVPCPZg" +
       "wEUM5uKxOa4ujGEK\nAYeETdz1uJGOhLyi3SwH5i7pWSAibrCGPEgU4V6UvB" +
       "SY/IxdLBg52daKBHYkHEyBk6aidgOTFwXW\no7q2AxQkaageCQQ92Ier5Hfk" +
       "fMUxkaEsYPVsHc8QTrqNdiADL1GuhUwurU3OaesQ5zBxFcFl0cK+\nO54m23" +
       "HRYp3vYUmPjiC8pulmdXAX8wrqSINImKo6c9eTsl0Rp6WP1VMuczmlHif4GD" +
       "qoKTawjulk\nPtbktibWlZa3oGUE2NopgUXpQc56vVgn83pltPVEGjWUGRF7" +
       "28a/wrkdNt50BUGZA+oQYZ0YhhuD\nbGmmmXJKaQHCmIg5QtxWiU4ZzI9pln" +
       "GecQzmvN6Cpn7VeHScbsN7hfTAaDxVbY4YfkucV3y8mq49\nV+0arg1nXVIe" +
       "nJyrY7pcrHOJpnvWv/KNZ5fdGuDAud8hfWQUVyFBsG5xlAFYPrFQoMbXDFoB" +
       "Ub1p\nGkY26D1R23zJgiYQtTKr1hhcNMhOKMyNWtnJJmyWTJPOB7b3okyB7G" +
       "URF2C3sfrNFuIqTWL6pd0E\n7elkU60GWNx1Uk65BjGyR3SFvuTbfYCAEIws" +
       "YniwADLnZWY+yksXaFF3NKKAhxQY8XdUf9UXBqvg\nWWBsy00DVYu+BM9tsi" +
       "1i+CCXC44NFJEMxZ3kOXS9id3tiPE7J5qf20V8ps7KHr801LbBD27U5avT\n" +
       "ICZyO6UcBHs6op2a515pY9cQMa4tl+VT5Bk39FnofVIPh+lszMY8ynfzBbVF" +
       "mLGSa5ylLbVgEQ4X\nOcNDjUTEDjgzQJ06Ofx05uOXSu2n7IwF84OQHpE1l6" +
       "WRkorTUb7bunCyB+C5M6CX3uXJBdRrIO4T\nPY0wl2DK1t0FoUF+ZEOGXNBC" +
       "vtTpTBbrdsMeYCM3ryN60Tyc37nKdh0MLuEfZG6uqi5jB66HS7m8\n5sX+SN" +
       "A60msB30y+4hEX/QgtmawNmwM/uekp8ZAFK9fm2tuZuTqwF8b3szOaOXK4Ge" +
       "dQzh7LFepc\nQzK3djiLWIMBqMfgIm73PJ5KeOxZ7MX1sLPogLhjLizjXMTi" +
       "QpVyGrDN0GcYZQXKh82SXsyvy3Jy\nwTEqR+qAj00YXPpgN6XKt//uqQLX8A" +
       "BrSKcDytluA/Vsrrjc072+9he1RUsXxB1OSHVJDaOhG2c+\n3dCLTDfrhWcA" +
       "17yBfHXFUWBCXwPC7+ScRULAg8/hsurRuOrUPVZtHQSsKM/JBc3cLa5kH3in" +
       "/QKw\nOmCei7uur0q1hg7NcWx31Kqo3OacyiIuXBgn2JjnKUdS4Jq29pd1m5" +
       "2g5bqMr42lnnJ8b1sXcDiJ\nvu01lU3NgRMr97pmInqzvGoBy5HNlou9sqET" +
       "NsZRXbzWFGzcIi4utJky3Qn9kPaJDq/XzfJAIyx/\nMXOtPo9E3cyFXYCV1F" +
       "BLQjSJNx1xWordi1sxVdjuViNjbdVRIEx44PdiYVGe4qiM3jSLFOTtoU37\n" +
       "gz4sielWQ0t8M68UpBID0r+OlJDY5w6MmSkcnLsNOlBoGV6DLpBXyFKmPWnB" +
       "Je64wzl8YYJAQnn0\nWNUDQiY8vXI5+WSe5sxmOUaCsEvw7TUfLnpnpU0bL2" +
       "AkLULkFAgkRm1070x5DdDpiuSKyilnFqi/\nN/V2XRquneKWLoEQhZDYvGlG" +
       "TraZKf0vd6sFkiF4CRobNVBlI5XprktruPRojtr4O+BIX+jG8LaF\n5xyyVX" +
       "Yy3XxzCBxHwNrNadE5c0vCPeWIdVP2TIpli3nNOgVYkVmeNBClMzvcRymksm" +
       "Li1vtEqUxu\nrXsFOmC0HLlMbZr7cB2JptKTOnuda6Q4prv1ihQcmxHsvmOj" +
       "JAi3U45CbwksjQ9UeAIcVBj3m3py\nxI6ABY8hDBpE19B5yS5xHx/gndlYR3" +
       "WYn3lDWXpdtLNV8doVU+R26cVpO+17VSAA5GMFvbpaUtrT\nnahxV5jfDe7k" +
       "J9wUmraMsN+tedsX4NQ8sPA4n64ZwAVY9gIP77M+6DZ1v7G3CQ0dzzZ8APSL" +
       "1WIS\nw8IGeE4aF8OC8RwC60UCGQvozDX5WtaM3ssh8IzVcz276sW1ggfUwI" +
       "RVmwJZnl79y7bYhVx2dcid\nnLQ7Hm/tS79YmB0fZBkkyHl7wtqul+x14mKp" +
       "RVFniN9d58GeFgysEUaOlaulu2SnHAV33YCSc0Cb\n/PqaX2Xe07fuEsgDoK" +
       "YqfcFakZH1Ms5u1YJfkiZGEMQP3oofxHdUFHrzrqD1XmPAwwIxeFdIGd6P\n" +
       "4X47+4DtNG1tu207e/W91oMniqYfeU7N/J1PfPTrP/MDf+nXnq2Vzm51oU9/" +
       "q1L/XU3oa8Z/ef1H\n7V/5ym3pbeEfm7Zti/JLqd/76eNdn0Ui3nU2PKpR/t" +
       "WX3/JeFPBPPLv/K9P2n/22K991219693d+\nDf1XX7z/bHFzXvttV+fH90qc" +
       "7y9Ly3Xh+l5X+4/RvbuEP7//eeh/3J+99GTt94bhc+/VW7/w/sra\nM4ierb" +
       "q+FhR1Zqc3Yh61c8zbqC4uj988WYKdeL/x/4en8YHbuOsKeKI14PYwnqP+25" +
       "y9M6CHGr93\newqTGD/yuLhKTCnmeKuuDz/yq5/+C//I/ssvzO5xsxeb+Orf" +
       "tSfcf4wLbN7f6nG3/EHV8Yf+88ft\nv1v81Bv374rJjt08kPSzPTLvb4F5qr" +
       "PljqVX32P85Wm8PY35bTzDOFiW5dOc3Z5fuZnqQ4OdzC+c\nMsW8ufj13cc/" +
       "8nDBD7azFyY67ubaU1K+tWK8dhvPk3L0/yDlR7TcuwO7e+n/36idl5M3KX7T" +
       "pe2z\n5L7YF7H3HHo/Oo0P3sbz6G2/e3ofFck/cWcqcfHOJk59qWvLrlXb2r" +
       "ez72j19z5RYvfdro7bkRlc\nv7y10Uz8vnaZ3vgPGL6tqL6FQm7zDz2PwR/5" +
       "Lhh8aNGPSHxrCqMPKJTrOHfj0k4fffrII95vX74T\ntm///OpNj62fpt+erU" +
       "9O48O38Ty2fvq7YGv2VEfMtzSx1x6TBj1w6ueL/I3beB5tP/v784Ef/30L\n" +
       "8NaF8rBf6t5tfnv5B8vHBP78/z/hvTnZyttTRHnUTfWueoP52vBEg1VZPqe9" +
       "5EGLzvB/AAFAcMHj\nKAAA");
}

abstract class IStudent_JIF_IMPL {
    
    public static boolean jif$Instanceof(final jif.lang.Principal jif$S,
                                         final Object o) {
        if (o instanceof IStudent) {
            IStudent c = (IStudent) o;
            return jif.lang.PrincipalUtil.equivalentTo(c.jif$getIStudent_S(),
                                                       jif$S);
        }
        return false;
    }
    
    public static IStudent jif$cast$IStudent(final jif.lang.Principal jif$S,
                                             final Object o) {
        if (jif$Instanceof(jif$S, o)) return (IStudent) o;
        throw new ClassCastException();
    }
    
    public IStudent_JIF_IMPL() { super(); }
    
    final public static String jlc$CompilerVersion$jl = "2.0.0";
    final public static long jlc$SourceLastModified$jl = 1227640386000L;
    final public static String jlc$ClassType$jl =
      ("H4sIAAAAAAAAAIVWXYwTVRS+nf1fKrvdH1xhfwZYQxuhC5hsDBWTzbILhQLN" +
       "dklkcVNvZ27LwO3c\n2Zk7u11WiL4ImmhiBKJGjRqNifKiJvCoCUQTfeOF+K" +
       "CJwaCJ8qDGv0TFc+902u5sWZp05vae75x7\nfr5zbi/dRk2OjVSL0cUCZTzO" +
       "Fy3ixNPYdog+TrHjTMNGVtvxzvZ1Hz1xOdKAOmZQh2FmOOaGNs5M\nTkp8Bo" +
       "WLpJgjtjOm60SfQRGTED1DbANT4xQAmTmDuhyjYGLu2sSZIg6j8wLY5bgWse" +
       "WZ/mYKhTVm\nOtx2Nc5sh6PO1Ak8j0dcbtCRlOHwRAo15w1CdWcOnUGhFGrK" +
       "U1wA4LqUH8WItDgyKfYB3m6Am3Ye\na8RXaTxpmDpHQ0GNSsTDBwAAqi1Fwo" +
       "+zylGNJoYN1OW5RLFZGMlw2zALAG1iLpzC0fq7GgVQq4W1\nk7hAshz1BXFp" +
       "TwSoNpkWocJRbxAmLZVstD5Qs5pqHW4O//t8+k9VkT7rRKPC/yZQGgwoTZE8" +
       "sYmp\nEU/xLzd+PnnU7VcQAnBvAOxhxh68ciT146dDHmZDHczh3Ami8az2z2" +
       "j/wPWx79sahButFnMMQYVl\nkcuqpsuSRMkCLq6rWBTCuC/8bOrzo09/QH5S" +
       "UHMSNWuMukUzidqIqY+X1y2wThkmSaJGCi+IPG9Q\nIiJvhLWF+XG5Lll3vM" +
       "9/5e8dKOg4K1oAttW9xCQ25kS3SgJ930IoBD71B/uDApn2MaoTO6u9f/PL\n" +
       "pyYOPHdOqTCkfA5HkWSGuzoxeXZ/cjKbPJhOoVBIWrx/eZQibbpg988fJzpf" +
       "3OZcVlDDDGozikWX\n4xyFYMKYUrZA9CyXtIjUUFBWHmgTzgGDgIxZCoYkY0" +
       "sWmrfRpiBTqv2VhBWG8i+NHkIXBideE0UV\nRegR1j3XIKUnPd/Csczs/ifP" +
       "bWoQoIVGhJCIZPje1rNaurv30Ht/bPjQI03QobTNNKLDaKgqZLc/\nvPHQWz" +
       "v/VlAT9ANMBI6hptBeg8F+WEbhRJnvHG1a0V7BQxL+6BCpUlJoTZ7ZRUyFGb" +
       "/f2/lxmy1U\ndyQn1ohHh0cP8RgS+QpEJEfPb8mz+259FZ1VaqdUR804yxDu" +
       "cT5STfe0TQjsf/NK+uULt88ek7n2\nko1K0omeEJS0u07bxft6zl+MvX7Dr2" +
       "F31eiYbeNFUcLSM9cHXv0CvwEtCW3iGKcIUAQ+yw8Qzy1y\nHa0RlqWCUcF+" +
       "mBTz2M9rMbf0+9U321XPD6HzQK15VT43lwnEUSvOAV+wxn371dMrejYauNu0" +
       "k5P6\n7OO/hJ/F12Y9enUt760J0y3+sHiVbHn0he/q9GgbZ9Y2SuYJrcYXPO" +
       "2gvAX8AN9u7tIbU4/0BQNU\nwM+hVTWzGr+S/fXG6NdRRTCu6ghQzSZwOZoi" +
       "JLHTIvnVL62vBdviOyASJpMW2iHj3wNMn2b7ocwT\nJZi3cVFwNar5s6zgz7" +
       "LYrp2j23epcy52jDmXcRJ15P2tWm6OwivHGCXYVE8Y+WHfVZaPHssbJqZi\n" +
       "Ny7mDLSpYWqGhekSLuZOS3Rmq+qBvJnvCdjsZExdMvJqlKlGxZzqz0KQVdaq" +
       "pu5WoxUJS6heGuoc\nekTUksy5xjymgJ1mUQgYXCgQXpmymWhsq3QrljhdNp" +
       "TH1CGJ0zGr2rCPreShwlGzlwxYeMmp3wxK\nudLidwQujpV++qJO2X5S5iVn" +
       "9e7iaO3y9Dsrb2s4owiX4Xz5tn5p8N1bn9yc6lFq/tJsXjn2anS8\nvzUyE+" +
       "2WaKuNq50g0dce2njpzNS3OUF2oTfKUUuZLzKG3R5FxT0KYfQJeoq12Oysyf" +
       "l0nZyL9bh4\n7Fk11+LnXvFI3iuDEZFBDTt82GeEX4xWf6NU71K2LM/8/wIU" +
       "cAsOCwAA");
}
