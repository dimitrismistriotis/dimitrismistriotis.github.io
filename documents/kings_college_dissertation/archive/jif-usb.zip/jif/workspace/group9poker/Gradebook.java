import java.io.PrintStream;
import jif.runtime.Runtime;
import java.io.FileOutputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;

class Gradebook {
    private BufferedReader file;
    
    Gradebook Gradebook$(final BufferedReader file) {
        this.jif$init();
        { this.file = file; }
        return this;
    }
    
    public int[] readResult(final jif.lang.Principal S, final String Name)
          throws SecurityException {
        if (file == null) return null;
        int[] result = new int[50];
        int totalExams = 0;
        if (result == null) return null;
        try {
            for (String str = file.readLine(); str != null;
                 str = file.readLine()) {
                int i = str.indexOf(Name);
                if (i == -1) continue;
                int x = 0;
                loop: for (i = 0; i < str.length(); ++i)
                    switch (str.charAt(i)) {
                        case '0':
                        case '1':
                        case '2':
                        case '3':
                        case '4':
                        case '5':
                        case '6':
                        case '7':
                        case '8':
                        case '9':
                            x = x * 10 + (str.charAt(i) - '0');
                            break;
                    }
                result[totalExams + 1] = x;
                ++totalExams;
            }
            result[0] = totalExams;
        }
        catch (final Exception e) {  }
        return result;
    }
    
    final public static String jlc$CompilerVersion$jif = "3.0.0";
    final public static long jlc$SourceLastModified$jif = 1227640386000L;
    final public static String jlc$ClassType$jif =
      ("H4sIAAAAAAAAAK0aCXQV1XX+JwuBYFhCiISED4RdkrCKxKohbJEAMQmoQf1O" +
       "5s9PBubPDDPzw09c\n0aKox6rHpdpTFS0q4la0B1s9tShWPbXaoq3rERWt9d" +
       "SlSkXliKe9977Z//ywnOaceZm8ufe+d/d7\n38vDX3D5hs5VrpOSNWavJho1" +
       "Z0rJFl43xESLKve2w1RceO2qu+754/xPX4xyA5q5Ij5tdqu6ZPaa\n3NDmdX" +
       "wPX5s2Jbm2WTLM+mZuqKQYJq+YEm+KiSW6mjK5cc0akOqSVbNWzJi1Gq/zqV" +
       "parLalUeYN\nA9AKaNbYwF3KRTI6F7MxrE2xHREw29LMe+vKdp63a9gArqSD" +
       "K5GUNpM3JaFRVUxYooMrTompTlE3\nGhIJMdHBDVNEMdEm6hIvS30AqCod3H" +
       "BD6lJ4M62LRqtoqHIPAg430pqo05r2ZDNXLKjAk54WTFVn\nO4T9JiVRTth/" +
       "5SdlvsswuTKXU8bfEpwH9gZJsDE9yQuijZK3XlISJjc2iOHwWL0cAAC1MCWC" +
       "vJ2l\n8hQeJrjhTPIyr3TVtpm6pHQBaL6ahlVMbnROogA0UOOF9XyXGDe58i" +
       "BcC/sEUEUkCEQxuZFBMKIE\nWhod0JJHP6sKin+8tuW7WJT2nBAFGfdfCEhV" +
       "AaRWMSnqoiKIDPH7dM0tTeemx0Q5DoBHBoAZTMPE\nJ1c3f/qHsQymIgRmVe" +
       "c6UTDjwuF5Yypfa/i4aABuY6CmGhIq38c5GW+L9aU+o4E3lDkU8WON/XF3\n" +
       "6wvnXr5D/CzKFTRxBYIqp1NKE1ckKolG670Q3pslRWzi8mT4BZwnJVlEzgvg" +
       "XePNbnrPaBz7KYGn\nEB+TG7JU5xNip6qurwFfRLDhGRxLNkYisKUxQYeQwZ" +
       "aWqXJC1OPCAx/96eLFy6/ZEnUMxFrG5Ioc\nslwkQpRG+ZlDaSXQdz9/vH7o" +
       "z2YYu8DJO7giKZVKm3ynDDwU87KsbhQTcZOsYZjH8mzvLe4EwwEb\njMtAiP" +
       "mwxvXo3PiggbiO1ERhQhAvmreSu7Vq8S9Qlyj7UqTOtgaSXM/2Vjy17fwzL9" +
       "wyfgACbcwD\niSEn431BK4R2XOh9duSCp3YfejrK5XdAaDIWiUk+LZstjQvV" +
       "tAL+XupMtYoQCpRmvlOUm7nBzON5\n8Frb7wo1gXBMblQzrGt5gozwtYQFYh" +
       "isu0QQrQqss/rIIogLLSNGrrzv24qHmEEHpdaiq4KYgEDl\nIsTrZo9buXXW" +
       "IeALfBV2a8Je0fWrgr7qc696yxdNbnyW6wcXqbfDGnKSB8wlVT3Fy0jGlskg" +
       "s1tX\nN7ozZLBD6H0o6Aj1dBI8g/Ehi/aYNQ4TUN8BZili/qfp6mWfvDzl/K" +
       "g3uJZ4kk2baDJXHeaaS7su\nijD/3u0tN9/6xdVryVaYsXAZ2lNZBExyREi0" +
       "qCkvveW2qb9807bBES7RBl3ne9EEM5teq7zjRf5O\niCTg3YbUJ5IXRxxrHO" +
       "VaIxmAmGDBau/g2Vtic5OlUS4KqiKDgWxGXlIFMQkx7L+LSDTFjgBPgGdS\n" +
       "iABhtdHuakQSNtpFy8aFa84d/fjW50Z+EUWtRQXJ5Cqz8oGa8OrZDRmg07QG" +
       "gZ9M3dpitAdIjAmS\nWMM79oupYFRwP9ZmRqwsPvxDxeuLiPvBCdEQdEnDYG" +
       "otV2CqZ4KwMRGSV+m8YshQOjCfaqePizOa\nXh+wLRTN9BDRmNxZuNGUqmvd" +
       "khCjvcTUZIwZb4zXu9IpUTFjGJdx3pPaY1M6kWsxEeM71R4x1tkb\nu0hbEL" +
       "tkKoh7IrFnb66mkVcU1QxsMS78a9WXu/s08SXmxmP9OFnQ4x6t/Kr64Qsmkt" +
       "WRO5gsX8B6\nFUFxtvCSbol0d+mVt15zuGQpiXQQMJCESk0SelFJwcjU6HzF" +
       "8IRFSJcNXJkF3OR+ZuKe64h7fA5L\nRG+Z4OfT2amX17mXf/rNE3/fNRl5Rc" +
       "x6wKsK8tgqQqrS2QYApfqjB7/ePPB+YjNf3Ujhbaxn0xpU\nPYKk8ZC97Tcs" +
       "JHWigossASWUZwnSIl+/Nc2rlYcEe0dDNHSrahfcIY/FJ59y1ogLEw9c3rP3" +
       "nQv+\nRtFpCBWutiuY3ImeHbZ4P9U7JhEk71KeObK8PHZAHESUHdeYEHANBy" +
       "G3e0yApzo8cowNqgv26FXV\npvu6vvvx2R0H7WB4ortnHz9x4cXCroELts37" +
       "ZgBFNk8SKvfIADOzp/q0yt6qXFJiVW8mu+DxxJu4\nMP+NnmEFv747FeUKIa" +
       "2TD0PLsYaX05gBOqDcNhqtSdCQ77u/dGZ1Yr2nRJ0TSHve2JiHW3EDtStu\n" +
       "fCrsWs4jbo4jx15DgBNpnMJS0gATlpEUHlJxgZbuBJuEF4OaGIhhERR8sFAG" +
       "taegDu2xCuWbqrZ9\n8sRHraVRTzcxITure3As2VKOIWsf198KBP389HEPX9" +
       "q6r5NFtOH+0nGxkk79s3ePOPnU6z8MKz0d\nE2d1LLIdzfjrNtcL2lXN4wjL" +
       "Pnzu/c0/L3/Z9s7ltN9JftP1ongt+K1No/dNP+kGKwwHw1MYxq8e\n+m5b3+" +
       "T7u2ybzwpNZ0O/64amn07b8u43v5k9xhOaKN6Az24kQBZ9cFyKw8KMk0ICXC" +
       "9UTVP1xpZZ\nL9WNati+YqfDuIM/1c9HANPLzczie5/5x44Ht9o0usnwZIsS" +
       "/lKwo/BVz82qwMuug5VesvDkB94T\nd7ICTPYWtEGzDGC+cFvXnLsfeyzfXr" +
       "wdh/mZCPMEM9sTIvjeQbA/oflaHGbSxMlZRxNt6U7D9PSZ\npaduOGW1tOos" +
       "puupzt7EjFlDkdlCDeLdNvWznul1V9xJKszr5A2y20Jg1kBIk4vlPrQgWsyP" +
       "Bjkh\noNAKAUX4QJBZmE5i4Z1gSQ17Oii6DalrhqELtRSAJLU2G4ioXkRUR5" +
       "hcGRWiklrjB6Q2KUsqceHp\n9w7c/OWavotJayXECGXiNsbSJH9YtpCq2/xw" +
       "9b7jl1A5Qgr8YOi/v71s/3Tqq22ReQv0FbyWVaAv\n441umM8vfOfZPWUX7o" +
       "W0sYQbJKt8YglP7RDIrVsXjW7oajPa6WdQh1y8caAVXyMklLMcgY+x0hwJ\n" +
       "HCcvweFSO+ZuOeaY20ywF2jMRSDvunZ/mbeNOM3ZQiU840KrIvzdSONii16T" +
       "g1UFz9iw3Iy/Vrn5\nQrQwWSpah8MtGdeVb7FdOWsmE6hkcut6SdF/618f/N" +
       "4Kq97olozqOjzFCrOTelakbia/JCu1uyoc\nT6L3GSglS1aRiKfpcjfTYBhQ" +
       "IkADcOqoLfv/UvlqO4u5QWwmaRyq/eJkU0xAnveuHDPrPDOy513J\nMXOaFq" +
       "o9WfOh+f5aZ/3l15fzlyUlPA4J1jRL8AzRDp2pzosO7rlrUMyVR4XTW/pjtQ" +
       "8tLkS3f3D1\n1PKStyGUdXAndPNGkwJJHE86Rf1IwTtAqu+Z1Xd9/4q5j+zB" +
       "regQexyL5o4VF8Mzzet+lhVbgf6l\nkEBvcoWQ+aCihaBidToU7300q0NoBt" +
       "wulgOsf7cbZ7UxocT7d7u9HvvZm2U/vhmS0sU07qPIQbOb\naLwqO6a5kcpl" +
       "r8KKD8fG3hgrHh0He/s97O3PYm+/G1Xw9z04vI9DCYfjX4nXyZaRu6GgwnZk" +
       "yOC5\njompxLz6nK+Lr+KfP98uGDqhcjRVbYYs9oiy6ztBIivoVNw23XsKhi" +
       "fymueXhzmPv4Dw48WFl98u\n+WrxnJc/+f+dEJKvhR8Gju2XibhgPhk/8Oa8" +
       "t6ewqsR7KsOItfv6j5ij/MFWLqRexKN8UhMOP+So\nu9aGx/AoK9YD7jkFnr" +
       "khqxDALB/YySFgJtd+VEczbTjJLj1i2My3igZIP/fpDFJfQOMhHA57uMbh\n" +
       "xyNzCEMkarGB73lIIpKPQ8HxEs6O9quV9Qr0Cqz+nPXGK39+fVHmUdvqoSHD" +
       "5YaG6yPiaAwgTLQG\nWyw0xXEerO3ZuTSkobE2Yx0pfbRzzqvK7Vt+Z+9mLu" +
       "NXc2UbKfNNQbnUFghbM3NYR/9haxY8s3PZ\nVL9hK1Lphi37XckxozOtstwU" +
       "mYZTaYeFftWPA3b0kek4jHHQL8S3GfQW8JJT4Gk8spcg2LJQLzn7\nqLxkJQ" +
       "SH43EU3HcxpF/ED2jw9Bw771+DmNMajk+D8zwanJelwXlZGpxpa7DR0qDLBS" +
       "mx1qNEaiAj\n9DrbUeIiHOYSBYKEFmso9Sd4GFTD7lHx6xIclvbriwGtF1qF" +
       "vdX+jWwThTTekS/OCCKdd7MOcLKv\nA2S3t2GQ5IW77D1WePYYhCY2RwR2g/" +
       "mgPJdOXIWX5gDrX+Ej4Sk7PoW3exTenqVwZyb7ZpmuYVjk\nPO/LUfzv1euH" +
       "0vWG07kXBa/ks2/cfRfpJODBPoENz8UT2ZYQFN4JOVD6F16JjXHswkt6hJfM" +
       "Ep5v\nxtPEDgA5aJrG2d3YBl+K8GQrN0M08rIs6o1OgRMXNpZd8/m+BbV3U1" +
       "8wyDm+8ojSPQudDE8dPMPw\nCXJI3WBl2EmYc5J1x9qbNKWuQfL3he4926Qw" +
       "7EW9UCxJgucg7eC2utY9N+y8jB1M4tV72P1IgwD2\nYbTAV3aes9xhowae2j" +
       "A2dG6a/yQuuLb3KO6dPcPqllZ1XesexfkuAayrO2cTdJY2Onl9Yd27vx3P\n" +
       "LuIVKIP1lWkZas6oLIVc8PrO33yXeZmQvO+u1aqq5uZZVZe/JS/qYadn2XeK" +
       "DnBV+YgPyxqKHon6\n/o8CVzmBjgUiV2DpH5mGSTVwPdmQNru9tqQ8neod8M" +
       "KJNUdjS1gdnJbblnDJS0IDs+twp8Lzk1wk\nmMNlgq49wTLjY3NtbEknHp9r" +
       "e851IlnnOs4M5QSTi7ZN3uCvRY4yA5pcPuZLwmZJcMNRpjmEa2Y5\nCV9XeZ" +
       "MOvrbSBJVTEd4TLa3IiSOaZMQ4ciRCMELoO6KWI5eR5RFc5EoaN/tsESTFPl" +
       "6Hw/X9EsTJ\nGzO08s3EaMb7zzOaFlIvsMsj+3zHT9XbX7gmMseqkYP3REET" +
       "cTGwkZqfE4NG90i00uq+wq+hIs8R\noP9IFN87cFiLw3l4DtpGNoWDfWeT8f" +
       "97A3bRafafe3Hhc+2Cpe+2vr/DumzJeXDsYpzzyNpY5rr2\nG9ntiSDzfX24" +
       "WCFkaFbkWqHAez8VpGbTkj54I3ntlR+XOLe4OAxjjZqllx7vqVcWHXxfM6T+" +
       "reVP\nPbU9eHhg/9sIkvCw77uvnDPlYOH3rxw4w5+tLO2TQknymf8BTZTbCW" +
       "gpAAA=");
    
    public Gradebook(final jif.lang.Principal jif$p,
                     final jif.lang.Principal jif$S) {
        super();
        this.jif$Gradebook_p = jif$p;
        this.jif$Gradebook_S = jif$S;
    }
    
    public static boolean jif$Instanceof(final jif.lang.Principal jif$p,
                                         final jif.lang.Principal jif$S,
                                         final Object o) {
        if (o instanceof Gradebook) {
            Gradebook c = (Gradebook) o;
            boolean ok = true;
            ok = ok &&
              jif.lang.PrincipalUtil.equivalentTo(c.jif$Gradebook_p, jif$p);
            ok = ok &&
              jif.lang.PrincipalUtil.equivalentTo(c.jif$Gradebook_S, jif$S);
            return ok;
        }
        return false;
    }
    
    public static Gradebook jif$cast$Gradebook(final jif.lang.Principal jif$p,
                                               final jif.lang.Principal jif$S,
                                               final Object o) {
        if (jif$Instanceof(jif$p, jif$S, o)) return (Gradebook) o;
        throw new ClassCastException();
    }
    
    final private jif.lang.Principal jif$Gradebook_p;
    final private jif.lang.Principal jif$Gradebook_S;
    
    private void jif$init() {  }
    
    final public static String jlc$CompilerVersion$jl = "2.0.0";
    final public static long jlc$SourceLastModified$jl = 1227640386000L;
    final public static String jlc$ClassType$jl =
      ("H4sIAAAAAAAAAK16ecwrWXaX3+tt2tMz3T17MtMz38x0Mt3x9Cu7quyqymOE" +
       "bFeVXYtrt2uZtB61\nu1z7XvYwEQgpExKFdQaxhkUgJJg/CEjJXwGkRCCxSC" +
       "gSRPxBACUKSBAkQECQgFD29763fO/NtCKw\ndMvXdc899yy/c+6tOv7ubw1e" +
       "KovBVZZGRz9Kq3vVMXPLe4JZlK6zjMyyVPobD+zJXxl/6ud+7Off\nfGHwuj" +
       "F4PUjkyqwCe5kmldtVxuC12I0ttyjnjuM6xuDNxHUd2S0CMwpOPWGaGIOPlY" +
       "GfmFVduKXk\nlmnUnAk/VtaZW1zWvLnJDl6z06Ssitqu0qKsBm+wB7MxgboK" +
       "IoANyuo+O3jZC9zIKfPBjw/usIOX\nvMj0e8JPsTdaABeOAHm+35MPg17Mwj" +
       "Nt92bKi2GQONXgC7dnPNL4baYn6Ke+ErvVPn201IuJ2d8Y\nfOxapMhMfECu" +
       "iiDxe9KX0rpfpRr84Pdk2hN9KDPt0PTdB9XgM7fphOuhnurVi1nOU6rBJ2+T" +
       "XTh1\nxeAHb/nsCW/xL7/2v39K+B9Xdy8yO64dneV/qZ/0+VuTJNdzCzex3e" +
       "uJv13f+zal15+7Oxj0xJ+8\nRXxNM/+hX9iy//7vfeGa5rPPoeGtg2tXD+z/" +
       "NfvcW78y/41XXziL8aEsLYMzFJ7S/OJV4eHI/S7r\nsfipRxzPg/duBv++9A" +
       "/0P/A33P9wd/AyNXjZTqM6TqjBq27iLB/2X+n7bJC41ODFqP/qNfeCyD1r\n" +
       "/mLfz8xqf+l32eD683rfXjm3avCRVWE6rpWm4b1D4J3J3ujO14+0d+70In3u" +
       "dnhEPZbWaeS4xQP7\nr//6P/r9BPOHf/LuI4A8XKYavPqI7eDOnQunTz+t3N" +
       "lazhnU//Fv33/jj7xX/vzdwQvG4NUgjuvK\ntKJeh9fMKEpb13lQXdDw5hPI" +
       "uzi8R8trVg+cHoMPop7RBai9ik0x+NJtgDwOK6rvmb3XvzHjBt/5\nPPFnz7" +
       "482/4TZ+7XovWWDK9le+1d+X369/3kl144E7Uv9hY7a/L2B3N/YAsf/yT31/" +
       "77Z//mNVZu\nCyQUqe06fUZ4POHBGPoi95fA/3l38FIfBn0iqMzelX1Uff52" +
       "GDyF3PsPYV4NvvRMVN1e5P5Nxjib\n6i47+LCXFrEZndnchPmw2hdp+/jOBQ" +
       "sfvvQ/+jvXn//zsP1Onw2WaZz1SCuuVm4vq1m5TnaNnvPl\nC2ez3lL8kpj+" +
       "K/Wt9W/+43fev/tkDnv9iWQnu9V1RLz52CtK4br9/X/1p4U/+Z3f+tbXLy55" +
       "6JNq\n8HJWW1FgdxdBP3Gnh8DHnxOd9z7ziW//qXf//K/e+Pzjj7nPi8I8nl" +
       "3e/cFfeevP/EPzL/SR20dT\nGZzcS9Tcvax098L/zV7xPlbunaHYezJI7CAz" +
       "L3nmvRsBztcfufRH53i7TB50D0fPCL0dV+Q5rd/4\nKba+8d9+6WeHV9dynu" +
       "f8wIXDy+WzaeypiQ/s09/d/uxv/9Pq1y6mfYyiM4+3umeX3ZlPQBb9F82b\n" +
       "L/+tvxjfHbxiDN64bEVmUu3MqD4b3ug3k3L58CY7+MhT409vDNdZ8DEyP3cb" +
       "mU8sexuTj9NI3z9T\nn/uvPAnD3hCv9e1H+vbquV1y1nXiujPIzh3sQvily/" +
       "WHHmHklawIGvO8a1+nxxtffuqCgiC9t6i9\nc2A5ktunrovJPnKhmZ4vV92d" +
       "nsdL0L3xvfH59/zZNV7ox70guYbCV3pQlpejQr/epw+R/fZNrOz6\n00Kf1d" +
       "/uIXQjwhsXES54ut5Un7N47/uPPiZj037n/enf+GP/5I9++V/3vqYHLzVnP/" +
       "QufoIXV5+P\nJj/x3e+89eFv/5ufvqCpt8Rb//zNn/tnZ670+bLst+2zdHJa" +
       "F7bLmmW1SZ2gP2U4FwGfBVwP+Ljf\nlpqH++Yf//xf/c2/8+vSJ+4+cbj48r" +
       "OZ6Ik51weMi0eHWdev8MXvt8KF+pdHX/zuj0u/Zl0n0489\nvZMQSR3/u+Mv" +
       "uV/5PT/zb5+zE70Ypc+1Z/UJew2X1Pzmw4zNpSbuJpo2ott6oZP7ZUDJBA5L" +
       "Tlgs\nmY5J9xZNzDdinIrehJ+WmLCoLQHHhVM7xuzh2GTSblasMydTSHmcw5" +
       "E5XkxKrJL3qmBpZppDBSGp\nFebIkRxqUcC4GIYgBgAc24Tvd1UjRmvPHTmA" +
       "gwwhtME1CJ/uy+muyHiZU82G3qcTY1zQZARDHSGz\nTOOC7USyXR7M6xEyhY" +
       "FO0ODuOJ/mU+owrZy8nhmCaQ4hDo8drRW0aQnSVgyqCrsZxUadM6JO5yOd\n" +
       "iEdMIKuz+MBMbXtshnwu7yxOPdHBZJUDp3yXmQVrRltX54ZzbM6YnKW3JMRI" +
       "CjUjkU1XEGC3logW\nxNiNO2oYJ5tBJubPi1zGmelqy2UbiDZJabft9DTdFE" +
       "ofCUpEQMPVnqI3znqB7zhi4xDxbE81MjSe\n58vUgfrbs4iGNzOQlfIqzdeU" +
       "MPdhaJzl6XhagAbOaSxzmIdTWFXIXTLkYQWjg52kVHtgKjtRU5Zt\nrTDaFr" +
       "U8ImvXmG/QJU5gR7EODgYDaREl0wcbDPh1q7Jjez5fTjZLddnQYDRE96JLF4" +
       "e9IlDHAlJ2\nVRbPsrW4MNmZuY92GyuR+NSfj7c8T2LaUVvh7hQNFvYSKIkt" +
       "sQ2XhNjVBrnYMBQxVPtz9Jim18Ks\n7NE8QqtaRVRaAZPFnFx5jrck9ru5Ka" +
       "kbOcnTgKFwYY04m3GluG7cjcUpni7Wi3RuKBuBGNITG/KA\nfF2Kx5jypXjn" +
       "2rOtgh/ampzqx8wzgQA254tany3j3r45hNrTlTpiMXM7SmECivBwi6o8B2gk" +
       "NJy1\nTaIVUxxYnhhSkbqFTuXZhGOIiR0yabSaIWMRyspIUk8BGivwwmgTeh" +
       "cRJ7/xNVfgrKQQzMUJYfRV\nMiQWI2WF0NtpxwXZLK+LlvQkFt+vpI7lQj0o" +
       "mW0n6q7YGqaaa/RywgvLeQdgM5cljzPAIJLtpiOL\n1ZRK7WEZtaGYSauREe" +
       "GmrInOCQOaNZKeQF2vUZzmET9gjB0TQ8cEx9stijCltRcV2+BL3Tis0fjU\n" +
       "sC5MtC1hDQ+bah4Icds1WgoJge9bAT8hpL24nzdx4co1sstRGROj4wHZ5gpf" +
       "+f2SGwDcHY4TxGtP\nLNYePX++tOwWHwYykcDQZMHAEqjxe8yp5WUG6Z57KJ" +
       "ip5sxNnFKDbThijbI6iM2umrMjrc42lZ6K\ny0yKm4jfxkiyOPHcdIiShYW0" +
       "6cTXFhsrEk/Fqpr66amtdJHU90FZj0WxEPOyBAqKSn2WlblVUZwa\nEM7XMU" +
       "H02cYMcpjRfQKPhlSpFEaKWbWmqZQ7Z73FDjRR2h17auEXSG7PsNmxc3qvHd" +
       "VZa2u55eGr\nhJEXaBvtFIg8jg+rqAz9clJpQ663tcH2Mbgep7P5YeIsKNQH" +
       "iH0AmDonwsqWQxdGEAVA7mWzWPUa\n/BQBjA/VtAGHIWiZOK2tXdOUkbIeBg" +
       "ccgOpxxWHArHN2xXFn6qU2N8CIMxZEd5SIYJwvw6ZxVTC3\nMHSMWAtCRqRF" +
       "BCUuRhCbaeXmyOkgeVN+GCwVH9KtLT2lNKnrijW/M6kunscrfGHWgA/u+l13" +
       "ykdb\nGWbygMF9tVv1wU5uxLBD2BEr4wp58BeCv3LkYTBf7CtnXZuhKHNVRh" +
       "5RkzRR2AG8gzodGyNiq1aS\nqNHTZX5C05WJ8oWBS7E/RsSVb2AbyMmCau5Q" +
       "h3ksD9XNBsHSOtNJqRUwI5bythSaDu/cmg2EZrF0\nCNEhElxfpdUOXOYGzL" +
       "QbaSXvRjGql3uRPyw9M3eF4MSbQ20/allJ4bBFvx7XGTW32uZx44T75aGx\n" +
       "la1BtYYFn7Qao7Jtr9GKdjooE0x9spmFatkR7gaZSHA3qUJrWI/3FsFWfVDv" +
       "EaogE2s2i8OdvZ2I\nXbmREdTEVK0GyjEqa3EXCxhPJiLczSqAKWawWMZhpU" +
       "r81C81dDEbkluyq5qlbKXR2BnFu2oyPdUr\nMQs0UdzQS0IOx7IbkXRrH7az" +
       "9YlEKYmUaZvT6JCEeGlk1Iw7g/eIN5+yw3OIw7yngGasTZBY84CC\nIyDA46" +
       "RoKtndrGVKBq38XMwLGRT1eeblhwUCuIKwGOkHzoO2h71ldsm4y7ZDQWdC1F" +
       "hiiGKX9FoN\n/LQs57K67dOWTEUjgLPBItJtwh07OLeWC3Pv2ZQOkPQUO076" +
       "8CJazIYKAUrEZjSUKjJbLtT+kFHr\nEBW7a8uABWyL0HsiRCZM/7DPoMLamK" +
       "8Jebt2XJ1Yz7nFcQW54+M8O6WonbZc7jfgjNR2w6ypZ03T\ndKA0XiPqAk6L" +
       "KlmfsA62tWWR9q4pIcTwFyQXojLTeNQc508ZkI+P1SzXyH5fU9G4HuFdR9fw" +
       "cCOM\nuCQmyAaBEdLdMpQJKvhYYEvd1MZTf8HnuM3t80p2liKC1ICzMiZ6AS" +
       "YSPVbkdX9uoIO1ChF4JVf1\n0FsWpVrCByuFD91kivsLLks2tDz250qUEdt1" +
       "RHe+YdULuiZImDdX1H5PSBJakvNVZbo+XoPdslat\nvDCwIVpK68LsN+GT3V" +
       "FK/+wJzUtwx/CUWnoTDGUWAoRia0LQsHxWTDmy4tejcbLqwhDBSsgVeCHZ\n" +
       "zk7ohjmNnSEBOhOWpZyTdyi4ymbBSOPg9sAKyakG7DHAQoCBlUjUpxXaq4RJ" +
       "f9CrRsyESwGHE0bh\nimnbdTvZ6F2OusNRPLWgkYLU4NE6tRlnjHlgBptx0u" +
       "catIahZhpi3Z43GW42P4FwKC4MzCaPTIsy\nm3BMLbUltlV2wqTLDGPIYirX" +
       "n+1Heu7hNbUBJjbWO19gT/YpcKfAtIPhdYWl47pMWoMqZSBi2hRY\n7E4omL" +
       "ebuvanO7ds8HCBwcrQQailIuhqRaxO+Go5sslGS9jSc48nTytaZw/ExlLYEB" +
       "usVKjm4IrW\nHEj7Z6b1ypK7TWRIHVfNtgiOCbIxzEyn5lfqpOLTMqvr7FQh" +
       "xIHsN30nWuIu63CNekrqaLLDOpop\nT8V0Dh7BMe1PwgUVwk0kFKKvlkdhcQ" +
       "j3w5SbM/OtBov0woiJaQAbE18WJwgfBDPcjIp93gNXkuc0\nuwVXcJBqobSV" +
       "pnt7JalBGBWHxUwEmW2Z2+46G2ItYgN8f5BNK9o8asRypQVcacn0GtOrbJmD" +
       "QNdi\nFnKIJvOp6BeozgdAg0xKAFLyHAQlV2zGpHVUd+a8GcLwpI43aOPxni" +
       "GoWw1J1XGpixbNVKjuRwIi\n4VSxK7WDiqTmQTBnqiPuJ0fUNuc77bgJI3Zj" +
       "+/qoG+9berhe2k3rkjLfZybeNXVwfGxJ8LCRZLyp\nEwPon6I4fgMZYrBF4T" +
       "FTUM3JkXkuCCYzxZ9syRMWtBB1BHZFMh3223Wrypm5RzfVynF3FkI6vFrG\n" +
       "xGwf2nU1kx0SmE1QD+D63QlD0ig95fzhRC4LXnEjM7QCE6CX9aQ+9qcgZcZC" +
       "K9mP5IkpBYyX2QdP\n0Rd7kQrnuM3nKes1wLaJch6up6LaxqZ0zAGXDrfjbp" +
       "40br3GhULA+eN0AtHDjcabZJ5iqsfvR97U\nNAAomky9U3TcRsIcpicHiUXn" +
       "JwnPwD59lTxSRMV2c9xJsKaoQHaoRLRiQxnyIHwynAiMXB1XW0eb\nJ47Arc" +
       "K2P+AS6EzyJlSrVPP+kcSYaA4GwPn0MDotCtcX3e7ITlN4R6Kb08mtRtF+Z/" +
       "neLBqGxKKx\nU1Ucmctgby4CR0m3CDQe52MuXVRtHfl86SG2ZSDbLrUVxEFq" +
       "bN00RgxugWYfy+NyO0ZygRIt3hqa\nbJvzM3Ma2llUoAyDo94K2vvFej9eu0" +
       "CJITwk6PEIWE20FjuN4YbC8KXuHTQ40Y6GKdWzld8mRnjk\nl9PhoX9U6djT" +
       "LGFGbDFiPAFD6xWe7+2DtLN0vcTS4Dg7VQsqaNId14KQVjL7wDvGtavtT7HQ" +
       "wHgL\noyoZ9fOGI7XoEtoGRt7IIWim2Uvo6lCDWmDtfWEfAihvotXMbfNS6k" +
       "+zPFV5zewwDQ7AhlTZXHI7\nhkO3+w0vjOR0WGPmqgPmKYPpOHIIyaQI93mH" +
       "z9kFoB9l0qcrZ7Qj7JOlHGj2MAnAzREKfIMSAC/D\nSdoT+c1+PZ8i9cbaD7" +
       "sjd1oSm9AsVgsEiigqYwQRXXdEOeOxvN5hYjHuD0CjRNBWDISNvN063jpN\n" +
       "nsprfKqbq9lRCMx56yusuBqqx3bcaYRb8JBRK3KYWgSod+PMs6TTKW8YZFeN" +
       "jBEWszWn2eDWYjyO\nE61kS/p7awNxugRge7PT0RISjOGOxfbMhM32AYRodt" +
       "ilJ74qq3Yb64Zi6i7pVaowh6xx6IbwYb0W\nWVSGVp6oojStwKsQLTPbB1la" +
       "ZE8JMszZLqRFeQ1DxBZa211GAgQOHlps0SLIZITH3MY8hCMcPbVm\nQrtRq0" +
       "XGKusyE8GlcY6zCznuJjlHmMH8MMTwwtq6VLDmdXmhMwQZlykmO/CKVHAkWn" +
       "ezjrKjxiqC\ndlWRk5xsHG10UFtlryhuKAP8csk4DrLh7f5JfjgHZagCV+KU" +
       "UhEEn6iuoOv7pQ5KrQT6QOwLtMNr\nlKpNfbzQRsQBlkNESFXI7RQ3yXetcb" +
       "QQI4trfXcIhwIPsFvv1Ez6BDBu1NUYCbWFCYQlCNie5GU0\njy+ElOBO6FYB" +
       "jf5Jg4NpfofPyMmMPmjrsg2r2Z72NkQ2bYZdJRC4P5+adLECHUhfRCMGXYkF" +
       "N96M\n0YIqZ+mE96WNxmWGgwLxaGHtoO0EbY94PELTgyyItYMTqCNshHa41G" +
       "gKUhcRSMS6PaUnHZZbHKPW\nosdCexfGwJnYIoSKbZcd7de2j7hLsK50jBsd" +
       "0cNisoGrHQIKE8pvcXCoW8p8B5lu2e/baWu64GEO\nOquZCfRP+DVrQQw/cw" +
       "RbyKOoz0Ru6XZeWM/NY8GDtuLQOsgnEaY7INJ0kDBka2rHUMIkUkPD7JVi\n" +
       "qZ2NCj2EoaPmGrHY8KN6Yub5tDaMneECtAzkuukkoOYyeLLYjXRfOHY5s06T" +
       "2RBI0eXuFC8O/jbY\ngXi2nsYrWdm1ghOLXFFjVS6iiZs6/TmH5rbOQZ74Tk" +
       "JbVpTg/bmLwstR1WYoewonbTiMN1zk5zDW\nKuxBh7jKIsJknWGFi04nVJQk" +
       "fAlvpqKsBIjBQfWykXT4OJ9mtlAbbBsbtL3hpOwQEyaoT4fLHdar\ns+Gbwp" +
       "IX9E4hHFhhTYgKZN40NiJsB9JyQ7ApP2NUaupKU4m0p0RqckBVErJCCtFs3Q" +
       "IaRpQKPVyd\n+HEfpYS5sZBT/8hCRlRTbsrDCDqtFUyzNMSPN6Wbh7oASQSh" +
       "2MqqDY3cI2BuhY2D8bjOR20+2lMl\nKg1TAaNIDkVsMmBbKILxKltxqYp7qq" +
       "ugHob0QS6Znum50Hpvj8Bl5o7ApgDwOj7RroaXenY6HblM\nnxYFOFxhSRXI" +
       "eH9+AmF1SYYmaYVqvp67J3SXrSwlPExhCkqqSBppPOvC/Lw7HIweKR3S5Dtb" +
       "XWud\nt5kpo8LdCUPB2mLueu8DWEmFzbJPFXWT4EKk82uo6Fq4nY4qlgcVMU" +
       "yOsYcuFEOxlqqfzefzr53f\nNu4evmd98/IW+FGd9WG5bf3su8nrt9j6s2+Y" +
       "7577xPnyta4avN5zePtRne3BZdJ734vb+79LbvJj\nbt2zUwc3pYzHhY4fuB" +
       "koBm99r/rs5WXut7T//NpPmL/8/vll7nmiXA1erdLsvcht3OhxheQ2k82l\n" +
       "HH1TNvjLL3/MeZFFP3O7RHIu6X/h+858YFe/8OC//OrsX75z93a9YVi4VV0k" +
       "ylNVh889qjqc+X+1\nbx8+tyeqDo8KXvH5Yj63BHTnugpx/vl7v3+RqBoMH3" +
       "nh7cfejB6JcV7+y31749yeJ8alEvr2cxe5\n+9jxF9+uny/LQ2lvyhOffaI8" +
       "4dp1EVRHorPd7FycPstbuKYjuWUdVeWzxflLZe26VvBj/+nT5i+m\nP/PG3U" +
       "txxzLLazPf/lfDs39aeOq/CBdFX33KHJ95jjkuBHx2/S1Vgxd6rlmW3TLmub" +
       "111vVSI7rz\nixeo4q4dKSndK0101QP73ln9q3fsm1qnf1PrfPdHwdn4R6/y" +
       "2iyDvE4r953ris/VdTXyqndh5JrJ\n1TmybuCXeu98/VIkunq2hPgNM7a+ea" +
       "HOvnr1wUTyDdF1ve16IH2ffPfqG4F39U56FTxa8+oRpPrB\nxz+u7KuvXb3z" +
       "eCy9/0jmfvBrV1VRu/cvvf7ywz/8HGm25wqMm9dBY0ZuUinpO/a9W2npqxeF" +
       "3v1/\n5SNf+Mjv3r8O0p7T/W8+7HpmVLr3v/nuE7XnP/Q90t1Xzhfy+ah/4b" +
       "qK9yg43ntOee7a1B8UwR99\n2uO3ofjKQyM/icVzQf0hku+c++ebX3xCoT/x" +
       "/0Oh8+WnPkj4c237bdssq8fGf14a+lDf3nwUOYMH\nv8vImUDQU5HzsDh71a" +
       "SBc0F3kATVO2e0fv19+eop3/658+X+99XiA1T80M0Ctz3z4nn57sm/r2TZ\n" +
       "tdH+L7V8BhovJgAA");
}
