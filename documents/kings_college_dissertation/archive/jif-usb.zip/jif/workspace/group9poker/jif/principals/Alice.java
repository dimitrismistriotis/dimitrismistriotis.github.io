package jif.principals;

public class Alice extends jif.lang.ExternalPrincipal {
    
    public Alice jif$principals$Alice$() {
        this.jif$init();
        { super.jif$lang$ExternalPrincipal$("Alice"); }
        return this;
    }
    
    private static Alice P;
    
    public static jif.lang.Principal getInstance() {
        if (P == null) { P = new Alice().jif$principals$Alice$(); }
        return P;
    }
    
    final public static String jlc$CompilerVersion$jif = "3.0.0";
    final public static long jlc$SourceLastModified$jif = 1227640386000L;
    final public static String jlc$ClassType$jif =
      ("H4sIAAAAAAAAAK1YfXBcVRW/2SSbbLIlzVezJtl8NTUpkE1LS6djOiMhTdO0" +
       "S9hJQoXUsry8vbt9\n7dv3nu/dTTbBcWAQGmAUHSiKo7VBxVLQsahlps5gtS" +
       "poBx3rCHQY+RDEzggzUEHasc547r3ve3fj\nP/7x3t5975xzz9fvnHPf0++h" +
       "SkNH0QNSOkYWNGzEdknphKAbOJVQ5YVpeJQUz913ZPnXWy88H0Dl\ncRQScm" +
       "S/qktkgaDV8QPCnDCYI5I8GJcMMhRHqyXFIIJCJIHg1A5dzRLUHddAVEZWyS" +
       "DOk0FN0IXs\nINtsMDEiC4YBbEH21Pgc+gIqy+uoy+IwleIaMWKu0sbHN6w5" +
       "8dmT9eWobgbVScoUEYgkjqgKgS1m\nUDiLs7NYN4ZTKZyaQfUKxqkprEuCLC" +
       "0CoarMoAZDyigCyenYmMSGKs9RwgYjp2Gd7Wk9jKOwqIJN\nek4kqs41BH3T" +
       "EpZT1r/KtCxkDILWOJZy+3bQ52BejQSK6WlBxBZLxUFJSRHU6eewbezdDQTA" +
       "WpXF\n4G97qwpFgAeogXteFpTM4BTRJSUDpJVqDnYhqLWkUCCq1gTxoJDBSY" +
       "IifroEfwVUIeYIykJQs5+M\nSYIotfqi5IrPzcHwfx5IfNwVYDqnsChT/auA" +
       "qcPHNInTWMeKiDnjpVzskfHbcu0BhIC42UfMaYbX\nPXtL/MLPOzlNWxGam2" +
       "cPYJEkxStb2qPnht8OlVM1qjXVkGjwPZaz5E2Yb4byGqBhjS2RvoxZL09P\n" +
       "/ua2u47jfwRQcBwFRVXOZZVxFMJKasRcV8E6Lil4HFXI8AOWpyUZU8uDsNYE" +
       "sp+t8xpCqAquBrjK\n6UVQaFiWRBwDHFKShjy9182XlYE67X4wyJBHO1U5hf" +
       "Wk+P23fvf50d33LwXs5DC3IKiJglqD3BAl\nTZCNGNsBlZUxoS1eG6nTUhTC" +
       "7z4ztPrLA8ZJwPoMCknZbI4IszKYEhZkWZ3HqSRhSVHvSkALxOFZ\nyB9Ixa" +
       "QMgjiUNTSnox5/njh4GmfVQsR3bplAhztGv0FDSkPQRKVz1cChB7lu4fVT+3" +
       "bdsdRTTonm\nK8Bx1JIeT+0qIjspLvyi+VOnTl/+WQBVzkCFMrbjtJCTSWLk" +
       "RjWnAOyb7EeTGCqCEhdmsRxHtRz4\nAoDXgl+VJjIeglrisK8JCJnSDzIucE" +
       "Ot7gihbB2QpL3/2wVJMdHYPPG9f7U9xfPa77WEroo4BfXK\nYUhu2NQ9cfS6" +
       "y2AXQBa0JaArrQAdfsh6UDZkQpKgnoIK4N9kyKpu1JIKMC6t6llBpmIsn9SQ" +
       "/bo6\n7zxhubuKrVdDjGrNRKfxqmDJ7cpweltL4+0zlhXOf44f2vnO2f59AX" +
       "eNrXP1nClMOGLrnXSZ1jGG\n53/5euLhw+8d2styxUwWAm0mNwsoyDPl1pRB" +
       "bjYWqR6xSNMjj67/5stWMjY60od1XViguZi/+1z0\nseeFb0FlAbQb0iJmqE" +
       "ZsJ2RtQO8DbB1zvQQAOvs72TtsGBA7KDTbWpb++ofo76f5/n5uUKjNYWKp\n" +
       "B/1R0lm+JcXTTfccvv9K3VgABSA0kBNpaOSSCN26vSBjR+y3NG1pj8pYxNEC" +
       "4nHnNS3+LX4dzP0b\nJ8JX/t32p+1s/9oUNkRd0qhVZhkMEnUXuJO2PraDLi" +
       "iGDMMCh880ezma1/Qhnkb01suisJZtaJE7\nJjssSfH6uy58+OM/n+zjCOr0" +
       "chRQd/8w+n7v07evs+Lc4TdpEgtQZLnNILz3rSc/uLf6CWZZpTrP\nkNbp8p" +
       "NdawFG5oqONjqTQg25AZSKFMTOFD90NCeo0csi1cZlurfC2VvEplXN3iUp7n" +
       "zzl6/f+7XI\nWbfhPgYX9cbmSKTrIq5hwLIDstYXEJuhRFBAs096PezWye3o" +
       "V+5ufe2aax96gWvnD2Qxju889fF3\nF/ueyDgQGDE3pT9jxYL1GZhJnWB98e" +
       "qlVz/8yaZ2V7BYBMDeeUbI40Hvw7Y564r57UaVEDXr8t51\nL2xoGT520wkr" +
       "UNtt/vVey3ycbvs2hh9/7m/HnzxqydjJ7Jpw2Zhg9y2aaf42dv+0xl9OaG4i" +
       "77+4\n+W9Es5zl+WeWJtqX/YPFDjrTWoU/O3vnR2eO1HQ5EWizW267p+V62J" +
       "Ji4Ngbh9ZH6s6D52fQVfsF\nY1yB8YlO3liHUMjutugfBn2iFp+75cilF8lr" +
       "LE+d/ka5u/OF+u8RXM1060tz9cEffTsbQFXQ81kn\nh2PJHkHO0fYwAyO5MW" +
       "I+jKNVnvfe8ZrPkk7PbPf3TNe2/m7pDGSwptR0HfI1yEa4uuGqpperQZYh\n" +
       "jS4kRriO3ft5JwsQGER0CUALugYNdvbJE1SWMDx1mRU8nOJD8x9rNy11XZ9u" +
       "YoAIsSjAqYqNaR0w\nG1MO6z9XMOxRsKOIgjxDbbJICTJPAtMbyTvZTjyJXP" +
       "Akbkv/BFzRUkqMeMhaS5GN+YjbV5I5Zg8o\ndYjeDeaVPhM+Tmdvc/pytNSB" +
       "iB3mDt36Qfg+4Vf7eBVs8A7go0ou+/eFM7hv25feLDLLh4iqDch4\nDssOfP" +
       "273cQOilYqLgcbUhXxrZFi+PUe9718SfHs+br3Rzeffef/Ny2bSVZsMO5c0Y" +
       "ikSJ5NXnx5\ny/l+lrZuONVwYdMeUHXZoaUTZx9cIXoVmzofKgIrur6a3pSV" +
       "B7gVXxJUm8HEsoC91my1qsz0bKYX\nQavs5kBPfjC3G1JmwNDFQdqJWfXxED" +
       "Dtp5mwRihSNIqUyGmhqMyl2ubiejuApf4ZKOKjAsAuuwC7\nXADY5eKA7Yfr" +
       "2iLSfRikZOtLkfkBe81KMhlgp8H/leykSye6SMF3JP7tQ+w5d0f/Ga3+twFW" +
       "pa3v\nE9VQCNM5WXZXbdc6qOk4LbEgVPMarrGfZwi6ynvWJqjG+cOUO8FJf0" +
       "pQuXnGP6lZgWy1Azmah8lE\nEWQ7oK5uHV1xqHts71c1ZcOwVPLM0OLFfI5/" +
       "ekuK72q3j706+fpxczazHYbzJMY+ylnAtDlu/cHe\nrvyD01/ho5UoC4uLdL" +
       "8qwDs/HNqf8bpLSrNkSW+8lH7gnrfrPENvPUepY3pHaTl0vWfV0Cu7T506\n" +
       "5i91yOU9l/mMx8Ln5v6Pqi69ePGG4n77L4xdrHQfFQAA");
    
    public Alice() { super(); }
    
    public void jif$invokeDefConstructor() { this.jif$principals$Alice$(); }
    
    private void jif$init() {  }
    
    final public static String jlc$CompilerVersion$jl = "2.0.0";
    final public static long jlc$SourceLastModified$jl = 1227640386000L;
    final public static String jlc$ClassType$jl =
      ("H4sIAAAAAAAAAKVZe8zj2FX3fDszu5Odtjuzu+223cfsdkpnsTqxkzhOOhUi" +
       "ifOw4/gRJ07ssnz1\n4zp+xW8ndloq+KfbUp6iRYCgPARCgv5BQWr/A6RWIF" +
       "4SqgQVf1BArQoS9A9AQJGAYiffN98338wW\noUa6zs2955577jm/c67PyWe+" +
       "AV2JI+hW4Lv5yvWTu0kegPgup0Qx0HuuEsezYuBYQ38Feetnv+9z\nNx6D3i" +
       "JDb7E8IVESS+v5XgKyRIaur8FaBVHc0XWgy9ANDwBdAJGluNauIPQ9GboZWy" +
       "tPSdIIxFMQ\n++6mJLwZpwGI9nueDtLQdc334iRKtcSP4gR6iraVjVJNE8ut" +
       "0lac3KOhq4YFXD0OoY9Al2joiuEq\nq4LwrfTpKap7jtVBOV6QV6xCzMhQNH" +
       "C65LJjeXoCvXRxxf0T3x4XBMXSx9cgMf37W132lGIAunkQ\nyVW8VVVIIstb" +
       "FaRX/LTYJYHe8YZMC6InAkVzlBU4TqDnLtJxh6mC6tpeLeWSBHr2ItmeUxZB" +
       "77hg\ns3PWYq9e/+8f5v7j1tFeZh1obin/lWLRixcWTYEBIuBp4LDwm+ndT5" +
       "JS+vwRBBXEz14gPtB03v35\nOf0Pv/fSgeadj6BhVRtoybH2X83nX/hS52vX" +
       "HivFeCLwY6uEwgMn31uVO5m5lwUFFt96n2M5efd0\n8venfyD94G+AfzyCrp" +
       "LQVc1307VHQteAp/dO+o8XfdryAAlddouv4uSG5YLy5JeLfqAk5r6fBRAE\n" +
       "PV60m0V7rGwJdK3jWhq4a1tGSfJUVj7ftL10qRDn+Yuu4RY4GvmuDqJj7de/" +
       "+scf7o8//rGj++A4\n2SKBnimY3Q0KbGhWoLjx3f0O0KVLe6Zve/CMpdL0Et" +
       "v/9Nv3nvqx98afO4Iek6Fr1nqdJorqFke5\nrriuvwX6cbIHxY1zANzbvQDN" +
       "dbXATwHFY7dgtMdrcdJNBL1yESdn3kUWPaUw/oeaDPSpF/s/V5q0\nNMEzJf" +
       "eDaIVCnYNs118VXqM++LFXHiuJtpcLxZUnuf1/cz/WuKefZX7t39/5mwfIXB" +
       "SIi3wN6EVg\nOFtwjNRfZn6p9p9H0JXCG4p4kCiFRQvnevGiNzwA4HsnaE+g" +
       "Vx5yroub3DsNHKWqjmjoScOP1opb\nsjn19kpiRv72bGQPiyf3/Td/6/D5n5" +
       "P2rSIo9Px1UAAuujUEhaxKAvTgAKTy8VKp1gsH38enfyVf\nH339T+68dnQ+" +
       "lL3lXMwTQHJwjBtnVplFABTjf/0z3E996huvf2BvkhObJNDVIFULsGV7QZ+5" +
       "VEDg\n6Uc46d3nnvnkT7/6818+tfnTZ9w7UaTkpcmzH/rSCz/7h8ovFA5cOF" +
       "Vs7cDeeaD9TtDpBuXzu/d9\n+NzkyWyJwIsuNCij96kd1uqH/u0Ln67cOshR" +
       "rnn7nsPl+OFo9cDCY233u/NPf/PPkq/sVXeGkpLH\nC9nD24rKOUi2/nJz4+" +
       "pv/eL6CHpchp7a3ziKl4iKm5aKlYs7I+6dDNLQmx6YfzD+H4LdGfKev4i8\n" +
       "c9texNxZxCj6JXXZf/w8zApFPF20l4v2RNn24ekQoy5BQdnB94Sv7J/vPmDg" +
       "KIEeLyLPpoBggYZ4\nf1VnCXSJu4/GN+3J6+XjVnapwMyV+l3kLlL+/p6H+R" +
       "UB8ophecr+FnlP+Xh/we5ttqvdPsW8WFz+\nRZC+XQS9/cobxb29B1Spo7uH" +
       "O/IRGxc2fvMZGe0XF+knvvYTf/rj7/qbwqYUdGVT6rsw5TleTFq+\naXz0M5" +
       "964clP/u0n9qgpUP/CX9z47J+XXAfl43uLW7iUTvDTSAO0EicTX7eKlwZ9L+" +
       "DDwOIia13c\nMpuTa/AnX/zVr//OV6fPHJ17V3jXwxHl3JrD+8LecpUgK3Z4" +
       "+dvtsKf+IvzyZz4y/Yp6CIo3H7wR\n+l66/vv8C+A97//Rv3vE5XLZ9R+pz+" +
       "R6Y9SIyc7pZ4xKxrKridNFtSYIqkqT7k4EOypxW8xsHjh9\nlBaaus1aE3Om" +
       "s4jQNineX87jKG9t1KRdwfVN3Uur+mymdrVFhx+uO/ORYI19XOxmIs3HiukG" +
       "MbZK\nhMDvZvWoN+IleEr0d6vVbt4fKbGGNfCovgF1w65wVTyrJ1gbx7Ldrm" +
       "1svBFnIDBsCg4zQnhGYB1p\nwQx3fd3xAnPcUVlK5DFJDADFz3dttC5z3nKR" +
       "t1ojhHAr2pQXtLVQDZ3EWSmE2OK5nkf0JBIjW0NK\nm0zM6SjMlwOSpHoUOV" +
       "qhHUzfTen5SNc7Yl9e5ALBOsiAQchlXCGZJJ4QfavXkLpqf1RDuZUGr8gw\n" +
       "h1M/h8mtC0hlshinSKyOmOYWa+nrWRssfHWlioLmz/vSyrHD1XgloOvKnLDo" +
       "GGckpiHPxnKu8MZ8\nnIVOEPXTHt1Der4STfyOTOTWqpcDT1pPhOE4bk+3K8" +
       "kOakMdXzhte8xuQ5JiKsBpOGHcQLuj+qwf\nyDM0qo6TXuYQJL1gKTmH6yqP" +
       "1brA5oVxc+F2s65MZ/MBJUxH8yYAWxXsdIKfdRbBclBpDNt4uA0G\nqw7wV8" +
       "sEDILZpNGdTSlhTgSUGBKeZIb0wpn3eiG6mmU+RXQFibSMyO8bW3FOAonMHY" +
       "qPMXhSKSb8\nxAgtjIy4nTbaGhlGGsxWlIjQi3vmrKqknVDjRgzpzRYTMLYI" +
       "zw7EXewYI1VLka5J9hq1uTFRJHVZ\n4ZYJXZ3QHLtzmUU2VNY1jZOovpMJiV" +
       "oLOc9MWqwrTtDQXorO0N5ysrLD+jVJbaj5MOyatlCbbvxM\nppE2V6mmSi1t" +
       "4LaxnfJadzuYiktWlsVsMKHGSjzVxFa/SVtuYzRYkq0OuwjyuTxvpUTMSP04" +
       "gJNW\nFvTCTph2I3tcac5FXhlYi2l3S4wGY8G08zbaqi1dqd/El41tTnVHLD" +
       "rHTGPhwFytbmwMDNHrdXq7\njDGiVyfHFrVyQ6Le7biVmdxjhkzcdeV55gso" +
       "GDa92dyc9fBdY5dwEd1pydSW8yc9x5NVskHGu7HU\nN2VnIddHoTA1BXG0EZ" +
       "wOnbEDuZJ322Sm8JOVbc2ZmeD5GVb1bLMxXBsiH0/rauB2zF0y3CADQnA4\n" +
       "fjoWd6jWM7u4mzYMcVZAR4/16Wzme+vKuNXNUIoEMxgJSTsO6E1uwSLrzdwq" +
       "vOC74s7pDSaRaidU\nbyYsaGdqL7wOm6t4H8yGvbDXN/V1PM1GyXTXqHR8Yr" +
       "lyYZGySbByIysetwon9ARiR6Zan03wlWWq\n3Rof0PVqbStSE30kcdywbeDz" +
       "dmZwCo4v+pHvN7rGclyR5mZaY/i2ZgjNvNZZ8l0FoZTiFYXv6EZs\nNueE7P" +
       "DBeOX55LjBtJ18HKTFScaTXjNpum43WJOx1xb4quo3K/guM1M1HUeiTtjDiJ" +
       "mOjSxcExSu\nBVvgJnQDRnauuWSNRsOobTy2ZmDtzhIw0ZJDvZ47YYd05C0F" +
       "GbWHwwpWr2Igpc0t3NJrcZJn8+2i\ns0bWzDb2c4Jz0WDaVW1pEU6bmcBMbL" +
       "uJV7E4WUxsqYn4OroUrVUqW1UY3SGVGICBigzcjsqriEWt\nw74cU7VpwrMt" +
       "Qu2iuw3Pd9hNjNdmSTzsdvAxMVMXgQrDvuHjTaMwPZbOxzYjLcZBpVtFp4i7" +
       "hilt\nOZsZmrbZtMd1cdXpCh3E6TKBwgpCj6k1N0LXnsJ5nRmigd0KpIzp9x" +
       "reyGOEOkwvG/qOQ9QK1aKW\n1aReC2A0rrb9OeNMdSQ0Rdl0Jn1vvkwptsZF" +
       "CkFb1pCYTHpmq4WA3VpBq7zpOSqCxqkVU3KiUH28\nQtlxLBijZppjLZidVD" +
       "14Z/fYCNHMKa9XW1vYwzcIDjYxTGuNmR70Vwkv0x5D0rt6JGjVlDaavYUs\n" +
       "B7OIqziMGrQCRle2gyHmhyxjhzN+VcM6sjAeTGbsgGgjTA/4iBZbqCa7aWT0" +
       "auKmH7hLpm7NA9zb\n7dxm1YDxJVlZqIbJraRlW1PXwngWkSFmbmmSiBNp2a" +
       "dSczrodmKk3eTAbpGDui/CWGqAmqJk7eZq\nsfGIGp/ZaavVNgb1yqCagpxY" +
       "8UOiXw9mbTuTaHQom5S36LZbIHTFXbWVK3JNxLtSd0IAMC/cHRlt\ntriENR" +
       "sRhs8VsU8so1aCoRW6lvnDGVZDtk40Z5KkuhFBXs81dRPXTLNdxdfVkbfLwl" +
       "y3KZwKtjXZ\nXLXzQjKjUdM3MJK5bVYZNiwchxsVeNHux9jOhRdgQSXhsipx" +
       "A8KOZgt/XmXrG29aAyw64rH+wtot\nak08gMVmjaKsBrNSzbY8asZNAqsZvG" +
       "jEg4qE5t2W5LJ11xrNJ3aapCuj69WsQQDjmGa5g5Yb0X1Y\nrzoKllbZAZy2" +
       "pssJijSRZNfW+oYxi1V+sORbqONVzBpHjZwRixjStpOz2GRBwvaYEb2NAVpy" +
       "xDkO\nzqmcUZ8xoFZd4wExFLZBMkVGBonmfaWRpsMwCEDEy5JZsYWGM40stm" +
       "4kGLWN+WF/ivTmHTpdSYy+\nUak+KiwmRIaup/OWx1JEK2tHTI6iS7mdSn6H" +
       "jAW7E0oho0yRbWWITtjmrr2csNk0HrPkys4IVaXI\n3oziOslEzWcbeWbn1J" +
       "LrOKqzqXYHu+ncCSdgYioCNmRgyVZFjMTkVcuv6JINCKCInDmBZ2t9o1WD\n" +
       "PGGErtWtr4mk3uSNFdwQDRx0xbjVwVc+4qdwFQwmuLmpYQagCZo2G1ZIaGaj" +
       "QsQxa3A1vK7xrOVK\nIb3S1Lm5zCJ5YMHcHLRxtFW4WwyrUX26A4YBjCqT11" +
       "RBlOMJi2mIZDkChTFLL8MqedWF3UhOWUbc\nSvoEzEdL2VfmMzlra+TSF9c7" +
       "3xivyCiNmko9EMQuvhKXGTVft0b92O+10XWOhvEOUcfSssIrmxhz\nupxh9+" +
       "pDlFpvGWLA6yG1MJZZnyCSAFtvp5YpMGQ4z4drM5zkbi1VLWCnncBoyGN2bH" +
       "fiTppue3hl\n2SEkDIw7uGRENYsWjKnlyGxCO4bTBS10PDHdVdAaVV2QO0IO" +
       "msJkUKc4POHhLaYjRnWo1OFkO1gE\nSn1T6bdFvsdMsMVSXqq61gxZp0Gr/Z" +
       "XITZQoGhry1mrm3mZBhfYQ1tg52xpQBhLw6dIbck1XXi1y\ntFPEN7Pl9iv9" +
       "BY/7YywdiWgWjpIYRzVU1tityNEThKUHBolVgZOO8VpYt3GkCRtBpu2U3UhS" +
       "d9RE\ngnPX6ySEm1a1EahEm5xA0KrpY3O/10hpnW6FWyKujpjQaKkBLUSMIy" +
       "zgljvCV15kRFyf2RRGDqR6\nMFJmLrJZGCLSS/EZhjQrmNVGc3bedqvrSdai" +
       "PWzT5EKr2QbccNjwcJxuZHo04o0B3+mU6cP0JHG6\nsU/r7tdBT0pixD7Z2O" +
       "c3t08S+7O0/+2n9YAIeuGNipL7lOf15T9f/6jyxdfKlKdcyCbQtcQP3uuC\n" +
       "DXDP6gUXmUz2NdjTJPqXr97UL9Ot5x5VMHjp26481pLPH//Ll5t/defoYvZd" +
       "iUCSRt7sgRz8+fs5\n+JMn5cL9Pudy8PsJ9fE5zbxBQeTbTibQs4Wmb5/VC2" +
       "/v64W3z3K8778vTCnIe4p2rWyPEsZ4REng\nXOr+nUj55Aokp+o8TfRvlpXO" +
       "fW7O3Rf/QYnLaut3lcWpQ4Hqo3tUEEBzZz5VJPb9LDnW7pYp/q07\n2mkRbX" +
       "VaRHv1fXW88b5bYarEVpj6CbhzqG/d2viWfqvUmuVtfKcIqsa54uOdV299KD" +
       "Gt+O4j1Xrn\n1Xs/8Oq56lz4HZvvuTcSZE87Dg7rmSJ1L8W+oJ+ytHPjTD/H" +
       "/0/9oPX6g/o51H7OK8hKSoXc+sBr\nwq0HDv7hh6GyP+K97wglT5xuWk7lxc" +
       "CVvdrLMuNzD/3TdPg/RHvlSx+884Xgxh8d7Ythp/9ZXKWh\nJ4zUdc8Xys71" +
       "rwYRMKz9ca4eymaHs30sgd78YP09gSpnP/Yiv34g/UQCPXYS5H4kOIX0O+5D" +
       "utA9\niDzFvQ/t7H8B8bB+kjMbAAA=");
}
