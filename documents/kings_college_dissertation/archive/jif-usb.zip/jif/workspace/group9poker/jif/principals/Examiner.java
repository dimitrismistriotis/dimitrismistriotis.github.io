package jif.principals;

public class Examiner extends jif.lang.ExternalPrincipal {
    
    public Examiner jif$principals$Examiner$() {
        this.jif$init();
        { super.jif$lang$ExternalPrincipal$("Examiner"); }
        return this;
    }
    
    private static Examiner P;
    
    public static jif.lang.Principal getInstance() {
        if (P == null) { P = new Examiner().jif$principals$Examiner$(); }
        return P;
    }
    
    final public static String jlc$CompilerVersion$jif = "3.0.0";
    final public static long jlc$SourceLastModified$jif = 1227640386000L;
    final public static String jlc$ClassType$jif =
      ("H4sIAAAAAAAAAK1YfWwcRxUfn+2zz77U8Vds2T5/xcF2W5+TJo0iHIm6juM4" +
       "ubon+xpah/Q63pu7\nbLK3u+zO2WcXoValjVsEBdEARRDiAiVNCyIFUilIJR" +
       "CghagggmgbVfSDlhKJVmpDSxMRJN7Mfu/d\nmX/4Y/fmdt97875+773Zp95F" +
       "lbqGIgfFdJQuqkSP7hbTcazpJBVXpMUEPEoK5x84uvLrbRefC6Dy\nGArhHD" +
       "2gaCJdpGht7CCex8M5KkrDMVGnIzG0VpR1imUqYkpSOzUlS1FPTAVRGUmhwy" +
       "RPh1Ws4eww\n32w4PiZhXQe2IH+qfxp9FpXlNdRtcZhKGRpxYkOlTY9tXHfy" +
       "U6fqy1HdLKoT5RmKqSiMKTKFLWZR\nOEuyc0TTR1MpkppF9TIhqRmiiVgSl4" +
       "BQkWdRgy5mZExzGtGnia5I84ywQc+pRON7Wg9jKCwoYJOW\nE6iiGRqCvmmR" +
       "SCnrX2VawhmdonWOpYZ9O9lzMK9GBMW0NBaIxVJxSJRTFHX5OWwb+/YAAbBW" +
       "ZQn4\n296qQsbwADUYnpewnBmeoZooZ4C0UsnBLhS1lRQKRNUqFg7hDElS1O" +
       "qnixuvgCrEHcFYKGr2k3FJ\nEKU2X5Rc8bk1GP7PQ/GPugNc5xQRJKZ/FTB1" +
       "+pimSZpoRBaIwXg5F31k8o5cRwAhIG72ERs0oxue\nuS128eddBk17EZpb5w" +
       "4SgSaFq1s7IudH3wqVMzWqVUUXWfA9lvPkjZtvRvIqoGGdLZG9jFovz0z/\n" +
       "5o57TpB/BFBwEgUFRcpl5UkUInJqzFxXwTomymQSVUjwA5anRYkwy4OwVjE9" +
       "wNd5FSFUBVczXOXs\noig8nsdZ4NGiAEVG1ZBn97qFsjLQqMOPBwlSaZcipY" +
       "iWFL7/5u8+M77nweWAnR/mLhS1MFyrkB6C\nqGJJj1qboLIyLrfFaylzXYoB" +
       "+Z2nR9Z+cUg/BYifRSExm81RPCeBQWEsScoCSSUpT416VxpaUA7P\nQRZBQi" +
       "YlEGQAWkXzGur1Z4uDqkleMwRy99YpdKRz/BsssCwQTUy6oRq49ZChW3hwZv" +
       "/uu5Z7yxnR\nQgW4j1nS66lgRWQnhcVfNH/89JkrPwugylmoU/oOksY5icbH" +
       "blZyMoC/yX40TaAuyDE8R6QYqjXg\njwHCFgirVIHzgINjsK8JC4nRD3MucE" +
       "Ot5ghhbJ2Qqn3/2wVJId7YPPW9f7U/aWS332txTRFICqqW\nw5DcuLln6tgN" +
       "V8AuAC5oSzGLMUWdfuB6sDZiApOi3oI64N9kxKpxzJIKMC6taFksMTGWT2ro" +
       "AU1Z\ncJ7w9F3D12shRrVmurN4VfD8diU5u61n8fYZy8vnPycP73r73MD+gL" +
       "vS1rk6zwyhBm7rnXRJaITA\n8798Pf6VI+8e3sdzxUwWCs0mNyeJQp4rt64M" +
       "crOxSA2JtjY98tXBb75kJWOjI31U0/Aiy8X8vecj\njz6HvwX1BTCvi0uEYx" +
       "vxnZC1AbsP8XXU9RIA6OzvZO+orkPsoNxsb1n+6x8iv08Y+/u5QaF2h4mn\n" +
       "HnRJUeP5lhTONN135MGrdRMBFIDQQE6koZ2LAvTsjoKMHbPfsrRlnSpjEUcK" +
       "iCed16wFtPh1MPdv\nnApf/Xf7n3bw/WtTRBc0UWVWmcUwSJXd4E7WAPkOGp" +
       "Z1CUYGAz4J/nI8r2ojRhqxWx+Pwnq+oUXu\nmOywJIUb77n4wY//fKrfQFCX" +
       "l6OAuueHkff6nrpzgxXnTr9J0wRDnTVsBuF9bz7x/v3Vj3PLKpUF\njrQul5" +
       "/scgswMldswNG4FGbITaBUa0HsTPEjx3JYiVwRmDYu070Vzt4imlBUe5eksO" +
       "uNX752/9da\nz7kN9zG4qDc1t7Z2XyI1HFh2QNb7AmIzlAgKaPYxr4fdOrkd" +
       "/fK9ba9ed/3Dzxva+QNZjOM7T370\n3aX+xzMOBMbMTdnPRLFgfRImUydYn7" +
       "t2+ZUPfrK5wxUsHgGwd4ETGvFg91HbnA3F/HazQqmSdXnv\nhuc3towev+Wk" +
       "FagdNv+g1zIfp9u+TeHHnv3biSeOWTJ2cbumXDbG+X2rapq/nd8/oRovp1Q3" +
       "kfdf\nzPw3plrO8vwzSxPry/7ZYiebbK3Cn527+8OzR2u6nQi02y23w9NyPW" +
       "xJIXD89cODrXUXwPOz6JoD\nWJ+UYYhi8zfRIBSSuy36R0KfqKVnbzt6+QX6" +
       "Ks9Tp78x7p58of57sauZbntxvj74o29nA6gKej7v\n5HA42YulHGsPszCY62" +
       "Pmwxha43nvHbKNidLpmR3+nuna1t8tnZkM1oyarUO+BtkIVx9c1exyNcgy\n" +
       "pLKFyAk38PuA0ckCFAYRTQTQgq5BnZ+A8hSVxXVPXeYFj6SM0fmPtZuXu29M" +
       "N3FAhHgU4GzFx7RO\nmJAZh/XfUDDsUbCniIJGhtpk7SXIPAnMbjTvZDv1JH" +
       "LBk5gtvQOu7lJKjHnIIqXIJnzEXavJnLAH\nlDrE7jr3Sr8JH6eztzt9OVLq" +
       "WMSPdIdvfz/8AP7VfqMKNngH8HE5l/374lnSv/0LbxQZ50NUUYck\nMk8kB7" +
       "7+3W7hx0UrFVeCDamK2LbWYvj1Hvq9fEnh3IW698a3nHv7/zctm0lWbDDuWt" +
       "WIpECfSV56\naeuFAZ62bjjVGMISHlB126FtgKsfrhC7ik2dDxeBFVtfy27y" +
       "6gPcqi8pqs0QalnAX6u2Wuzs12YO\nxM0UrbGbAzv8wdyui5khXROGWSfm1c" +
       "dDwLVPcGGNUKRYFBmR00JRmUu1LcX1dgDL/DNUxEcFgF1x\nAXalALArxQE7" +
       "ANf1RaT7MMjIBkuR+QF73WoyOWAT4P9q67DLhrrWgg9KxkcQoff8XQNn1frf" +
       "Bnih\ntj5UVEMtTOckyV24XeugqpG0yONQbZRxlf88TdE13hM3RTXOH67fSY" +
       "P0pxSVmyf9U6oVyzY7luN5\nGE5kLNkxdTXsyKpz3aP7vqzKG0fFkseGFi/s" +
       "c8Y3uKTwjnrnxCvTr50wxzPbYSRPo/zrnIVNm+P2\nH+zrzn8+8SVjuhIkvL" +
       "TE9qsCyBvnQ/t7Xk9JaZYs8fUX0w/d91adZ+6tN4DqmN5ZWg5b710z8vKe\n" +
       "06eP+6sdcnnPZT7nsSC6ZeDDqssvXLqpuN/+C52EkgwoFQAA");
    
    public Examiner() { super(); }
    
    public void jif$invokeDefConstructor() { this.jif$principals$Examiner$(); }
    
    private void jif$init() {  }
    
    final public static String jlc$CompilerVersion$jl = "2.0.0";
    final public static long jlc$SourceLastModified$jl = 1227640386000L;
    final public static String jlc$ClassType$jl =
      ("H4sIAAAAAAAAAK1Zaawk11WueZ4Z2+2J4xnbieN4mTgTMqaV111dXUtnIkT1" +
       "Ut3Va3VtXV3BvNTe\n1bV27VUOEfyJs7AKGwGCsAiEBPlBQEr+AVIiEJuEIk" +
       "HEDwIoUUCC/AAEBAkIVf3em/fmzdgIhZZu\n9e2655577jnfPeee05/9JnAl" +
       "DICbvmfnhu1Fh1Hua+EhJQWhpvZsKQzZ8sWRAv5y8x2f+77PX38I\neLsIvN" +
       "10mUiKTKXnuZGWRSJwzdEcWQtCXFU1VQSuu5qmMlpgSrZZlISeKwI3QtNwpS" +
       "gOtJDWQs9O\nKsIbYexrwX7N05dT4JriuWEUxErkBWEEPDHdSonUiCPTbkzN" +
       "MLozBa7qpmar4Q74GHBpClzRbcko\nCd8xPd1FY8+xQVTvS/KaWYoZ6JKinU" +
       "65bJmuGgEvXpxxd8e3JiVBOfVhR4s23t2lLrtS+QK4cSyS\nLblGg4kC0zVK" +
       "0iteXK4SAc++KdOS6BFfUizJ0I4i4JmLdNTxUEn16F4t1ZQIePoi2Z5TFgDP" +
       "XrDZ\nOWstrl77r09R/37zYC+zqil2Jf+VctILFybRmq4FmqtoxxO/FR++Tq" +
       "7j5w4AoCR++gLxMQ3+vi9w\n07//3RePad79AJqFvNWU6Ej5T+S557+Mf/3R" +
       "hyoxHvG90KygcM/O91alTkbuZH6JxXfc5VgNHp4O\n/h79++sf/HXtHw6Aqy" +
       "RwVfHs2HFJ4FHNVXsn/YfL/tR0NRK4bJdf5c5109aqnV8u+74Ubfb9zAcA\n" +
       "4OGyPV22h6oWAdcGmeSUc4LDralXVE9k1fNt6aVLpUTPXTwddgmlkWerWnCk" +
       "/NrX/uijg8knP3Fw\nFx8nq0TAO0tmh34JD8X0JTs8PF0EuHRpz/ed9+60Up" +
       "1aIfwff+vOEz/6gfDzB8BDIvCo6ThxJMl2\nuaFrkm17qaYeRXtoXD8Hw731" +
       "S+hck0sUlYA8sktGe9SW+00C4KWLaDk7Y2TZk0oIvIrMgTdeGPxs\nZdjKEE" +
       "9V3I9FK9VqHct27WXmlfFHPvHSQxVRerlUX7WTW/879yOFevLp+a/+27t/4x" +
       "g4FwWiAk/R\n1NI9nE04akLvmf9i6z8OgCvlmSi9QiRV6ouAFy6eiXtgfOcE" +
       "8xHw0n1H7OIid07dR6WqgynwmO4F\njmRXbE7PfC3aBF569maPjMf2/ce/ff" +
       "z575P27dI19DzHL2EX3BxqpaxSpKn+MZaqx4uVWi9sfO+l\n/oV8bfSNP779" +
       "ysF5h/b2c56P0aLj43H9zCpsoGnl+7/6aeon3/jmax/em+TEJhFw1Y9l21Sy" +
       "vaBP\nXSoh8OQDjurhM0+9/lMv/9xXTm3+5Bl3PAikvDJ59kNffv5n/kD6+f" +
       "IYl0crNAttf4SA/UrA6QLV\n87v3/fq5wZPRCoEXTxFR+fBTOzjyq//6xc/U" +
       "bh7LUc15157D5fB+n3XPxCOl+B3uM9/60+ire9Wd\noaTi8Xx2/7K8dA6S2F" +
       "8k16/+5i84B8DDIvDEPu5IbsRLdlwpViwjR9g7eTkF3nbP+L1R4NjlnSHv\n" +
       "uYvIO7fsRcydOY2yX1FX/YfPw6xUxJNlu1W2R6q291DHbuoS4FcddE/40v75" +
       "vmMMHETAw6XzSUoI\nlmgI9wE7i4BL1F00vm1PDlWPm9mlEjNXoMPmYbP6/T" +
       "338yvd5BXddKV9LHl/9fhQVvk4W7l1inm+\nvAKUrvpW6ff2M6+X0XsPqEpH" +
       "h8eR8gELlzZ+/Ixs6pXh9NNf//E/+bH3/nVp0zFwJan0XZryHK95\nXN03Pv" +
       "7ZN55/7PW/+fQeNSXqn//z65/7s4orUT2+t4zFlXSMFweKNpXCaOapZnl1UP" +
       "cC3g8sKjCd\nMtYkJ8HwJ174lW/89tfopw7O3Rjee79HOTfn+Nawt1zNz8oV" +
       "3vNWK+ypv1R/z2c/Rn9VPnaKN+6N\nCAM3dv4u/6L2/g/9yN8+IL5ctr0H6j" +
       "O6ho3aIYmffibgWl+lCp1xultvFQWKchivhi0WbmQK0VrB\ndXbsNc0R6SDb" +
       "eNaOZc+tZ760aSwRyI/RmjydQHG9WLRWiuCV4N/y4aCrDnCa7pu4yc97OUlw" +
       "pk2O\n6Z6xkQzDcAyZ15m+vZmMecfvM9mMHs/RmR431JojNNrrhu6oUQfFUL" +
       "iOopDod2DClndD0tAJdbyM\ndxZDoRuZVaTCH3d5wZ9xA2rgTeAMa8fJNJBL" +
       "f99D+nltiAebUb9lSL2x6g83EdrraRk2gydW0J/x\nQ5cshk3ep0HT4XZry2" +
       "cWBWczIEGxOE8POWeT5jS1AVdhW0vTGtRK25QpboSl1iJH9Z2e+R3CF+y5\n" +
       "SkeKuJkMaT9bWwubXXciYaTnHKLvcnCkTiceC9POZMeYswk7IaYrka4tBnGu" +
       "NFmWBme+5ftEhyU3\nO9oxTd5g7HZ3aa1U2shhRxxkxTAauqYEk1g7T5dK3a" +
       "cXc3RldLaTXuqtx4tVbYCY5pDe9RLHoZme\nGwgtXko3juq5q4W/FjuLjl3M" +
       "Jp1hd7ZqzrsSmfHjjBnTLDES4MUqleuNNY7L3ZW4dNu1VgfZLUM5\nxfvc2v" +
       "W11O06mid6ntjuNbnQ7U43DGjTywk953aEgW76g1Jli51rZnFi9ILBSCHWk2" +
       "HQsiBiXBtM\nuJYA0womW+CQQqllY0jFxlyBsyU9nogNgu2Cdd90GNH36FKy" +
       "VDBgAgItzIMVOsU35BBtDeiw6WWx\nVosZsIVpqtq1QHQg+jKcthmDkYgdGK" +
       "JkrI6gdMfPitWO5zhhpeMdO6GsrRgldELuvOFQnYrDzpbw\nkqJZNGqwB6Os" +
       "3210iW46MDiCVnwb5iyOdMe7gsiElPWc3FkyPLdNcVhy6bWV5u1Fym8HnXSu" +
       "wgRD\ncF1eKYSFENY808DcUBXb86GJD/ghKHbdDrojwu10uZstqG5qM5JYXv" +
       "PW5oqYog04xuozFHVTbYW7\ndMOpdDoj8sDqIr3abjgeb8Gd7E3JfBrohJTb" +
       "hbD2unWx5dIdsa5wRqO7NnWaGWQOBtJUT+suV4OQ\nUbwew3A+2wYRvjyfHI" +
       "5StSUtdpfm2h4Ml/jKEophHIBiO+7vLFubpXTe6ax9dUIXjW4Yhr10yXI5\n" +
       "4tG7dkfsbVbQJhWTRhzDIppnLl1bGqv2FnQZBLENerV0Nwqvz0cNrDO2AiqN" +
       "jdx2PK7hLaxwDZuK\nPJJtMZ95vUYutJushMd5f4DRyHK92wpGbZuOeoRhBj" +
       "w5Kgxyvg0n2LjXduk+NIuVwSKCjc1GHreW\nOxdqtFJ+TKromqJWHR3lGtKK" +
       "gaBWlLE0QfZ2u1UthftKPLVdJDLmPIbHeA/2mGI4nXErVY+7SNgX\nTdxfmJ" +
       "BHIu15x8omflaMycmsh0QSYYUzdrhiW4GHc6BYU8Zo2iGgPtgKN3TAO3Ewb/" +
       "N6H1NNDo4R\n0MX0tZhjiUvlCoVCAQrN+nVjmjBgYCFFmm+6Dhq4Aj2WSBav" +
       "YWgHo3SEJ+uYBoVqkXHpqhc2nXmu\njZd+O4iQ9kwJFhmDt8bRdt3BIqEro7" +
       "A1Xi22JARyzQZu5piAJZqyrW0LZJSkAthle4nZjAfrLMlc\nsQfickhhgsB1" +
       "aBJHFkUiLupeYFGhN89CGXTrSIaZSRNb1xsxvJSI1qbtuLWRS485jYLtDbuY" +
       "z0EI\nng0DlZ51CbK/XA4QyxNbUzxhw603mY1kqoyItO0y/nbAKROzp6kgkh" +
       "JR6R5nlJrUXNzXG4KOupCc\nNlYRS3eVJrfiV47CpcxYUNsDdIVT1mLoi2CP" +
       "Ww/xoj1uuCQWtLwtvdllq6xOpe6u7nFCXHMWeTom\nObk8Ie103Wjok0BfEj" +
       "3BRhZ4HGsjS9cRN/ALIxNcNuiMmyndd1k+7MZERy7QrJFA/BaiphOfI2rb\n" +
       "YBnbcCNUjDCd2WqYzodtYiiTrNTlpOYoZKnBNoPGa5NPaae/jptoky+itunY" +
       "XU6DNStcxHMBhVuN\njirVCtSad4phe9dXwAgVW0JOgiNi01rOZRR3yMLGjY" +
       "lErbOgrauLwFJL0Tuy1NHUBtQvskSqL+fi\ndjFDWQht1iBJqGfFbNGdyTNW" +
       "dSl6Shg6TTpcrq5dNGrVRY7SgwmcZlw4MoZpqUR2mBBGBxzJLg4R\njZFULH" +
       "cOowpuUtvEChSVyV9SX1mEZKjzpG6ABan7nbjOaqORm0CyyWiLFTtuKXLsCH" +
       "15WBdageTv\nGq6KNTzaS3xwCVm6qtcKKoV8O1hgSVowGRXkDVRcm5osT6Ce" +
       "C7fQOrYo6FaMuEuz2cpbUNqZ59Qq\nG5NCH+soi34gcEJKLQpk7PVrq3GdW6" +
       "83JlaUm+syTJxDCN2c6LsJ78pFhNSXAjIJO6yPYhnqw5in\nw2goxaLsRlmy" +
       "Rdteq+PiiDHRtmhSg0d4u7WO7dEwpMKit0ZalJNmG6kNuclInsxNdeo7NFR3" +
       "Y1cC\nIyxyRWsGerkUcIt6N7JIPusooJblc8XIa/50QuS4BWFUjDcVq0fga5" +
       "pdsktjB3ddsY5jG4bPBJ4S\ntDWxRZhZU3eoSIyFuNWZzSEC34wMrj0sowVK" +
       "L2rOGBc35RHg+v2Qk3uuSY7LG4dvoYxAUrg7k7ds\nIvYTcDyadi3YiJLlIk" +
       "bt8WQ7cklyJ5BjtxgIUjJ2p/ioZveDAboNICbAxiNEK6Ii6iz46W41YyiV\n" +
       "VBO9aGA4hfL6bjaZu8YIGw1guwGh7fKEJo3mVM6WItycc9xasWozC7O6KFqH" +
       "Vugma3IBwWu9vuRM\nWlN5tU624CjZdfSBu4HIFdLBJMgdJWijUCKnaa/kfj" +
       "9eRSvSH/R0hoeRmqTFBC4iLXm75YczkhnZ\nXbCFEJExCfVg00NNq6X2M61L" +
       "8JGet9AcMShlZ2L+LmwuJdvFBSRureIiBFvrRS2bleLIQxkvEixV\n89iErY" +
       "1AL4YrRndARe2nU55ShsM5N6HXRNehm80x7XAxOFUEUDX600Z/zmUDhTAIMK" +
       "vhgmTjUzzI\nlgMUn+sgLbHobLYlu1ZM15cECq28fLHC2TbV2SFof7oJgpVh" +
       "dCaZpSw9XceE5dwF9UDvuuamFm1h\njh/MInahWDnfagtabOz8YTNfzJeySG" +
       "e2jmGsOgChzQyiWWExQlCdWVNNP2N4J9c7HOLxebFG7XgO\n14YD2JrOrUxl" +
       "hTCf+AUkUWiyKybDpl7GHm1ImKV7wtZQPGHTrRu4WS9hA7iZZgUlrxma8hpF" +
       "4JL8\n3KlTrdqoXgSFi9Uxht/GG9JKpuygswt7eTdxl40IFazOWBLXIaZzQj" +
       "NtqB1QUsU6Es3b/Z0zh8WV\nAcso2CywZKLVmohG1ZFQVVyXElnUDZkeImr9" +
       "/i4ME2G68+N5o96DWwPLSD1iieNVCkGfJE/X96nd\n3YroSWWsv0849jnOrZ" +
       "Pk/iz1f9dpTSAAnn+z8uQ+7XlN+KdrH5e+9EqV9lQTFxHwaOT5H7C1RLPP\n" +
       "agYXmcz21djTRPqXrt5QL0+xZx5UNHjxLWceKdEXjv75K8hf3j64mIHXAi2K" +
       "A5e9Jw9/7m4e/thJ\n4XC/zrk8/G5SfXROM29SFHnLwQh4ptT0rbOy4a3Tsu" +
       "Gts1Tv++/Kc6Ns7y/bo1V7kDz6AyoD5zL4\n70TQxwwtOtXoab5/o6p57lN0" +
       "6u4O7pW4Kr1+V1WjOq5TfXIPjL6m2Kw3LvP7QRYdKYdVpn/ztnJa\nSzNOa2" +
       "kvf7D0gR+8uYul0NzFXqTdPi5z3Uw8U71ZKc50E8/S+mWCeFaDvP3yzVejjR" +
       "kevplmb798\n5wdePlen2/3/GPFBsuxpy9vp/nteJvGV5BdUVBV5rp+p6Oj/" +
       "qCIQgu5V0XEV6LyOzKjSyc0Pv8Lc\nvGfjH70fLfst3vmOgPLI6aLVUF69ON" +
       "V8VXN85r4/n47/IlFe+vJHbn/Rv/6HB/vK2OnfGFenwCN6\nbNvnq2bn+lf9" +
       "QNPN/Y6uHtfQjrf3iQh4/N56fATUzn7spX7tmPTTEfDQibf7Yf8U2M/eBXap" +
       "fi1w\nJfsuwLP/AYVi/pRGGwAA");
}
