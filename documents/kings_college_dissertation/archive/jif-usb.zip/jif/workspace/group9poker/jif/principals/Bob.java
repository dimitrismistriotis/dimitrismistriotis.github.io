package jif.principals;

public class Bob extends jif.lang.ExternalPrincipal {
    
    public Bob jif$principals$Bob$() {
        this.jif$init();
        { super.jif$lang$ExternalPrincipal$("Bob"); }
        return this;
    }
    
    private static Bob P;
    
    public static jif.lang.Principal getInstance() {
        if (P == null) { P = new Bob().jif$principals$Bob$(); }
        return P;
    }
    
    final public static String jlc$CompilerVersion$jif = "3.0.0";
    final public static long jlc$SourceLastModified$jif = 1227640386000L;
    final public static String jlc$ClassType$jif =
      ("H4sIAAAAAAAAAK1Ya2wcVxW+Xtu7fmzq+L3y246D7bZeJ00aRTgSdRzHcbJ1" +
       "V7YbWod0ez17dzPJ\n7Mwwc9deuwi1Km3cIiiIpqUIQlygpGlBpEAqBakEAr" +
       "QQFUQQbaOKPmgpkWilNrQ0EUHi3Dvv2V3z\nhx8ze3fmnHPP6zvn3Hn6PVSu" +
       "a6j9oJiK0kWV6NHdYiqONZ0k44q0OAOPEsL5+4+u/HrrxecDqDSG\nKnGWHl" +
       "A0kS5StDZ2EM/joSwVpaGYqNPhGForyjrFMhUxJcmdmpKhqDumgqi0pNAhkq" +
       "NDKtZwZohv\nNhQflbCuA1uQP9U/iz6PSnIa6rI4TKUMjTixodLGxzc0nfzM" +
       "qdpSVDOLakR5mmIqCqOKTGGLWRTO\nkMwc0fSRZJIkZ1GtTEhymmgilsQlIF" +
       "TkWVSni2kZ06xG9CmiK9I8I6zTsyrR+J7WwxgKCwrYpGUF\nqmiGhqBvSiRS" +
       "0vpXnpJwWqeoybHUsG8new7mVYmgmJbCArFYyg6JcpKiTj+HbWPvHiAA1lCG" +
       "gL/t\nrcpkDA9QneF5CcvpoWmqiXIaSMuVLOxCUUtRoUBUoWLhEE6TBEURP1" +
       "3ceAVUldwRjIWiRj8ZlwRR\navFFyRWfW4Lh/zwY/7grwHVOEkFi+oeAqcPH" +
       "NEVSRCOyQAzGy9nowxO3Z9sCCAFxo4/YoBlZ/+yt\nsYs/7zRoWgvQ3DJ3kA" +
       "g0IVzd0tZ+fuTtylKmRoWq6CILvsdynrxx881wTgU0NNkS2cuo9fLM1G9u\n" +
       "v/sE+UcABSdQUFCkbEaeQJVETo6a6xCsY6JMJlCZBD9geUqUCLM8CGsV0wN8" +
       "nVMRQiG41sJVyi6K\nQtuVuSigkBHU5di9ZqGkBJRp80NBgizapUhJoiWE77" +
       "/1u8+N7XlgOWCnhrkBZAiDtAqZIYgqlvQo\nyEclJVxks9c+5rAkg++7zwyv" +
       "/fKgfgpwPosqxUwmS/GcBGaEsSQpCySZoDwhal3JZwE4PAe5A2mY\nkECQAW" +
       "MVzWuox58jDpYmeKUQyF1bJtGRjrFvsHAy9zcw6YZq4MxDhm7hgen9u+9c7i" +
       "llRAtl4DRm\nSY+nbhWQnRAWf9H4ydNnrvwsgMpnoTrpO0gKZyUaH92uZGWA" +
       "fIP9aIpANZBjeI5IMVRtgB4DcC3o\nhVSB81DUHIN9TTBIjH6Ic4EbqjVHCG" +
       "PrgATt/d8uSAjx+sbJ7/2r9Skjp/1ei2uKQJJQqxyGxIZN\n3ZPHbrgCdgFc" +
       "QVsKujL0d/jh6kHYsAlHinry0O/fZNiqbMySMjAupWgZLDExlk+q6AFNWXCe" +
       "8Mxd\nw9csuavNJGfxKuOp7cpvdlvH4u0zlhfNf04c3vXOuf79AXd9rXH1m2" +
       "lCDbTWOukyoxECz//y9fjX\njrx3eB/PFTNZKLSY7JwkCjmuXFMJ5GZ9gcoR" +
       "jTQ8/MjAN1+2krHekT6iaXiR5WLunvPtjz2PvwVV\nBZCui0uEIxrxnZC1Ab" +
       "sP8nXU9RIA6OzvZO+IrkPsoMhsa17+6x/afz9j7O/nBoVaHSaeetAbRY3n\n" +
       "W0I403DvkQeu1owHUABCAzmRgiYuCtCp2/IydtR+y9KW9ae0RdyeRzzhvGaF" +
       "v9mvg7l//WT46r9b\n/7SD71+dJLqgiSqzyiyBQarsBneytsd30LCsSzAoGP" +
       "CZ4S/Hcqo2bKQRu/XyKKzjG1rkjskOS0K4\n8e6LH/74z6f6DAR1ejnyqLt/" +
       "2P5+79N3rLfi3OE3aYpgKLGGzSC8960nP7iv4gluWbmywJHW6fKT\nXWkBRu" +
       "aKjTUal8IMuQmUiuTFzhQ/fCyLlfYrAtPGZbq3wtlbRGcU1d4lIex685ev3/" +
       "do5JzbcB+D\ni3pjYyTSdYlUcWDZAVnnC4jNUCQooNknvB526+R29Cv3tLx2" +
       "3fUPvWBo5w9kIY7vPPXxd5f6nkg7\nEBg1N2U/44WC9WmYR51gfeHa5Vc//M" +
       "mmNleweATA3gVOaMSD3Udsc9YX8tt2hVIl4/LeDS9saB45\nfvNJK1A7bP4B" +
       "r2U+Trd9G8OPP/e3E08es2Ts4nZNumyM8/sW1TR/G79/SjVeTqpuIu+/mPlv" +
       "VLWc\n5flnlibWl/1jxU42z1qFPzN310dnj1Z1ORFotVtum6fletgSQuD4G4" +
       "cHIjUXwPOz6JoDWJ+QYXRi\nUzfRIBSSuy36B0GfqKXnbj16+UX6Gs9Tp78x" +
       "7u5cvv57sauZbn1pvjb4o29nAigEPZ93cjiS7MVS\nlrWHWRjH9VHzYQyt8b" +
       "z3jtbGHOn0zDZ/z3Rt6++WzjgGa0bN1pW+BlkPVydcFexyNcgSpLKFyAnX\n" +
       "83u/0ckCMCtCggJoQdegzs89OYpK4rqnLvOCR5LGwPzH6k3LXTemGjggKnkU" +
       "4ETFx7QOmIsZh/Xf\nUDDsUbCtgIJGhtpkTUXIPAnMbjTnZDv1JHLek5gtvR" +
       "mu1mJKjHrIIsXIxn3ELavJHLcHlBrE7jr3\nSp8JH6eztzp9ub3YYYgf5A7f" +
       "9kH4fvyr/UYVrPMO4GNyNvP3xbOkb9uX3iwwyVdSRR2UyDyRHPj6\nd7uZHx" +
       "KtVFwJ1iXLYlsjhfDrPep7+RLCuQs1749tPvfO/29aNpOs0GDcuaoRCYE+m7" +
       "j08pYL/Txt\n3XCqMoTNeEDVZYe2Dq4+uCrZVWjqfKgArNj6WnaTVx/gVn1J" +
       "UXWaUMsC/lq11QqZWdfILorW2M2B\nnftgbtfF9KCuCUOsE/Pq4yHg2s9wYf" +
       "Xm6Y4ROS0UlbhU21xYbwewzD+DBXyUB9gVF2BX8gC7Uhiw\n/XBdX0C6D4OM" +
       "bKAYmR+w160mkwN2BvxfCudcNs9F8r4gGV89hJ7zd/afVWt/G+A12voyUQFl" +
       "MJWV\nJHfNdq2DqkZSIg9BhVHBVf7zDEXXeM/ZFFU5f7hqJw3Sn4Ju5vn+lG" +
       "qFscUO41gO5hIZS3Y4Xb26\nfdWR7rF9X1XlDSNi0RNDsxfxWeOjW0J4V71j" +
       "/NWp10+Yk5ntMJKjUf45zoKlzXHbD/Z15b448xVj\nsBIkvLTE9gsB2o2jof" +
       "0Br7uoNEuW+MZLqQfvfbvGM/LWGhh1TO8oLoet964ZfmXP6dPH/YUOubzn\n" +
       "Mp/zWOjc3P9R6PKLl24q7Lf/At6vjNAZFQAA");
    
    public Bob() { super(); }
    
    public void jif$invokeDefConstructor() { this.jif$principals$Bob$(); }
    
    private void jif$init() {  }
    
    final public static String jlc$CompilerVersion$jl = "2.0.0";
    final public static long jlc$SourceLastModified$jl = 1227640386000L;
    final public static String jlc$ClassType$jl =
      ("H4sIAAAAAAAAAKVZe6zj2FnP3J2Z3c1O253dbbtt9zHdTuksoddx4thxp0I4" +
       "TuI4cRLHju3EZbn1\nO3b8fsV2SwVS1V0oT9EiQFAeAiFB/6Agtf8BUisQLw" +
       "lVgoo/KKBWBQn6ByCgSECxk3vn3rkzW4Qa\n6Tgn53znO9/jd77j78unv167" +
       "FoW1W75n54btxcdx7mvRMS2FkabithRFy3LgRAF/pfmWz3zvZ28+\nUnuTWH" +
       "uT6bKxFJsK7rmxlsVi7YajObIWRpiqaqpYu+lqmspqoSnZZlESeq5YeyoyDV" +
       "eKk1CLGC3y\n7LQifCpKfC3c73k2SNVuKJ4bxWGixF4YxbUnKUtKJSCJTRug" +
       "zCi+S9Wu66Zmq1FQ+0jtClW7ptuS\nURK+hTrTAthzBIbVeEleN0sxQ11StL" +
       "MlV7emq8a1Fy+vuKfx7UlJUC591NHijXdvq6uuVA7UnjqI\nZEuuAbBxaLpG" +
       "SXrNS8pd4trbX5dpSfSYLylbydBO4tqzl+now1RJ9fjeLNWSuPbmy2R7TllY" +
       "e/sl\nn13w1vz6jf/+Yfo/bh3tZVY1xa7kv1YueuHSIkbTtVBzFe2w8BvJ8S" +
       "fIdfLcUa1WEr/5EvGBBnv3\n5zjqH37vxQPNOx5CM5ctTYlPlP+Cn3v+i9hX" +
       "H3+kEuMx34vMCgr3ab73Kn06czfzSyy+5R7HavL4\nbPL3mT9Y/8BvaP94VL" +
       "tO1q4rnp04Lll7XHNV/LT/aNmnTFcja1ft8qvUXDdtrdL8atn3pXiz72d+\n" +
       "rVZ7tGxPlu2RqsW1R3uefGyZekXwZFY937C7cqUU5rnLB8MuUTTybFULT5Rf" +
       "/8off3gw+aHXju5B\n43SDEiEls2O/RIZi+pIdHZf8a1eu7Fm+9X79KoOpFa" +
       "7/6bfvPvlj740+e1R7RKw9bjpOEkuyXapx\nQ7Jtb6epJ/EeEDcvgG/v8xIw" +
       "N+QSOyUMT+yS0R6rpZZpWHvpMkbOTxZZ9qTS8R+CZ7VPvjD4ucqd\nlfmfqb" +
       "gfRCuNuT3IduNl9pXxB1976ZGKaHe1NFqlye3/m/uJQj/95tmv/fs7fvMAl8" +
       "sC0aGnaGoZ\nFM4XnDTb75z9Uus/j2rXypNQxoJYKr1ZHqwXLp+E+8B79xTp" +
       "ce2lBw7W5U3ungWNylRHVO0J3Qsd\nya7YnJ30erwJvd35yB4UT+z7b/zm4f" +
       "M/p+2bpbtxz/FLsIW3CK2UVYo11T/AqHq8WJn1kuL72PSv\n5Kujr/3JnVeO" +
       "LoaxN12Id6wWHw7FzXOvLENNK8f/+mfon/rk11/9wN4lpz6Ja9f9RLZNJdsL" +
       "+syV\nEgJPP+SAHj/7zCd++uWf/9KZz58+546FoZRXLs9+8IvP/+wfSr9QHt" +
       "7yQEVmoe0PTm2/U+1sg+r5\nnft+48Lk6WyFwMsHaFhF7jM/OPKH/u3zn6rf" +
       "OshRrXnbnsPV6MFIdd/CE6X4Xe5T3/iz+Mt7052j\npOLxfPbgtrx0AZLdv0" +
       "xvXv+tX3SOao+KtSf3t43kxrxkJ5VhxfK+iPDTQar2hvvm74/9h0B3jrzn\n" +
       "LiPvwraXMXceL8p+RV31H70Is9IQT5ftxbI9VrV9cDpEqCs1v+oge8KX9s93" +
       "HzBwVAazMu6kJQRL\nNET7azqLa1foe2h8w568XT1uZVdKzFxrHzePm9Xv73" +
       "6QXxkcr+mmK+1vkPdUj/eX7N5q2crtM8zz\n5cVfBujbZcjbr7xZ3tl7QFU2" +
       "Oj7cjw/ZuPTxG8/JKK+8RD/+1Z/40x9/19+UPh3XrqWVvUtXXuA1\nS6q3jI" +
       "99+pPPP/GJv/34HjUl6p//i5uf+fOK67B6fE95A1fSsV4SKholRfHUU83yhU" +
       "HdC/ggsOjQ\ndMobJj29An/yhV/92u98hXnm6MJ7wrsejCgX1hzeFfaeq/tZ" +
       "ucM7v9UOe+ovNN756Y8wX5YPQfGp\n+2+EgZs4f59/XnvP+3/07x5ytVy1vY" +
       "faM77xXSMoIrGzzwRcS62dwmdCYxUniO4UQYNq5y0I7iOy\nqI2bTYlZGqzK" +
       "FCNFHoM8spYFT21qBYioBT2uI9PdTkFVLdmZ4MRpK6Rpkn7AkYtSVp+we/4A" +
       "C3rS\ndoCFi8WQWyxkaT6hHcPfCqY9CxfNATcy2/00bfHtor7JuoXW1h13RN" +
       "NwkbrtkQvTPJtIsIV6Y3PS\n3Ao8PBupazOYz8TmFoKC5hyb04OI6jSgRgKM" +
       "wjDTlH7QZ4n6xCWEkY01t2yHjftiazAFLI/d8b5E\nrIMZvSGGXphb4XC64b" +
       "Kx4qiOP9kE/cQxArPpz7DNNpj1J7G4E71NWp9tFrot4wkGJgsa5QCzgGnW\n" +
       "JSU4JKHlhJtaSzPzVIrICqXp6sU0UH2W788pact0HIcM8GA+WRIEJTDLeX07" +
       "3SlNnWXEMbkVQSJe\nDja54ximHS1scrgslWRds7UVm3BGoLhjTlCyS8LFMs" +
       "pDpjFGhF1mTPBduPYJblgPHJPYBL2UNRm2\nmfor1x/vhEDzcnnERUTX1XaI" +
       "w68dwxnLOBYO17kBjxV/Yi6txkgW6HRkYhho44RBAXE9VPxtH0MX\nrjbs4E" +
       "rqe4ITmCtSYqcJT80znONixuN6nCdQm8EAXvYGHEODbUXDeM5Wd4xFCiZjdU" +
       "V7xzB1KR0O\nc0bQBYjaAMVuDSBGuBvx88F2aDY8DQsUejQb8CyDz/MFVhA5" +
       "6nq7bN4W0QjHsWHmQcDa69ki0Mjj\nerSOAKRgPMFIF+3+uL3FjCbJF2ozFh" +
       "t6soxze+KUswGMk1QaqbkbZlm3C+6WBteczbZsS0k8VKem\nIIEm9RSIBg1O" +
       "wXqsuuCG+FYeSNpizA+WHizBGR6t4fF0bONir48aGhdwODXt4kTEN3ezrstP" +
       "mYVJ\nQGA05nMTntQXccInrGlseyOuo5qoGBDb3pjxu81ZzygTG5/bjD1TGC" +
       "AIACbdxgxZ2cZcwN1NuO2J\nmNmPsUAk10Zgpwuvng8Ue8xn2whVGp0Q2xqN" +
       "BlLs8hTQJ4Zu+LvyPTfIuJ3DAoTSI6RBxC58PGdF\nr7/bSHZ7LO4GEI1pHa" +
       "zlrOvbAb7AhClfCImXdbpW31872oRb5ENQHscEU4I/jUZYjhbKDl6LATTN\n" +
       "+hsH2RiaiyYNVEFM22aw2Ib6jFNn1w1X3ggLl8EEHR1BuTpzw3QXGVPf9Zah" +
       "P28aEzHnpBHaSkRC\nwHSSRiXSx2Ziz9LIDjnlmdjoQX0Fb3v1Dc/2umCfG5" +
       "EzdLnskdYIJhVoIAcWP8IJOjSwZQyo3YTF\nrKwRyWMEaIUou7V8ANTMVjJZ" +
       "jMeLIMuJjBRn9bZIj+TQwFVjqCz4aJJYVFMFrA28Ha0jzB6Zbpg3\n54Auzs" +
       "xAnubs1MISXzBEqj/I7G0jgLHhTFjhWneaqfUdqkSJlM7GhJ5NkrmPKH6q2u" +
       "kISpqFvdFn\nehNS2ulqnugIiq1UNFyNQKdl4315KcyTbe5lA7wAgBzVrVXd" +
       "CrO21gPo4XImTih2jYx3W9xyktVw\nOu4QImooHmMtF12gFGkGNlrbcKRtl7" +
       "AprUymI1CJm9KxVbTodMfz9Z6IJ2YzGZBZmLkiDmJyRHfd\nFYcyJAbPi1Sc" +
       "N8hwS0fedBNJINKAM0DSC9RC5oDb83hpxEqaFmMys267daFJQs0y7m4XWgJ6" +
       "uxGH\n9XCscBjDXCd4jPstgMzVmGnk6ERAJa3JqLnGFMUmJaRhijqpgdgAIC" +
       "whOETlOoCwfQRsqGMqMEw2\nKHIz7y2kMOq5Wh5HartJ4RFbYB5B4yLEAiMl" +
       "8FryZMEkwCqfTAqLAMOtFW3nbHMC1bsaTI0ABCpg\nHe5jDKhZbh5QMdCiOw" +
       "0EnbVDSjfb80FbWvvGhCKIgsW7KNx0acRMIcNOBNnJd+ORAOuTZX0lbHtM\n" +
       "Ik2sJSfZXXKaLBzOTJbDYrMAdDynbH0dYjFNiHLQ3sW2zBAKB6qQTWoZ3O1o" +
       "aRtQvc64kJVeo183\n2761zpesurY5ReiLGO+6OGTNOHzhebOtm/Y6LbjBtF" +
       "A8bcdU1mrrHJ0KPa+zQ7fkGklpepWpHR12\ntwZSH/QMcNbiAAgScFRw1kwH" +
       "NHRtJHV4BQCmjjOztZ2GLbG2wc+lKdtvc2qkoOtVN45bG560IYDS\n+iwaST" +
       "2oU9dLvE5ADJFpqBe2uMYyVFGiO6dpQGsPml0tai0jyBXLF6N82gUiAVwyAI" +
       "GgAGvx2jLw\nEzJpAA5tpzwlKPWObru2KQs2AFoZB7UKMBjSxawNNlXXAkVw" +
       "zgy9mI8TB9ZtLTbYRdKHCEgZkRa3\n2tHzAh57fWHcWKxXjFnnCp0heyyb5G" +
       "241yT0YLJyZQuEG9wKJiJ06SPdDEk6Spp2kEhKRNkF/dSS\nIa+FuphpDGgR" +
       "bSuWySJTnq3boTASGGuE8qNivcjjrly0rVgmRnO3WfRFoGgzMdxoCIVlEFJT" +
       "noG+\n0OjZW5rPVWWoZflMMVifmgxzzF3Vu+0EaCpbfFrC3TDG3kLVjCLqov" +
       "O1P4HCwKXSOc50KGJHFyN4\n26ZWS80hLMOYuFsOGiyHGbKYO2QkboCVXuf6" +
       "/YiT8dggx8Qm9rdLbkXSmDuVraUr9lNwPKK0bceI\nU8ZJQGc8sUYhSUYrMn" +
       "PbA0pKy2llZPfCAWKF7Trrd8cjWCviwkcTub1erw29gyE6uh1BepqHALfm\n" +
       "Q3o6h4hZPkvpdibPtzKarNrmbpfzKsswLS7v58yItuC6iiTiKJvE/HA3Bs0V" +
       "tbYja6P3Q1rzkQZD\n4ckiAhEIjelUnwMtVJr586hJ9JVE8hh8PWg4iNXs+m" +
       "sKWGZxvb3Cg6m3nGmDPi+utVY/KF+68FDk\nBSsoLygsnFmw4EpLPgMM3gXH" +
       "3EqQuGmEA3YAgotAFFSdpLxQaE1bvbqrx4Yc60N0gic4N48GAB1A\n+choRe" +
       "hura8ceA0xZUjgbHnDtcBsLe+0XdFv9HurnOuhBj9s9VZdA0e4jbmrA6ueum" +
       "ricB+aT+UJ\ntnaYxg6Em852N2v10kzHE1WZReiwG0IGwXfRzRgp1DI+8kIM" +
       "EA0MbKVezi2G9nQs8PXxSJ+pQand\nVmRJA+1t+FGP15GiP1ittCkgDodcR0" +
       "c2wXjXZl1onHRSt2ETwTBSuDkEGvPOhhTZ9hpayS24rqsC\ng4RDdAWu7D47" +
       "M5vMrB9leiZoc0tojiEeAS1gJvhgs7Hedtx4WqKD06FO4U3sYjWS+4AIdmQI" +
       "6ma8\nVY965DallgPUiHotr2V5erMXIok3GyRCYypSwUJPdTklpgAlEJsNuJ" +
       "x3PcrTYhSGRN1Z0bBKj4A1\nN0/kwq1PfaAQ5pbSplEGpieU3YIChNIBLIZT" +
       "a4aJwwWGVWkDc5ow3dync/dqn6eFsP4+ydjnNbdP\nE/rzdP9tZ3WAsPb86x" +
       "Ui96nOq6t/vvEx6QuvVKlOtXAe1x6PPf+9tpZq9nmd4DKT6b7uepY8//L1\n" +
       "p9SrVPfZhxUKXvyWK0+U+HMn//Il+K/uHF3OuuuhFiehu7wv937uXu79xGmJ" +
       "cL/Phdz7XiJ9csEy\nr1MI+ZaTce3p0tK3z6uEt3uefPs8s/u+e6I8Vbb3lO" +
       "3xqj1MFP0hhYALCfu3I+MThhafGfMsvd9X\nN/cZOX1P+Pslruqr31GVpA5l" +
       "qY/uMdHXFHvpjct0fpDFJ8pxldjfuqOclc6Ms9LZy+9rI9D7bgWJ\nFJlB4s" +
       "XanUNV61bqmeqtymamm3pbra/pF0qOd16+9aF4Y0bHDzHqnZfvfv/LFypywb" +
       "ftumdfT4w9\n7cQ/rJ+V6Xol9CXrVOWcm+fWOfl/Wgdst++3zqHec9E8ZlyZ" +
       "49YHXmFv3af4hx8Eyl7Fu98WRh47\n27SaysuBR0qjV4XFZx/4X+nw74fy0h" +
       "c/eOfz/s0/OtqXv87+obhO1R7TE9u+WBq70L/uh5pu7pW5\nfiiUHTR7La69" +
       "8f56e1yrn//YC/zqgfTjpWyn4e1H/DM4v/0enEvLa6Er2fdgnf0vJKoeaCEb" + "AAA=");
}
