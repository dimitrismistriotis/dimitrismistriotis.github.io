

import java.math.BigInteger;
import java.security.*;
import java.util.Random;			//import java.security.SecureRandom;
import java.security.interfaces.*;

/*
 * Custom implementation of ElGamal
 * Ideas, but not copy-paste from:
 * http://faculty.washington.edu/moishe/javademos/Security/ElGamal.java
 */
public class MPElGamal {

//	private final int RandomBitLength = 50; //randomly chosen
//	private final int CryptographyError = -3;
	
	private MPKeyPrivate privateKey;
//	private MPKeyPublic  publicKey;
//	private BigInteger{Owner:}   zPlayer = null;
	
//	public static int Apos = 0;
//	public static int Bpos = 1;
//	public static int EncryptionArraySize = 2;
//	public static final String Seperator = "-";
	
	//missing:
	//verify signature
	//decrypt
	
//	public MPKeyPublic getPublicKey() {
//		return publicKey;
//	}

//	public MPKeyPrivate getPrivateKey() {
//		return privateKey;
//	}
	
//	public BigInteger getZPlayer() {
//		if (zPlayer == null) {
//			return generateZ();
//		} else {
//			return zPlayer;
//		}
//	}

//	private BigInteger generateZ() {
//		zPlayer = BigInteger.ZERO;
//		int zLegth = publicKey.p.bitLength();
//		//SecureRandom sec = new SecureRandom();
//		Random sec = new Random(); //Temportal measure until secure random is compiled correctly
//        do {
//        	zPlayer = new BigInteger(zLegth, sec);
//        } while ((zPlayer.compareTo(publicKey.p) >= 0) || (zPlayer.compareTo(BigInteger.ZERO) <= 0));	
//		return zPlayer;
//	}

	public void initMPElGamal() {
		//initialization
		//SecureRandom sec = new SecureRandom();
		Random sec = new Random(); //Temportal measure until secure random is compiled correctly
//		publicKey  = new MPKeyPublic();
		privateKey = new MPKeyPrivate();
//		//assignments
//		publicKey.p  = new BigInteger(RandomBitLength, sec);
//		publicKey.g  = new BigInteger(RandomBitLength - 2 , sec);
//		privateKey.x = new BigInteger(RandomBitLength - 2 , sec);
//		publicKey.y  = publicKey.g.modPow(privateKey.x, publicKey.p);
	}
	
//	public MPEncryptedMessage encrypt(BigInteger message) {
//		//SecureRandom sec = new SecureRandom();
//		Random sec = new Random(); //Temportal measure until secure random is compiled correctly
//		BigInteger pMinusOne = (publicKey.p).add(BigInteger.ONE.negate());
//		BigInteger randomK;
//		randomK = randomRelativelyPrime(pMinusOne);
//		BigInteger resultA;
//		BigInteger resultB;
		
//		resultA =  (publicKey.g).modPow(randomK, publicKey.p);
		/*
		 * b = ( (y^k)*M ) % p =
		 *   = ( ((y^k) % p) * (M % p) ) % p
		 *       ^^^^^= ypowk  ^^^^=mpowk
		 */
//		BigInteger ypowk = (publicKey.y).modPow(randomK, publicKey.p);
//		BigInteger mpowk = message.mod(publicKey.p);
//		resultB = ( ypowk.multiply(mpowk) ).mod(publicKey.p);
//		MPEncryptedMessage mpEncRes = new MPEncryptedMessage(resultA, resultB);
//		return mpEncRes;
//	}
	
//	public String signString(String message) {
//		return "stab-output";
	/*
		//getSHA1Byte
		byte[] hashedMessageByte = null;
		try {
			hashedMessageByte = Signature.getSHA1Byte(message);
		} catch (NoSuchAlgorithmException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			//System.err.println("No Sha1 supported, exiting");
			System.exit(CryptographyError);
		}
		MPEncryptedMessage signedMessage = sign(hashedMessageByte); 
		return signedMessage.strOutput();
	*/	
//	}

//	public MPEncryptedMessage sign(byte[] hashedMessageByte) {
//		
//		BigInteger hashedMessageBI = new BigInteger(hashedMessageByte);
//		
//		BigInteger pMinusOne = (publicKey.p).add(BigInteger.ONE.negate());
//		
//		if (hashedMessageBI.compareTo(pMinusOne) == 1) {
//			//System.err.print("messageBI: " + hashedMessageBI 
//			//		+ " is begger than pMinusOne" + pMinusOne + " proceeding with mod (" );
//			hashedMessageBI = hashedMessageBI.mod(pMinusOne);
//			//System.err.println( hashedMessageBI + ")");
//		}
//		
//		BigInteger randomK = randomRelativelyPrime(pMinusOne);
//		BigInteger kPowMinOne = randomK.modInverse(pMinusOne);
//		
//		BigInteger a = (publicKey.g).modPow(randomK, (publicKey.p));
//		
//		//steps for calculating b:
//		BigInteger amulr = a.multiply(randomK);
//		BigInteger hashMinusAmulR = hashedMessageBI.min(amulr);
//		BigInteger b = kPowMinOne.multiply(hashMinusAmulR).mod(pMinusOne);
//		
//		MPEncryptedMessage signedMessage = new MPEncryptedMessage(a, b);
//		return signedMessage;
//	}

//	private BigInteger randomRelativelyPrime(BigInteger coPrime) { //coPrime is modulo as well
//		//SecureRandom sec = new SecureRandom();
//		Random sec = new Random(); //Temportal measure until secure random is compiled correctly
//		BigInteger gcdRandomCoPrime = null;
//		BigInteger randomK = null;
//		do {
//			randomK = new BigInteger(RandomBitLength, sec);
//			randomK = randomK.abs();
//			randomK = randomK.mod(coPrime);
//			gcdRandomCoPrime = randomK.gcd(coPrime);
//			//System.out.println("random: " + randomK + ", comparisson result: " + gcdRandomCoPrime.compareTo(BigInteger.ONE));
//		} while ( gcdRandomCoPrime.compareTo(BigInteger.ONE) != 0);		
//		return randomK;
//	}
	
}

/* TODO: elevate them to JIF when the rest of the proram needs them */

/*
class EncryptedCard {
	public final static String Seperator = ", ";
	MPEncryptedMessage[] encryptedVector;

	public EncryptedCard(Card inputCard, MPElGamal cryptoSystem) {
		encryptedVector = new MPEncryptedMessage[Deck.numberOfCards];
		for (int i=0; i < Deck.numberOfCards; i++) {
			encryptedVector[i] = cryptoSystem.encrypt(inputCard.cardVector[i]);
		}
	}
	
	public String forOutput() {
		String result = "";
		for (int i=0; i < Deck.numberOfCards; i++) {
			result += encryptedVector[i].strOutput();
			if (i != (Deck.numberOfCards - 1)) {
				result += Seperator;
			}
		}
		return result;
	}
}
*/

/*
class EcnryptedDeck {
	public EncryptedCard[] encCards;
	
	EcnryptedDeck() {
		encCards = new EncryptedCard[Deck.numberOfCards]; 
		
	}
	
	public String forOutput() {
		String result = "";
		for (int i=0; i < Deck.numberOfCards; i++) {
			result += encCards[i].forOutput();
			if (i != (Deck.numberOfCards - 1)) {
				result += EncryptedCard.Seperator; //using the same, 
				//since the other part knows it's length and can therefore decode
			}
		}		
	return result;	
	}
}
*/

/*
class MPEncryptedMessage extends MPEncryptedMessage {
	MPEncryptedMessage(BigInteger a, BigInteger b) {
		super(a, b);
	}
}
*/
