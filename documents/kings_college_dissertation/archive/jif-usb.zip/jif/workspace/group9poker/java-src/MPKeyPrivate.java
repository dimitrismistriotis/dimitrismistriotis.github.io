import java.io.PrintStream;
import java.lang.Object;
import java.math.BigInteger;

class MPKeyPrivate {
	public MPKeyPrivate() { }

	public BigInteger x; //El Gamal's x, random number less than p
}
