import java.io.PrintStream;
import jif.runtime.Runtime;
import java.io.FileOutputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;

class ExamRoom {
    private IStudent alice;
    private IStudent bob;
    private Exam exm;
    public jif.lang.Principal p;
    
    ExamRoom ExamRoom$(final jif.lang.Principal p) {
        this.jif$init();
        {
            this.p = p;
            this.alice =
              new Student(jif.principals.Alice.getInstance()).Student$("Alice");
            this.bob =
              new Student(jif.principals.Bob.getInstance()).Student$("Bob");
            this.exm = new Exam().Exam$(this.alice, this.bob);
        }
        return this;
    }
    
    public void startExam() {
        Exam exm = this.exm;
        if (exm != null) exm.runExam();
    }
    
    public static ExamRoom room;
    
    final public static void main(final String[] args) throws SecurityException,
        IllegalArgumentException {
        final jif.lang.Principal p = Runtime.user(null);
        {
            Runtime runtime = Runtime.getRuntime(p);
            if (runtime == null) return;
            PrintStream output =
              runtime.stdout(
                jif.lang.LabelUtil.toLabel(
                  jif.lang.LabelUtil.readerPolicy(
                    jif.lang.PrincipalUtil.bottomPrincipal(),
                    jif.lang.PrincipalUtil.bottomPrincipal()),
                  jif.lang.LabelUtil.writerPolicy(
                    jif.lang.PrincipalUtil.bottomPrincipal(),
                    jif.lang.PrincipalUtil.bottomPrincipal())));
            if (output == null) return;
            output.println("Starting exam");
            MPElGamal pmel = null;
            pmel = new MPElGamal();
            ExamRoom rm = new ExamRoom().ExamRoom$(p);
            rm.startExam();
            output.println("exam finished");
            IStudent a = rm.alice;
            IStudent b = rm.bob;
            if (a == null) return;
            if (b == null) return;
            a.tellResult(output);
            b.tellResult(output);
            try {
                FileOutputStream out =
                  runtime.openFileWrite(
                    "gradebook.txt",
                    true,
                    jif.lang.LabelUtil.toLabel(
                      jif.lang.LabelUtil.readerPolicy(
                        jif.lang.PrincipalUtil.bottomPrincipal(),
                        jif.lang.PrincipalUtil.bottomPrincipal()),
                      jif.lang.LabelUtil.writerPolicy(
                        jif.lang.PrincipalUtil.bottomPrincipal(),
                        jif.lang.PrincipalUtil.bottomPrincipal())));
                if (out != null) {
                    output.println("Appending Alice\'s Score to gradebook.txt");
                    a.writeResult(out);
                    output.println("Appending Bob\'s Score to gradebook.txt");
                    b.writeResult(out);
                }
                out.close();
            }
            catch (final Exception e) {  }
            output.println("Printing current gradebook:");
            PrintStream outputP =
              runtime.stdout(
                jif.lang.LabelUtil.toLabel(
                  jif.lang.LabelUtil.readerPolicy(
                    p, jif.lang.PrincipalUtil.topPrincipal()),
                  jif.lang.LabelUtil.writerPolicy(
                    jif.lang.PrincipalUtil.bottomPrincipal(),
                    jif.lang.PrincipalUtil.bottomPrincipal())));
            if (outputP == null) return;
            try {
                BufferedReader in =
                  new BufferedReader(
                  new InputStreamReader(
                    runtime.openFileRead(
                      "gradebook.txt",
                      jif.lang.LabelUtil.toLabel(
                        jif.lang.LabelUtil.readerPolicy(
                          p, jif.lang.PrincipalUtil.topPrincipal()),
                        jif.lang.LabelUtil.writerPolicy(
                          jif.lang.PrincipalUtil.bottomPrincipal(),
                          jif.lang.PrincipalUtil.bottomPrincipal())))));
                if (in == null) return;
                Gradebook gA =
                  new Gradebook(p,
                                jif.principals.Alice.getInstance()).Gradebook$(
                    in);
                int[] resA =
                  gA.readResult(jif.principals.Alice.getInstance(), "Alice");
                outputP.println("Alice has taken " + resA[0] + " exam(s):");
                for (int i = 1; i <= resA[0]; ++i)
                    outputP.println("Exam " + i + ": " + resA[i] +
                                    " point(s).");
                in.close();
                in =
                  new BufferedReader(
                  new InputStreamReader(
                    runtime.openFileRead(
                      "gradebook.txt",
                      jif.lang.LabelUtil.toLabel(
                        jif.lang.LabelUtil.readerPolicy(
                          p, jif.lang.PrincipalUtil.topPrincipal()),
                        jif.lang.LabelUtil.writerPolicy(
                          jif.lang.PrincipalUtil.bottomPrincipal(),
                          jif.lang.PrincipalUtil.bottomPrincipal())))));
                if (in == null) return;
                Gradebook gB =
                  new Gradebook(p, jif.principals.Bob.getInstance()).Gradebook$(
                    in);
                int[] resB =
                  gB.readResult(jif.principals.Bob.getInstance(), "Bob");
                outputP.println("Bob has taken " + resB[0] + " exam(s):");
                for (int i = 1; i <= resA[0]; ++i)
                    outputP.println("Exam " + i + ": " + resB[i] +
                                    " point(s).");
                in.close();
            }
            catch (final Exception e) {  }
        }
    }
    
    final public static String jlc$CompilerVersion$jif = "3.0.0";
    final public static long jlc$SourceLastModified$jif = 1246876041000L;
    final public static String jlc$ClassType$jif =
      ("H4sIAAAAAAAAAM06CXAc1ZU9o8uSZUuyJUvI0nhsZHxhST4AxyIksiQjwdiW" +
       "JZtDHOOenh6pcU93\n090jjcwRh8uGLZbNEpOwibmWAAFC1pACArtZiFmg1o" +
       "EtoJaz7HBkCZUASRwIUEtq8977fU+PrKSo\nZF3V363f773/3vvv+u/P/R9w" +
       "ZYbOtV4kZdrNSU002s+QMoO8bojpQVWe3AZTSeHFa265/T/WvfdM\nlCtJcJ" +
       "V8zhxTdcmcNLnaxEX8ON+RMyW5IyEZZleCq5UUw+QVU+JNMb1RV7MmtzChAa" +
       "lRWTU7xLzZ\nofE6n+2gxToGe2TeMACtnGaNi7nLuUhe5+I2hsUU44iAGUur" +
       "7uicd+D8h+tKuJoRrkZShk3elIQe\nVTFhiRGuOitmU6JudKfTYnqEq1NEMT" +
       "0s6hIvS7sAUFVGuDmGNKrwZk4XjSHRUOVxBJxj5DRRpzXt\nyQRXLaggk54T" +
       "TFVnHAK/GUmU0/ZfZRmZHzVMbp4rKZNvI86DeFUSMKZneEG0UUp3Skra5BYE" +
       "MRwZ\n284EAECtyIqgb2epUoWHCW4O07zMK6Mdw6YuKaMAWqbmYBWTay5KFI" +
       "BmaLywkx8VkybXFIQbZJ8A\nqpIUgSgm1xAEI0qwS82BXfLsz5by6j9eN/hJ" +
       "PEo8p0VBRv4rACkWQBoSM6IuKoLIED/NtX9z4Nxc\nS5TjALghAMxguhc/sj" +
       "3x3r8vYDDzQ2C2pC4SBTMpfH5yS+uL3b+oLEE2ZmiqIeHm+yQn4x20vnTl\n" +
       "NfCGeQ5F/Nhuf3xi6Olzd98r/jrKlQ9w5YIq57LKAFcpKuke670C3hOSIg5w" +
       "pTL8B5JnJFlEycvh\nXePNMXrPaxz7NxueCnxMrrovz2eHVDXbDq6IUHPyON" +
       "ZMRCLAUUvQH2QwpX5VTot6Urj7nf+8tO/M\na/dGHfuwVjG5GTZVLhIhQo1+" +
       "0VBXafTc9x/sqv37lcbD4OIjXKWUzeZMPiWDBNW8LKsTYjppki3U\neezO9t" +
       "3qFJgNWGBSBkLMgzVuXOcWBc3DdaMBChKCeMnJm7l9sb5/wp1EzdcjdcYa6H" +
       "En46162fAF\nZ+zYu6gEgSZKQV8oySJfyAqhnRQmn2xY/9gTnz0e5cpGIDAZ" +
       "vWKGz8nmYM8GNaeAt9c7U0MiBAIl\nwadEOcHNZP7Og8/aXlehCYRjco0JWN" +
       "fyAxnhOwgL1DBTd4kgWgxss+3YKkgKg3MbNn/vD/PvY+Yc\n1NqgrgpiGsKU" +
       "i5DsXLNw822rPwO5wFOBWxN4RcePBT3V51xdliea3KICxw8u0mUHNZSkFITL" +
       "qHqW\nl5GMrZMqc0xXJ9wZstdZ9F4Le4T7NN+y8dlk0B6rxuF43O+AsBQvfz" +
       "+wp//dQ0sviHpDa40n1QyL\nJnPUOtdctumiCPOHvz14474P9pxHtsKMhcsT" +
       "T/MiYJJzQ2JFe1P9N29a9t1XbBuc6xLt1nV+Ek0w\n//UXW29+ht8PcQR825" +
       "B2ieTDEccaG11rJAMQ0yxUvTBzzd74SZn6KBeFrSKDgVxGXhKDiIQY9t+V\n" +
       "pJpqR4Gz4GkKUSCs1uyuRiSB0VFaNilce27zg7f9tOGDKO5aVJBMrrUgG6hp" +
       "7z67EQP2NKdB2CdT\nt1iMjgOJliCJs3jHfjERNAb5sZiZu7n68/+d/1IvST" +
       "8zLRqCLmkYSq3lyk31DFA2pkHyKp1XDBkK\nB+ZT2+hjX17TuwK2happDlGN" +
       "yZ2JjGZVXRuThDjxElczcWa8cV4fzWVFxYxrOOnJ6vGlKRRZTMf5\nlDouxl" +
       "OT8UsuWwaKXkyC2Wy19/CKopoB5pLCr7Z8+MQuTXyWOfACP04B9MIHWn/bdv" +
       "+Fi8neyBFM\nLoKGNz+oxUFe0i1NPlF/5b5rP685nTRZBaxnoDyThEncm2BA" +
       "6nG+YlTCymPUBm4tAB5wPzMtn6SR\nFxzvl8JhxSvJSbvf++ih/354CUqCqF" +
       "2AFwsKMSTykKXYCoDS9s73f3f1jLtIjjJ1gsLWAg9XGtQy\ngqTxkJPtNywP" +
       "daKCi/SBipsKNGWR77otx6utnwk2R7O0vLOLBO6Qb9+gmqaadRZJCquf7Wzs" +
       "vmfT\nAe8uBnA80KsampriR8UqClKOHR8fsGMHocCWibFlfiUHWPKqelX1HT" +
       "/5n3u/fxtjLrg5YRj/fN8n\nd+5actcoC2u4Zr/GImEibJvOhore3aarlu99" +
       "46MfrWnxbBPpHkSdIEC2EzhutKi61INrtfgydUIV\neNnNZfWXbTjl7sPiAR" +
       "bsZW/yDFaKAcynbxpde+sPf1jGVBKskDwRKimse3m8rvxfbs1GuQooBMjx\n" +
       "4YhyFi/nMGeMQHlu9FiTCW6W77u/1GZ1ZZenpF0bSJTeaFqKrLihfRYO6/IR" +
       "jrz+PMJYTONSq6wx\ngZak8DKBf5k+deCwiiZOMQp1AlufheJ03KqevxG789" +
       "2H3hmqj3qOGMcXJnsPDjtmsNRDNrlwqhUI\n+qkVC++/fOhIiil+jr+i7FNy" +
       "2V9OHhSXnHr9WyEFaaXjTCQRDik7P+N4Ir2vxLRtJW8oW9307VpS\nt2FA6I" +
       "BUcmrj3rf/q/X5ba6dr/RlZk+u7IaTa49T2yUF5fHsZMnTx7UTn1UOZ6HlzC" +
       "J4usOyscNc\n65QR4+bzvqEpnd2Sn80SYrME2FwSht2XB1cDe/DEHX7tvXX/" +
       "etnzrwV1i+MAbeAKf3AooOENEvsb\n1Td3312xxY6Xm8ACuyEEsJLOtJx43O" +
       "RKNqip4BwdLrDwzLOp03Bos6TbQGMvm/KX665821TNI1r/\nWz/9+dXfajpk" +
       "MzPgIJ/gF8mL5pXm1a83H1lx4g3POtIQD1dYZPC/q2jc6pnp97wnisycpvmF" +
       "OkbE\noyWsv67QvAs7f1lmg6ekYODaiI0FO3RlU5d8fPCWqrhrNfPJYsoKwq" +
       "oPLSlE73lzz7KmGjCT6Ag3\ne4w3BhRwYmx/iPqx4myA1K6fbL/l0+fMI2Rx" +
       "7mkDsReSms91nKTacpQZ+HicxAp5t4aGvAqwB8id\nIlRvZbxjex0OUfw313" +
       "NQHhg2c2mo4uyD8t3ERHdBF2s4lzJMT0ui/tSLv7Rd2rKVha1ljtCwcDt1\n" +
       "nyzUIN5Ny349vqLziv2UC0tTvEEeVwFaNBDS5OLF+1tEi0XXKhzuotf7SLa5" +
       "4EG2LHT0LWA+KTx+\n+OiNH56161LSfQ2tR1XYMFv5BE/h5CK1DfvhunwNtV" +
       "Bxk8LiN2t/84evvb2COiW2ZN5D1yZeKzh0\n9fPGGMyXVbz+5MF5O14o4aIb" +
       "uSpZ5dMbeTricpVwRhSNMVVO57WvfJW2snoCraPWis7HuVIPIlOu\n2T1TMT" +
       "pj/Z0nf1RCJyfPIbfJL7S3t2VlvJgHwkfVk+xco62HZ4FtX2RQzKo4ZrSPFh" +
       "ptiZ2nTa5c\ny6XAZuHFoA4kGHFkmGB3aLQOGcv9hBbNByMoi7V5DHFtYdsf" +
       "3MmNlf/X9dLMw5usonNMMto6sesY\nZgVd7HDxIA41HHMRHPf7vDUGTyU+hd" +
       "76DA63Q+hPWaG/w7VgRuoed+IQiUmzD9D4UOF2u9oMJBYr\nfzyFw8+m5rcB" +
       "nip8Cvl90eZXzGdDQghiRVjEocRlh49XPAKBS5bit+I81FnGgrxUF/LweqGx" +
       "RPH9\nQsdS8nTY87OHRFtCiBIDOKSKMzQHnrh1HG4uZOjtIgwd8Vpsqa6qWX" +
       "eL69yFazwL0+wSK3HheKIn\nIXFow63F+sHkd3vO+V31NfxTF9jZGRy10lS1" +
       "lbI4LspuPgwS2UTtb9uDby+fky5NrGsKJsRoQfj3\n4yWFQ6/V/LZv7aF3v7" +
       "hmIOXP8L7fgimFSArmI8mjr5z82lKWU7wNGEZsm+/gEHd2eyY8x1lu0BCw\n" +
       "FNqrj0JSLO331EX2lB9hn4Bv3UTPsEMb/Q9hr3RcldJcxIO/s6AGx7+zjght" +
       "8JwSIoKHhB5KIrzy\ndEz1evp41FkHW2cLLcdqCVFVpDIksJOvkr5weDdcL1" +
       "HL4vxOjHJ1hKxHAKt9YKtCwP6s1hW7Eopn\nwSqLtK6Q6HqmEZS1yiM2DjOP" +
       "LRiC1Vrc4ztpLjIXh/q/lHBhtbtd2amoEwqrtFa//NzPXurNP2BH\niGpKoZ" +
       "HYlNtAEAwMzBFVQn9wXKhNcm60KmiBWLxYHbd3Dqx9Xvn23h/bzJzExNVc1U" +
       "bafFMY2N0I\nfTbTGQvDkeU4db4b+qdSLg7oGJEVtm0zdEwCkZX0FjC9NfB8" +
       "6dimh2CnhZre1mmZHrwY07C+5evj\ntgEix82wK4jpHBEjqwqOiDDlHNXs96" +
       "uKzGz1zPR73hNFZs5mM9ZGdFsb4bJEe9Hh2QtqtkTodY2z\nFxtwIBPAg0bw" +
       "4pPuCZgNn/9hI/9v6vW11H93TguVwRvjwgth3z0vWdxMD2cWl659QalSS4U4" +
       "9qXa\n2RWwppGMvWScfUWw8bUfIP+c2FbhrRRNrmFYFHL4C4C+vCBSPx+LKR" +
       "OKA2l0paELHZ676TBIq13g\nkN8ATybEMG0zgeNL0FfPUCXF7XMnhRmJzuYn" +
       "E5fusZqBYeA2aGzJ2Oz1WzcZVETPvogIZTVVEa0M\nfwJra6Kehln32Dnv9K" +
       "iyLAoohtG2XcmqaSkj4TXpsGjubv3HF274zu7tjIETj43jzh+3gdt96MJP\n" +
       "YsRQRKCC3jl2uWDs9NUYvCHFMxis/6r8ysi+w8tjbP3AGQ2+P9Z79b6bHn1k" +
       "LbtExUqz1qrQS5gb\nam6jJdCl6Z2EAkUSPJ2aj+/sHDp4w4GvsSYU3muH3U" +
       "N0C2DdxiB8ZUeuAWfDe+DpDQtYOrfc3+oJ\nru1t97x+sK7z9NjodW67x9e2" +
       "t27GHCaofdycub6i841HF7F7bgVKT31zToY6LypLIfenvpaz764s\nH5JA3L" +
       "WGVNW8enVs96ty7zjbkcIrOwc41jT3rXndlT+I+n6kgKvMpjNcROAoCTjpw9" +
       "9U6nXU2g/P\ntmJ5YLrNvADNs+ERp0EzvG3oFmpu7B72xO7hgtjtm4EgN98T" +
       "5IKxJCRKLXajVMsAeM4oL3db+SsQ\nrNoLg9VUCG6LE1j05K/IdpfryDk0nl" +
       "/EvfDbDtpP9k6xPpIJ7DC+4DkiQnXMOCWjy21tLHK1UYxZ\nQliI8H8sUgN5" +
       "qjHXKHt4oKd7u+MT8659/8j6jlun0x3HrnijlSRiQSuZoqiP7HBI4HlgXhES" +
       "XlXt\nd1WVDxwt8GS0brpc2K33adnxMdrfblr+WxmIyUW1JU5+Z/XiNMsbbL" +
       "tCMYTYdoVz8RdTPyDolr+S\n4zDxCxWDw5UuO9f8P2Dnxum7KAJ+C4ebp+FK" +
       "5B3F/QVYshwGJ+6Y0isQ4ns4YIsvct9f1cKLqS7v\n+TmbpoUUwexy1r5aCZ" +
       "Xri/B2/699sNOUYz9jTQrvaxee/sbQz++1bumL9txdjHN+cF48/3fb/oFd\n" +
       "tAsyv2sXLlgB5wF2/LLCrfdeNkjNpiW9+XLmuit/UeP8+AEH1syrsZQy7r3t" +
       "KaCD72fN6nr1zMce\nuyfYYLN7REiisUjTfu3Sjys+fe7oV/13nPaR+0+a01" +
       "wEaywAAA==");
    
    public ExamRoom() { super(); }
    
    private void jif$init() {  }
    
    final public static String jlc$CompilerVersion$jl = "2.0.0";
    final public static long jlc$SourceLastModified$jl = 1246876041000L;
    final public static String jlc$ClassType$jl =
      ("H4sIAAAAAAAAAKV6aezsWHZXvdevt5qeme6e6Vl7Zt50OpoerLTLS3lJEyGX" +
       "yy67vFSVl1qcGT28\nlu3yVt7tgQE+kBmIQkDMoBBBWARCgvnAIiWfWKREIL" +
       "F8yQciPhBAiQISBAkQECQguOr//u+9fu9N\n5wMl3fu/f99zzzn33HPOvdc/" +
       "/+C3Ry8W+eh+lkbdMUrL98suc4v312ZeuA4dmUWhDQ8e2NBfnXzm\n73zjF9" +
       "94YfRJY/TJIFFLswxsOk1Kty2N0WuxG1tuXlCO4zrG6I3EdR3VzQMzCvqBME" +
       "2M0ZtFcEzM\nssrdQnGLNKovhG8WVebmV5m3D8XRa3aaFGVe2WWaF+XodTE0" +
       "axOsyiACxaAoPxBHL3mBGznFefTt\n0R1x9KIXmceB8DPi7SzAK0eQvTwfyM" +
       "fBoGbumbZ7O+TeKUiccvSVp0c8mvG7wkAwDH05dks/fSTq\nXmIOD0Zv3qgU" +
       "mckRVMs8SI4D6YtpNUgpR1/4oUwHolcy0z6ZR/dBOfrc03Trm66B6tWrWS5D" +
       "ytFb\nT5NdObX56AtPrdkTq7V66bX/8yfX//P+3avOjmtHF/1fHAZ9+alBiu" +
       "u5uZvY7s3A36ne/x5/qN6+\nOxoNxG89RXxDQ/3oL+nif/iHX7mh+eJzaFZW" +
       "6NrlA/t/Y29/6Vep33z1hYsar2RpEVxc4UMzv67q\n+mHPB202+OJnHnG8dL" +
       "5/2/mPlH98+KN/0/2Pd0cv8aOX7DSq4oQfveomDv2w/fLQFoPE5Uf3ouHP\n" +
       "MHMviNzLzO8N7cws/Wu7zUY3v08M5eVLKUevMa0ZK2kavx8G3oXq9fZSf7y5" +
       "c2fQ6O2noyMaXIlL\nI8fNH9h/4zf+6R9ihD/x3buP/OOhlHL0yi3X0Z07V0" +
       "af/fDULrZyLi79n/7uB6//qR8rfvHu6AVj\n9GoQx1VpWtEwg9fMKEob13lQ" +
       "Xn3hjSf87rrcg6+8Zg1uM3jgg2hgdHXTYYJ1Pnrnafd4HFT80DKH\nNf8WJo" +
       "++/2Xm5y8rebH8py/cb1Qb7Hi60e21r6vfXP7B777zwoWouTfY6zKTd39v7g" +
       "/s9afekv/6\n//ji37rxlKcVWuep7TpDPng84MEE+ar8l+H/dXf04hAEQxoo" +
       "zWEhh5j68tNB8CG//eChk5ejd56J\nqaeFfHCbLy6muiuOPualeWxGFza3QT" +
       "4u/TxtHj+5usLHru1P/O7N7/8+LL875AI6jbPBz/L7C3fQ\n1SxdJ7txnkv1" +
       "lYtZn5r4NS39N/473G/9s/e+effJDPbJJ1Kd6pY38fDG41XRctcdnv/rn1v/" +
       "2e//\n9nd+8rokD9ekHL2UVVYU2O1V0U/fGVzgU8+Jzfc/9+nv/bmv/4Vfu1" +
       "3zTz3mTuW52V2WvP1jv/ql\nP/9PzL84xO0QS0XQuzcxc5U0uhVwqX/ftQ08" +
       "0fmw9+KBT4cNe0nat+sQW9/677/8C+P7N3pcxnz+\nyuGV4tkk9aGBD+z+H+" +
       "i/8Dv/ovz1q+kee8mFx5faZ8VuzSdckviX9Rsv/e2/FN8dvWyMXr9uNGZS\n" +
       "bs2ouhjWGLaKgn74UBx9/EP9H077Nznusee9/bTnPSH2aZ97nCWG9oX60n75" +
       "STcbDPHaUN65GORS\nrinpJi/dGWWXBn4lfOda/+gjH3g5y4PavOzJoxeHvf" +
       "fhhvfGkIp4tawcN7lmiI9fnyIfEvXlobx6\nKc+K+gOXiixHL1ipdWn+xA/j" +
       "8dZQxpfyLI/ZLQ+3jW91undJj8/j9cZQvvKQ52vP8lo8Z+qX9teG\nWd/Jbr" +
       "m/OWTy9y9LNSSaILGDzIyeJ+vNodwfyhcu5VlZ8rOy7l5lDfFWXM9Ag9B7+Z" +
       "DjH4X8QwmX\n6n57Z1iUF5H3J+9PLv9rz3J7Yej3guRGua9dKmXg+Nkwst+9" +
       "TSzb4WA1bIDvDhO6ndzr16i9zu7m\n/PEcwUMgfeIxmZgOh5Sf/s0//c9/9k" +
       "f+zRA4y9GL9cWph3h5gpdcXU5xP/WD73/pY9/7tz99Dc3B\ntu+sfv6PvHfh" +
       "+o1LtR1OOBft1LTKbVc0i1JKnWA4kDlXBZ+N3sH88bCD1w+PGH/my3/tt/7e" +
       "byif\nvvvEOexHnk3bT4y5OYtdw2OctYOEr36UhCv1rwBf/cG3lV+3bnaeNz" +
       "+87TJJFf/77pfdr/3+n/l3\nz9m170Xpc+1ZvvWzHFrw1O1PmmD0nrIhQydT" +
       "olINveqWes1PEr8wuNZXNZRqO/5UBJuwcYLd0ijn\n3GrlJj6W2TqJjCfkJA" +
       "ztRvGJaiEalsxkqyaw4h1FsTSUUTSVl0bAxkcoZcp0afY4NzvRhk6pSsPr\n" +
       "THkmSBz3dGCdC2o6Nlhki2CIh+MIiNR1DVTgGlTIxjhYq3KLngwnl1V9MoEL" +
       "YCOlK8JKw2yz3bkI\nZWiqy7EmjE1BDdzVniONI7pc2sst0fut5tixLYuJ2T" +
       "J7YiUDitTtpnzHGEbk0ueprjfAZqsDS1my\nIGWLS3HZ0z5lRspO0/FW7I1x" +
       "6jFYAsDHVksXLqy5EkWXycKUAzwRK913pwAP+4Wuo2hALfQqx6vA\ndoA54Q" +
       "OlUC1TJT8Zqn9C3IjfuOOtxvqBsqhWQRnr2LJyBE87JGfmDMmMpE0KzOdrFS" +
       "8ond0uqnm8\nkIW8MU7oPlQ5RV9t29myDadzRcn6fTnuNspeNI/H0xTVNHab" +
       "cJQALvRYn4CGZyixwfVbycrQXDDk\nmiewucvqqiQYicssJrqeIeopN6ezAy" +
       "MpjTGGCZShGLrs+PPRgt1MT3ccvUNXE7yXBExyGuxQCaZE\n7c5WfJjtNLOb" +
       "Ciw/i02xa04tsT111p7lN5axJKjxOeP1o3qMoZZi+Mm5UQl4tvfEop9aHRaS" +
       "rgz6\nyzWTEtlkO1NqNKfo024zS1UJ4yshFXlmDsrlnuxRubXH6lQLKfHoU1" +
       "J7rHwbLEKkRXKiPszn/Qam\n4YxG1ZkmZR437VSgEhELSEWGgY04OPMuFwPd" +
       "JkFbeFInWjSWPXrhbqYsKPuVh7QBtop6hyRyMMyF\naEM20wN/nuKiQLF2Jl" +
       "QnF8MnNOKvVP44bTJNJGbTZbJkI6aza3+8d9eytM/XZtvjclu5dNJKeZ7W\n" +
       "Pexy2/nemp8xXufW3Uo2JIUWKV2vNxy8abL9dKulJabnIZ54AFGuQGlsgs6C" +
       "86pmGy6mC83Yij7v\nb1IIGEy0Nz3NJluwONcIHtnWHF3x4V7Y6b1rSOtgN5" +
       "/JO0IUCu0QZtkpQPSx6/YrskTO7PIo7xYz\ndXYSpWO/rfYrezezkbljSjPa" +
       "F2hXSpYxHpGFNQWbDGJ6xw4d+2BiHJOgGITBHsWODaA/VNiROaqG\nsNkSaa" +
       "cuvY46+4myiRO4PYDkUUv6iTu1swU/p4x6Jyx6IokPErGQTZcqSRvXJ1Iwo/" +
       "ho3JgOs7I5\n2VjjqyMBmvvI9emDEtrpZLmTB75t4q+aowjNZ5qDno67Y1sU" +
       "AHIQTkfhiEiWnID1HFzXB+BgjyH5\nfMyPWbAoBD2Yzou9KDcEDOfrZjVt2N" +
       "Vs18qoYrvrmYZsp1DrRIFrIgJPtw1RTWJ90EI9sbwmnrnz\nbhxNF1JuSGd7" +
       "0u6XQ+YpSscgWVR0UQ2XZaAjnOg0mWF5W7EosgKoYrapvR5oMhB0NpOiDrhs" +
       "bqKT\nBNp04niZrPVV6dhlFQf0esXVPYSiOLoms5YrC0Hy7ULTQCk4LJeDEy" +
       "9ZF1qTMkyaZAntrVllY61Y\nQskWYE6TZgyC+n4Hk4BfEmt7oxDwdAYHrjZn" +
       "bNtcQFC+pKTNpGv1Wpv1vYOjqpFgwsxlc1WYH7ft\nYu8L84DfHMgS2I6zZX" +
       "ZW0EWPLk6CrtIFVHWVEqizyZYdklpkuzDeH3GPLFeLubCamtvlbHBq/bjA\n" +
       "/AzvMZzZrGFZcGYw7WjjEgqk8LhaRgG9LJCQ80JGkSlrWhiBUeEJRoCAA0JD" +
       "TtOIXlTOtBifDuoZ\niboTAs1ZCs5OXCdk0H4+OwnjGWBoMOCHewjXqkaAfT" +
       "PL5tFC7gx4GS6M7V6pNH8etkxk9/bOJOwt\n6vW7Ldse2ny1SpZYvYgERTE0" +
       "yZuOo3latdFKI/Si2jWmsD91NLzrIBKkhTRLZ9NMpHPcIABpU2n7\nbrfyKH" +
       "o9QWekxHO7BLScGmADInG7GSuNxVRYyD2QtjrrTgJIXkcsOLWm+RojpommGD" +
       "OzTdJ5p/lM\nYsfwjMKSBXCINLqL1/osRktqNm3WvVQmmKqM2bavI2Lpt2q9" +
       "VK3aA4DAB5EpSutn+szCFNsM/qFq\n3UnYH+h0rpIFjniIB4ViyYfhEjoW4o" +
       "46kvtFuenGx7PWnpbrUu6atWMKdACqsyArBHmxU3A8LVus\nKpPmBCv4alKL" +
       "K3G2wjYWCRzjs2k6irGkz5WH7/qijj1tTLlENUsoYiIUZjycxBViUCkSVpxC" +
       "eMVC\n4lKb3gUWG3mBzu3WwtmN9hCngdMEqUCvLUMxP06HUAY9mUjGDjA17d" +
       "JOabhCjRxc8DETWMt65ae5\ni5hmHlUkiWKSl++S1pqtM+6kOjxDw0zvV6UQ" +
       "YBAv56V37Byd345dOZENb7e3tDDCi3VAKVZh7MBu\nzpoCZXeJ1WaOCxTrwU" +
       "qL7UwoTvNGEYK4cJGYyOvWswpoUW3SdCaF7Rg9+B0bgIm0cKUNN+jBBhq9\n" +
       "w3Y4XoHQwoAMw00ydmKpS8012bOQi4HvKYcVBvJKmPfAWloetJWsnrGmHR8N" +
       "80TMhZk3PQGOSzdB\nYKykTQZRUeX57nKCDGaq2wVOkDCH+PE5RM6rhWTvl0" +
       "mxnodlXMjKXM6j5uzr/Bg4n7Y0AIDeyueD\nIALCHAhwVu7gLbnifHWfcDm5" +
       "6xjWNPehRm+UeXDC14CM8jlct6JSLndEuiORCb7N1HEJsxTGz3Q7\nzkMk98" +
       "AzuJ9aJubkoBIZJ6DCeVMzUVKDO52delxhSInW4rqWQPrKwLiop5doVay6wp" +
       "btMTbdKChg\n9fWZyRIHVhNioh5yiYHZRvVLeD+D7LkLzhluj5f1fg+6ZdLn" +
       "zRYKAImyXErwECpNV4zM1IU1hjQH\nQSC4bQ/YPiYouuoYpliKq3LZDplVEe" +
       "RzkKGzxhHzedOLq2yCzNIC06zNQqpjUNhj2JSAIU3moRwc\n73qQBJy9Z4bZ" +
       "SerXR34JHlkiFqfZPoZMAuGgqEWPyHpV8ps55ByMNQ2e4dDGsiQj8SYJis7O" +
       "6phd\nnSxmnHa7osbwTU0VuAdF8RFzT4fV3Az4CbtClEifOoS3pnfn3M9lb7" +
       "08FKnQnNO1qEYMjkR9jwvx\nIqQ1jDoiYxdtkJmvNIe4BYP1uUXjjoIEzLNE" +
       "MJoAnsTDSovHp3mhuGpckFAiaKadbQyAG25lVDYt\nUXNRU+dmRgTOmI+U2r" +
       "Da0G0nK91rEAiRN5x/hG04TtGqmxMlwiicM2PhAo365XCYrAKwVMUaVxw4\n" +
       "F7a+CUVhSTf2vITGSdfrvDyVOwQl67PYBzWs05NSqxnG3TbDPjCbq9OVyAJQ" +
       "yQST/V7w+yotPVwV\nzSnKLGCR0yZDEgIErQXGwCqQuelwWIBE1dvApQLtDx" +
       "JbT2cM6E9pAZp7tV8ljVxuZ+2JEAMZLkEC\ndevagulVsIMNeTqHOsMVen8y" +
       "Jr31YiF1+63VA1OJna4gNEVN3qrUzJg6kuVqeWBn2+HWocrSdrua\n4sORf7" +
       "mDiySlc3O9Cwqcq7b8mo9W1RjWIE3SshA0JokHKfSy89a85S1FXEVKeBvVyy" +
       "PXnLztCWjt\nFIM5A2XLPaxseiEdUpa6Zv2sDAw40cypPe6wPWVUHJtS6GnB" +
       "sad4MUNMcbNa2DXpzyx51klpgG+n\nc44tD07hIVIsRx64Jx1RaqZVkSayJJ" +
       "UpVrjFYWwctw7OzVueQiGOkxRu7eH1XF9onQ74Do7NKQzZ\nAP56Zy7ABt8e" +
       "lSp1HYDfBHrcz8k5qq9YuCJTaTk75GOv79iGAOJpbs+SICPoOiInrrHvF858" +
       "cxzu\nG9uQSW0l8lFyv6aEmTq1ghLgCYhNFsd82NNAsXHPi1ZZc+R4UzgqkW" +
       "gHAh/SPlvSwYyfrwRVkPoN\nl+Q+xC3QyliFJX9sHGKbFWcTO+/2roiRHWv2" +
       "jTgBGlVAON8V+GTM79m0wRAWKLiTg9QrYItAstdq\nLBkaC6WDJpEKRRaPik" +
       "VWrY+NCutaaZHV3OoA79RN5Xw42C0LJd14ITJGux27wcAtKBo1brJIjfsx\n" +
       "v9qvCRH3jkHMqlQe80Qc5tOegKPhdIw38oIxihgAjwznwG53IFooqiYzuhmz" +
       "8jkPJ0tVXA2ZiNnD\n0Yz0E3RWI7q2LhjJAjeknyOKHTlLu+VXYIFRixYH+v" +
       "A4HMKWjcqnAufPpgKf993YYXrIrTMUYk/c\nDrZF0XbO9JbdZvPh+rxc1ad8" +
       "2rhzxxYhTkTrdhVyS8gX2uG+VpIHYQjKNVZA/g5n0iwZN+pZLAVs\ng3HnmD" +
       "FUqAskeB6u1qIS0NA2t9G+zMSQ3/tDQo+4mV9apQObcco057xkTRCU+/W+yu" +
       "U1POPGwSIT\nUoM7RHJJMVQj9TN2u0nIZoho2Y6xiRAHs53YHjjLQebnltzX" +
       "CYz4oNUve6aVtzakW6bHSgdYnvBj\nT7O0xaaen1wddSzUAs6OKh7xdLFktm" +
       "U86R2moU/GfsKGNCl7MwJzgtiH6cQ3cheKh/to3hwmOA1M\n3Tocl0cmaAm4" +
       "EdAw42ZMeG7Oq2A+jzh5X5BYJfSLHurXCo74MmsU01gijYXDFoPYJeOSnA9v" +
       "ynN5\n0lLnAPfDkaps+NmaOk6sBs3WFW0ch3sC6fMgWWP1DoI4EtGO1ZA26r" +
       "A5lj7ST+qd00pz2N5F2JTc\nmJGqojpKnvfmGFZ2TZYNW81OtT191xCW7vFr" +
       "wIZZy88VRc5j9sAOC0mjNFDTM3XdAqKgrAQKjiaZ\nyYicgeGYNuPPEHIcn2" +
       "SC0jqLkRaT/ujK4oT11jq9Z/G9lPhKvOyrQ8JMvaowzrODS8Hmol/Cqx7a\n" +
       "9baxZbR1nR55Q9tuGXMijb1mmZuY4PpRgsDzpCaFoBOHfdUvF/DeHo506ilE" +
       "tX1WLMLKqhGOhXG0\nr/Ay5BktRJGw9wHk6JQkJi3X40OhbBSBppEwgqvdvC" +
       "Bl/VDTHCu1QQFiOdEVAdAQZWitEWqxgYE1\naeCkhVlcAp1Eq2Ra/dxD53yj" +
       "To/W2IyxcOnQEWbADHXS1fUSNkMALLh5hjbooi7Ug47EFYfo8oSG\n504bzA" +
       "hDdytq581dYJ7NN+VhlXs2AqTLcV5BJYm3QCHgPSmHqbPD8JZ04RLGFxxtpp" +
       "7T2ZWFBcSQ\nO1mcxa3jVtAQqNfSAyZ2mch7blJnZo9jaDHmpksKEXeL7XBF" +
       "dpPt4Ftlh/ehdbL5fNXYKBRqSL5P\nnEgDeCDBhltmLWWhbCsrKqW1MGtIUs" +
       "eSvQ4fwfW4jJfTg5jLNTWXC4BRsgnT1wskZeOswmc43K5w\n/1gOpzqUOcok" +
       "oU15oV3SiiDuzXArFZQroamIOBagFptxLqfikdzq9AITGSicTAWQdzIv7+an" +
       "SRKB\nTO3NrXmZrckT1q4zfonPaQCdn4JNspdW9C7sYKgUOQHSD60x3kQBT3" +
       "BEoR/l6Tnk9gJXoqng4BUg\nacTg4SARYmFUJZMW4fIkCCNVCTZqZaTnYI1z" +
       "Mx7louPeZ9R9tC/HDrTbztumJBbqxMozGxYQxHSS\nVnJyz4pyYNfGfKfvoK" +
       "U+BQxwH8hSYVliSUsH7eCk255QHG3dzdOBVB2j/byl2928merVivSI9eC5\n" +
       "bRXjArUEaNS1MoAVpjOEBTfbQ+E3iyWAHSZBsUGTAj3wRW2XpAfZgnhW8XoM" +
       "aLGVpbreuG0H5VOT\nNvZ5AM5gECPJQl7ph54MtU1em63rgoW16QEAsqpYJM" +
       "vWCTkZsFmUABHPAlPWGZdU0dVwsRej43A/\nY2FQHK6EnuPKp1DOgh0J7MW4" +
       "CkpQd9cEQDEcVHR5YWw6PEdKwaTnOOzJWJJDvWS746rzDgdRxhUm\nCAo91L" +
       "wKUcOuADwXT7cghCRrUwEmgDmBGsbsGoqifuKKQ/gP30m/cX1j/gi+fwjjGt" +
       "f3uO2zr91v\nUazRYxTr87cd+ehLPwxav75c/s7+v7z2U+avfPPycvky0C1H" +
       "r5Zp9mORW7vRY/jraSbS9UuCW0zo\nr7z0pnNPJD73NP51bxD/lY8c+cAuf+" +
       "nBf/017F+9d/dpMGmcu2WVJ9qHIKW3H2EdF/5ffAh8f+IJ\nrOMRdNFcqtNz" +
       "8b07j3EW8aMRwMEat7j3u49fo9ePtPjYUD7/EC1663lafPtSvfuRMn4vBQZL" +
       "5eVF\ni2unmd0McMrRvToNnKcU+txQvjqUty/leQp99zmwzaW9fwKz+SijFc" +
       "9+rHHFWm8AkW/858+afz/9\nmdfvXuFAyyxu1u7pr1ye/YjlQ9+mXLV99dGc" +
       "kKGQP2RORpZlz9f37g3AdYsyffEJlMm1qzwoO6a1\n3ezyOcYtzTuPafgoco" +
       "9mROXHKnaT8hHpBSGLzSC5jPjjT9n+lYdw350b/PLBNdLmrh1p6XJgzLTl\n" +
       "A/v9i4j779m3OPvxFmf/+o9DCPLj98+VWQTn4YLlvvcQ/rx/WeX7Qw54N0iC" +
       "8r2v3//W/Z/8pnr/\nD3/9CWT+566I5P+Pl71yK+A6sfaJ7z2yRyjkE+DaDW" +
       "Lc/j+mS7XmciUAAA==");
}
