import java.io.PrintStream;
import jif.runtime.Runtime;
import java.io.FileOutputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;

class ExamRoom {
    private IStudent alice;
    private IStudent bob;
    private Exam exm;
    public jif.lang.Principal p;
    
    ExamRoom ExamRoom$(final jif.lang.Principal p) {
        this.jif$init();
        {
            this.p = p;
            this.alice =
              new Student(jif.principals.Alice.getInstance()).Student$("Alice");
            this.bob =
              new Student(jif.principals.Bob.getInstance()).Student$("Bob");
            this.exm = new Exam().Exam$(this.alice, this.bob);
        }
        return this;
    }
    
    public void startExam() {
        Exam exm = this.exm;
        if (exm != null) exm.runExam();
    }
    
    public static ExamRoom room;
    
    final public static void main(final String[] args) throws SecurityException,
        IllegalArgumentException {
        final jif.lang.Principal p = Runtime.user(null);
        {
            Runtime runtime = Runtime.getRuntime(p);
            if (runtime == null) return;
            PrintStream output =
              runtime.stdout(
                jif.lang.LabelUtil.toLabel(
                  jif.lang.LabelUtil.readerPolicy(
                    jif.lang.PrincipalUtil.bottomPrincipal(),
                    jif.lang.PrincipalUtil.bottomPrincipal()),
                  jif.lang.LabelUtil.writerPolicy(
                    jif.lang.PrincipalUtil.bottomPrincipal(),
                    jif.lang.PrincipalUtil.bottomPrincipal())));
            if (output == null) return;
            output.println("Starting exam");
            ExamRoom rm = new ExamRoom().ExamRoom$(p);
            rm.startExam();
            output.println("exam finished");
            IStudent a = rm.alice;
            IStudent b = rm.bob;
            if (a == null) return;
            if (b == null) return;
            a.tellResult(output);
            b.tellResult(output);
            try {
                FileOutputStream out =
                  runtime.openFileWrite(
                    "gradebook.txt",
                    true,
                    jif.lang.LabelUtil.toLabel(
                      jif.lang.LabelUtil.readerPolicy(
                        jif.lang.PrincipalUtil.bottomPrincipal(),
                        jif.lang.PrincipalUtil.bottomPrincipal()),
                      jif.lang.LabelUtil.writerPolicy(
                        jif.lang.PrincipalUtil.bottomPrincipal(),
                        jif.lang.PrincipalUtil.bottomPrincipal())));
                if (out != null) {
                    output.println("Appending Alice\'s Score to gradebook.txt");
                    a.writeResult(out);
                    output.println("Appending Bob\'s Score to gradebook.txt");
                    b.writeResult(out);
                }
                out.close();
            }
            catch (final Exception e) {  }
            output.println("Printing current gradebook:");
            PrintStream outputP =
              runtime.stdout(
                jif.lang.LabelUtil.toLabel(
                  jif.lang.LabelUtil.readerPolicy(
                    p, jif.lang.PrincipalUtil.topPrincipal()),
                  jif.lang.LabelUtil.writerPolicy(
                    jif.lang.PrincipalUtil.bottomPrincipal(),
                    jif.lang.PrincipalUtil.bottomPrincipal())));
            if (outputP == null) return;
            try {
                BufferedReader in =
                  new BufferedReader(
                  new InputStreamReader(
                    runtime.openFileRead(
                      "gradebook.txt",
                      jif.lang.LabelUtil.toLabel(
                        jif.lang.LabelUtil.readerPolicy(
                          p, jif.lang.PrincipalUtil.topPrincipal()),
                        jif.lang.LabelUtil.writerPolicy(
                          jif.lang.PrincipalUtil.bottomPrincipal(),
                          jif.lang.PrincipalUtil.bottomPrincipal())))));
                if (in == null) return;
                Gradebook gA =
                  new Gradebook(p,
                                jif.principals.Alice.getInstance()).Gradebook$(
                    in);
                int[] resA =
                  gA.readResult(jif.principals.Alice.getInstance(), "Alice");
                outputP.println("Alice has taken " + resA[0] + " exam(s):");
                for (int i = 1; i <= resA[0]; ++i)
                    outputP.println("Exam " + i + ": " + resA[i] +
                                    " point(s).");
                in.close();
                in =
                  new BufferedReader(
                  new InputStreamReader(
                    runtime.openFileRead(
                      "gradebook.txt",
                      jif.lang.LabelUtil.toLabel(
                        jif.lang.LabelUtil.readerPolicy(
                          p, jif.lang.PrincipalUtil.topPrincipal()),
                        jif.lang.LabelUtil.writerPolicy(
                          jif.lang.PrincipalUtil.bottomPrincipal(),
                          jif.lang.PrincipalUtil.bottomPrincipal())))));
                if (in == null) return;
                Gradebook gB =
                  new Gradebook(p, jif.principals.Bob.getInstance()).Gradebook$(
                    in);
                int[] resB =
                  gB.readResult(jif.principals.Bob.getInstance(), "Bob");
                outputP.println("Bob has taken " + resB[0] + " exam(s):");
                for (int i = 1; i <= resA[0]; ++i)
                    outputP.println("Exam " + i + ": " + resB[i] +
                                    " point(s).");
                in.close();
            }
            catch (final Exception e) {  }
        }
    }
    
    final public static String jlc$CompilerVersion$jif = "3.0.0";
    final public static long jlc$SourceLastModified$jif = 1227640386000L;
    final public static String jlc$ClassType$jif =
      ("H4sIAAAAAAAAAM0aC3QU1fXt5kdCIAnkZ0jCgkFAJAmIikStIQkSWSAkwU9E" +
       "19nZSTIwOzPOzCYb\n1Ipf0B5KrWK1rR8sFfwX7VHrryr+KtVWPSrqwX+tp3" +
       "6q1u+pPe29781/Z0Ps8dhyzjwmb+677/7v\nffftLR+SPF0jdWvF/kZjRBX0" +
       "xuPF/i5O04VElyKN9MJUjH/uomu2PbbwvSfCJCdKCrmUMahoojFi\nkNLoWm" +
       "6Ia0oZotQUFXWjJUpKRVk3ONkQOUNILNGUpEGmRVVANSApRpOQNppUTuOSTX" +
       "Szpq42idN1\nWJZPZ/UzyA9JKK2RiLXCJIpRRIEZSfOub67cteaushxS0kdK" +
       "RLnH4AyRb1NkA7boI8VJIRkXNL01\nkRASfaRMFoREj6CJnCSuB0BF7iOTdH" +
       "FA5oyUJujdgq5IQwg4SU+pgkb3tCajpJhXgCctxRuKxigE\nevtFQUpYf+X1" +
       "S9yAbpBKh1PG3xKcB/aKRCBM6+d4wVqSu06UEwaZ6l9h89iwDABgaUFSAHnb" +
       "W+XK\nHEyQSUzyEicPNPUYmigPAGiekoJdDFKTFSkAjVM5fh03IMQMUu2H62" +
       "KfAKqQCgKXGKTCD0YxgZZq\nfFpy6WdlfvG/Lun6MhKmNCcEXkL6C2BRvW9R" +
       "t9AvaILMC2zhV6nGyztPTtWGCQHgCh8wg2mdcffq\n6Hu/n8pgpgTArIyvFX" +
       "gjxn9zeG3dc63vFOYgGeNURRdR+R7OqfF2mV9a0ip4Q6WNET82Wh8f6n78\n" +
       "5A03Ce+HSX4nyecVKZWUO0mhICfazPcCeI+KstBJciX4DzjvFyUBOc+Hd5Uz" +
       "Bul7WiXs30R4CvAx\nSHFHmkt2K0qyEVwRoSalcSwZDoWAolq/P0hgSksVKS" +
       "FoMX7H20+d1bHs4k1h2z7MXQwyzsJKQiGK\nqMrLGsoqgZ77wR0tpT+eq98F" +
       "Lt5HCsVkMmVwcQk4KOYkSRkWEjGD2kKZy+4s3y2Og9mABcYkQMQ8\nWCVDGp" +
       "nuNw/HjTppkOCFMw9fQbbWd/wcNYmSL0fsjDSQ4zpGW/HsnlOPP33T9BwEGs" +
       "4FeSEn0z0h\nKwB3jB95uGLRvQ99fV+Y5PVBYNLbhX4uJRldbYuVlAzeXm5P" +
       "dQsQCOQoFxekKBnP/J0Dn7W8rkDl\n6RqDVEVhX9MPJIRvoqtADOM1Bwkuqw" +
       "fbbNi/CGJ81+SKFb/+YsrNzJz9UuvSFF5IQJhyFsSaD522\n4rr5XwNf4KlA" +
       "rQG0ouPX+z3V41wtpicaZHqG4/s3abGCGnKSC8z1K1qSkxCNJZMiY1BThp0Z" +
       "aq8T\n6Hsp6Aj1NMW08YnUoF1WjcOBqG8fszRe/qNz49J398w6NewOrSWuVN" +
       "MjGMxRyxxz6dUEAeb3Xdl1\n2dYPN55CbYUZC0lTmipDYJKTA2JFY3X55VfM" +
       "/uVLlg1OdpC2aho3giaYPve5uque4K6GOAK+rYvr\nBerDIdsaqxxrpAYgJF" +
       "ioenb8oZsih/WXh0kYVEUNBnIZ9ZJ6iEi4wvq7kIqm2BbgBHiqAwQIu9U4\n" +
       "u1GUQOgA3TbGX3xyzR3XPVLxYRi1FuZFg9RlZAMl4dazEzFApykVwj41dZPE" +
       "8BCgqPWjOIGz7RcT\nQZWfHpOYySuKv/nnlOfbKffjE4LOa6KKodTcLt9Qjg" +
       "dhYxqkXqVxsi5B4cB8qpd+7EirWovPtlA0\nNQGiMcgyJDSpaOqgyEcoLRGl" +
       "P8KMN8JpA6mkIBsRFSddWT0yK44sC4kIF1eGhEh8JHLm2bNB0DMo\nYxZZjW" +
       "2cLCuGj7gY/7eVHz20XhWeZA481bsmA3rabXUfN9xy2gxqb9QRDBJCw5vil2" +
       "IXJ2qmJB8q\nP3/rxd+UHEclWQSk90N5JvIjqBt/QGqzv2JUwspjwAKuywDu" +
       "dD4zKR+mUi840MuFTYqbk8M2vPfZ\nnS/cNRM5waUtsK7ez0S3wEGWYjvAko" +
       "a3b/zkwnE3UD7ylGEatqa6qFKhluFFlYOcbL1heahRLLhJ\nB4i4OkNSJvqW" +
       "61KcUvc1b1E0QU3bWqTgNvrGxYphKEl7kxg//8nmqtady3e5tehb44KeV1Fd" +
       "HflU\nKKJByrbjA312bC/IsGVK2GyvkH0kuUU9r/j6B/9y043XMeL8ygla8a" +
       "ubv9y+fuYNAyys4Z5LVRYJ\no0FqOhEqekdNFxy86dXPfntorUtNVPbA6jAF" +
       "ZJrAcYmJ1cHu36vWk6mjCs9JTi4rP3vxETv2CbtY\nsJfcydNfKfpWPn7FwI" +
       "Jrb789j4nEXyG5IlSMX/jiUFn+b65NhkkBFALU8eGIcgInpTBn9EF5rreZ\n" +
       "k1EywfPdW2qzurLFVdIu8CVKdzTNRVKc0D4Bh4XpEKFefwpdMYOOs8yyxgBc" +
       "osxJFPxo+qkJh3l0\n4gg9Uyag+iQUp0Nm9Xxp/fZ373y7uzzsOmIcmJnsXW" +
       "vYMYOlHmqT00bbgUI/OmfaLT/sfi3OBD/J\nW1F2yKnkX0d2CzOP2vxmQEFa" +
       "aDsT5QiHuJWfcTyEvs/FtG0mbyhbnfTtWFKrrkPogFRyVNWmt/5U\n90yvY+" +
       "dzPZnZlStb4eTaZtd2MV6+LzmS8/gBjZTOIpuywHJmOjytQdnYJq5u1Ihx1S" +
       "mXqnJzq+gl\nM4eSmQNkzgxa3ZEGVwN7cMUdbsFNZfef/czLftni2EkVOMcb" +
       "HDJwuIPE1VXKGxt2FKy04uVysMBW\nCAGspDNMJx4ySM5iJe6fo4cLLDzTbO" +
       "oYHBpM7hbTsZ1Nect1h79eRXWxtvTNR16/8GfVeyxiOu3F\nB3lZci9zc7P3" +
       "3JrX5hyy5UmbG0rDeSYa/O8COq5yzSx1vUezzByjepnaT8SjW5h/nae6N7b/" +
       "Ms0G\nT0n+wLUEGwtW6ErGz/x89zVFEcdqplCLycsIq55lMT68842Ns6tLwE" +
       "zCfWTiIKd3yuDE2P4QtP3F\nWR+q9Q+uvuarp43XqMU5pw1cPY2K+WTbSYpN" +
       "RxmHj8tJzJB3bWDIKwB7gNwpQPWWx9m212QjxX+T\nXQflzh4jlYAqzjoo76" +
       "BEtGZ0sXpScd1wtSTKjzrjyNXiylUsbM22mYaNG2n3yVzqX3fF7PeH5jSf\n" +
       "dzXNhblxTqceVwBS1BHSIJHs/S2Ki0XXIhxuoK83U94mgwdZvNCjbwbxMf6+" +
       "fZ9e9tEJ68+isi+h\n+9EqrIftfJCrcHIWNfR44Vo8DbVAdmP8jDdK//7FOW" +
       "/NoZ0SizP3oWs5p2YcupZy+iDM5xW88vDu\nytOfzSHhJaRIUrjEEo4ecUkh" +
       "nBEFfVCREmn1B8dSVRYPo3WUmtH5AIfrLiTKMbsnCgbGLdp++Gc5\n9OTkOu" +
       "RWe5l297bMjFfvgvBgdSU7x2jL4Zlq2Rc1KGZVhBntPZlGm4PvpxkkX03FwW" +
       "DhRaftR7Dg\nUA9NaTjcQmHDaX/YZAE2jXGtIUjnfvUtKfx3y/Pj9y03K81B" +
       "UW9oxlZjkOpb2IniDhxKCPMLHK/2\nuGg9PIX4ZLroYzhsg3gfN+N9k2O2DN" +
       "VOZ+IPlE06exsd78zUsSNCXzYxk8YjODw1Or0V8BThk0nv\nny16hXQyIG7g" +
       "qhALMzRbWTHjBRdD4Ie5+C07DWWmhSAtxZk07M20kDC1EBzuT9PTnZc0RFgb" +
       "gJBu\nbhtQMDGT4ImY59+aTGJez0LM/Tg8AMTkaoqSdFRb5mxa4tqUzs40sx" +
       "SOh7iyD0HbrcvW/KVOtvGk\nT4ov4h491UrF4JWFhqLOlYQhQXKSnx/Jctrr" +
       "ttx1W/6kRG50YbU/+4UzYr13XYzf83LJxx0L9rz7\n3XX+aLIMbvJNHZWJGG" +
       "/cHfv0pcNfnsUSiLvbwpD1ek4JEVvT4+E5wDT/Cp+VUF19HJBPmc2NWlGP\n" +
       "+hH0BHRrBnoE/Xi66bYQ5nKHFDFBQq716zIKbvw7abPQAM8RASy4UGiBKILL" +
       "TNtUN9OPH9n7YJ9s\nmulUtQGiCuVli+Iu3wiUS9i0OK8DI19NAftRgPkesH" +
       "kBYN+qT8XufyJJsMosfSpEuohJBHnNd7GN\nQ8H+GUOwYpN6fJ+IKEIURel/" +
       "iziztF0tr5OVYZmVVfNffPqPz7enb7MiBJw+EWfNqGqgEAwMzBFF\nQv8gJN" +
       "AmiROtMvodJi1me+3tXQueka/c9DuLmMMYu6oj2lDEM4VB3YnOJzKZsRAcOg" +
       "in1jhhfzTh\n4lCGw0zLttlyTACh2fTNZ3qHwnPk/k0PwY4JNL1VYzI9eNHH" +
       "YH0HL4pYBogUV4JWcKV9HgzNzTgP\nwpR9LrPeL8gys8o1s9T1Hs0ycyKbMR" +
       "VxtKkIhySqizkuXcylumjEocnWBSV8HsWgZ95y0ksBZsNr\nPqriHlA2l9Jm" +
       "u300KPRfD2fe/noudanFjXdRZlLp2BeUKKW06sYmVCO771VVyuOx1Dhbs6zG" +
       "13aA\n/DaxrcBdIRqkokfgU3jd35HmBdq8xyLKgOJAHJira3yT6yI6CNLsDd" +
       "joF8PTH2CYlpnAWcXvq8cr\nouw0tWP8uGhzzcPRszaanb8gcAu0fubgxEWr" +
       "luu0eJ64liJKqoosmBn+INbDRDmtZK1i+3DTpkiS\nwCMbesNqOakkxH4R70" +
       "R7BGND3U+f3fKLDasZAYfsf40zf8BismHPaV/WU4JCPC3k7TOWA8aOWlX+\n" +
       "61A8cMH+e6WX+rbuO7ie7e87kMH3e9sv3HrFPXcvYDemWGWWmpV5DnND1emq" +
       "+Foy7SNQoIi8qy3z\n+fbm7t1bdp3DOk54iR106dDKg3XrXfCVna86bYW3wd" +
       "MeFLA0crC3r+Pf293beWV3WfNx9QOXOL0d\nT4/evAaziaC94pr+zQXNr94z" +
       "nV1qy1B6aitSEtR5YUkMuCz19Jc9F2PpgATi7NWtKMaF8+s37JXa\nh5hGMu" +
       "/nbOD66slvVrYW3hr2/CIBd5lIz26hGKFJwE4f3g5Suy3WpfD0ZssDY+3c+X" +
       "CeCI8wBpzB\nPUKnUHNi90pX7F6ZEbs9MxDkpriCnD+WBESpGU6Uqu0Ezxng" +
       "pFYzf/mCVWNmsBptgdPPBBJd+Svk\n4inUS8eTsrgXfltD9cneT6dj3KdhfM" +
       "HfhITW4qDRZLTeksZ0RxrZiKUL6hD+6yw1kKsac4yyjQN8\nmrsVPlx58Qev" +
       "LWq6diytcGyBV5lJot5vJaMU9aE1Ngo8D1RmQeEW1VWOqNK+owWejBaOlQqr" +
       "zz4m\nO95Pr9tJy/8rAzFIWPXXi2Msb7DHCsUQrrYqnDO+m/oBQZd9T47D2M" +
       "8UDA7nOOSc939AzpaxuygC\nXobD1jG4EvWO7P4CJJkOgxPXjOoVCLENh+04" +
       "7PheLTyb6NKu366pakARzG5irXuUQL6+C2/3/rQH\nO00p9pvVGP+Betpxr3" +
       "a/fpN5JZ+1we6sOOnWUyLpH/X+hN2q8xK3Hk0ErxIK2PHLDLfuS1g/NguX\n" +
       "+MaL/Zec/06J/UsHHFgzr8QUypD7aicDD76fMKFl77J7793pb7BZPSJEUZWl" +
       "Q79g1ucFXz396bHe\nC03ryP0fBeScilgsAAA=");
    
    public ExamRoom() { super(); }
    
    private void jif$init() {  }
    
    final public static String jlc$CompilerVersion$jl = "2.0.0";
    final public static long jlc$SourceLastModified$jl = 1227640386000L;
    final public static String jlc$ClassType$jl =
      ("H4sIAAAAAAAAAKV6a+zkWHZXdU/Pq3Z2d2Z2Z58zu72TiXYHK2O77Ho4C0K2" +
       "yy6X7bJddvlRzq4a\nv8vl96vK9sIKPpDdEIWH2EUBQXgIhAT7gYCUfOIhJQ" +
       "KJh4QiQcQHAihRQIIgAQKCBARX/fvf3dPd\nO/lASdf/+/c995xz73ncY//8" +
       "g98avViVo/t5FndBnNUf1F3uVR9IVll5LhlbVbUbbjxw4L8Cfebn\nv/ELb7" +
       "ww+qQ5+mSYKrVVhw6ZpbXX1ubotcRLbK+scNf1XHP0Rup5ruKVoRWH/UCYpe" +
       "bozSoMUqtu\nSq+SvSqLTxfCN6sm98qrzNub/Og1J0urumycOiurevQ6f7RO" +
       "FtjUYQzyYVV/nR+95Ide7FbF6Nuj\nO/zoRT+2goHwM/ztKsArR5C+3B/Ix+" +
       "GgZulbjnc75V4Upm49+vLTMx6t+D1uIBimvpx49SF7JOpe\nag03Rm/eqBRb" +
       "aQAqdRmmwUD6YtYMUurRF34o04HoldxyIivwHtSjzz1NJ90MDVSvXrflMqUe" +
       "vfU0\n2ZVTW46+8JTNnrCW+NJr/+ePSf/z/t2rzq7nxBf9XxwmfempSbLne6" +
       "WXOt7NxN9uPvjeet+8fXc0\nGojfeor4hgb/0V9U+f/w9798Q/PF59CI9tFz" +
       "6gfO/569/c6v4L/x6gsXNV7Jsyq8uMKHVn61qvRw\n5OttPvjiZx5xvAx+cD" +
       "v4D+R/uP/Df8P7j3dHL61HLzlZ3CTpevSql7rkw/7LQ58PU289uhcPf4aV\n" +
       "+2HsXVZ+b+jnVn249tt8dPP7xNBevrR69BrVWomcZckHx9C/UL3eXq4fP9+5" +
       "M2j09tPREQ+uxGSx\n65UPnL/+6//4D1LcT3337iP/eCilHr1yy3V0586V0W" +
       "c/vLTLXrkXl/5Pf/vrr//xH6t+4e7oBXP0\napgkTW3Z8bCC16w4zs6e+6C+" +
       "+sIbT/jd1dyDr7xmD24zeOCDeGB0ddNhgady9O7T7vE4qNZDzxps\n/q2ZMP" +
       "r+l6g/d7HkZec/feF+o9qwj9GNbq+9r3yT/QPfffeFC9H53rBfl5W897tzf+" +
       "BIn3pL+Gv/\n44t/88ZTnlZIKjPHc4d88HjCAwj5ivCXJv/r7ujFIQiGNFBb" +
       "gyGHmPrS00HwIb/9+kMnr0fvPhNT\nTwv5+m2+uGzVXX70MT8rEyu+sLkN8n" +
       "F9KLPz4ztXV/jYtf+J37n5/d+H7XeGXEBmST74WXl/5Q26\nWrXn5jfOc7l8" +
       "+bKtTy38mpb+2/o7zG/+k6998+6TGeyTT6Q6xatv4uGNx1bZlZ433P/XPyv9" +
       "6e//\n1nd+4mqShzapRy/ljR2HTntV9NN3Bhf41HNi84PPffp7f+b9P/+rtz" +
       "b/1GPueFla3cXk7R/5lXf+\n7D+y/sIQt0MsVWHv3cTMVdLoVsDl+nuufeCJ" +
       "wYejFw98OmzoS9K+tUNif+u//9LPje/f6HGZ8/kr\nh1eqZ5PUhyY+cPq/p/" +
       "7cb/+z+teuW/fYSy483mmfFatZT7jk4l+e3njpb/3F5O7oZXP0+vWgsdJa\n" +
       "s+LmsrHmcFRU5MOb/OjjHxr/cNq/yXGPPe/tpz3vCbFP+9zjLDH0L9SX/stP" +
       "utmwEa8N7d3Lhlza\nNSXd5KU7o/zSmV8J371ef/SRD7ycl+HJupzJoxeHs/" +
       "fhgffGkIrWSt24XnrNEB+/3kU+JOpLQ3v1\n0p4V9fsvF6wevWBn9qX7+34Y" +
       "j7eGNr60Z3kQtzy8NrnV6d4lPT6P1xtD+/JDnq89y2v1nKVf+l8d\nVn0nv+" +
       "X+5pDJP7iYakg0YeqEuRU/T9abQ7s/tC9c2rOyhGdl3b3KGuKtutZAg9B75Z" +
       "DjH4X8QwmX\ny/32zmCUF5EPoA+gy/+7Z7m9MIz7YXqj3FcvF3ng+Nlj7Lx3" +
       "m1i0obAaDsD3hgXdLu71a9ReV3dT\nfzxH8BBIn3hMxmdDkfLTv/En/+mf+J" +
       "F/MwQOO3rxdHHqIV6e4CU0lyruJ3/w/Xc+9r1/+9PX0Bz2\n9p1/8cbP//ML" +
       "129cLtpQ4Vy0U7KmdDzequpN5oZDQeZeFXw2eoftT4YT/PSwxPhTX/qrv/l3" +
       "fl3+\n9N0n6rAfeTZtPzHnpha7hsc4bwcJX/koCVfqXwa+8oNvy79m35w8b3" +
       "742KXSJvn33S95X/29P/Pv\nnnNq34uz5+5n/VbGoNUav/1tIItEtirsG/U0" +
       "csk1nkYmdCSDiMZZPFmHkVKvt5GiK3h0VjEKxlJT\n2a3PYi+JPbm3x/A69y" +
       "FiypU6B5fyoqL9szHXmLLsSoCrNV1SyuJsAHWOzAq4AXLJm2DzBQyakFQt\n" +
       "3EPXH8+JDczmc3B+Gvu+X/MyoEg0dHT1Ew1G5lEmDKhtJBoMpyKEalTccQK2" +
       "YdUjAzZZ0kwk2z6f\nFJ9kSZcjy0TdWIcsO9LhOBL4TE9mawvKzKzeqrShH1" +
       "k152QtQkQh2oqqsOaFlZpTq0TWNFxQ8FzO\nxa2Q5+quEZWdofR5gU5CV4DH" +
       "OmtKJqj2HY6xHDeRQ94g2XUuy2vKVHyxsWdzp/aspjq0ChS5nMyn\nDIp3sg" +
       "0LET63s/VCY9dyZAg8BI8jGVd8S97QmUwdZySbkkpDQAQ9D8Wdy9D4NOtUtj" +
       "m6QTFdb88B\nqqhAHkQ2UpPWMWcPRkA6dSs3XBsG1Ng71fRWzfc+YMAK1uF2" +
       "TnAHWFohLecQoMXJJLGZAS561gql\ngWYqdbbMWYwdFlh4XuJEYKm0gjOprQ" +
       "MGN2aobqsMq6RCRxIkdZ+EgYSvQi/KWHdJcztaifCjtpn6\nBwhZb7YbtZkw" +
       "swnn41yxJQPOWHE7cgnt28A0i7FP591Md2P/tAL5Jp1tDlwikA5lRPyMnBDy" +
       "Scfk\nGsNP1prfkJP+oM3SVdfX0q7WV+SWCcjD4hxMEtfx/WI8YxowXeRBHu" +
       "zwct2daCM4tinWeyvEdWbI\niRb3wcoTVFl2ZUCei4VPTxINs6AwR7czXaB2" +
       "i4l+WPizdL4YT3EIIT2AUQw07TxH40xdFaHksCZ9\nq5cc0lsDXFUTrBMa6L" +
       "I/nuhOJUQHYNyp2hNNPNdDo0IgGSVPeDtWGJpJonrCQUVHaWc5U6zYUc7m\n" +
       "MtPxLC5ACToESlRpnEJnG2POTCDAhW2mQiP4MOnnG2N77vqK5bbhihsXm5Jf" +
       "VVkRmPP5WYbqfAd4\nBbag+XrKkJUWbRLt7GwjlBP3kSJHOnVcLScRZ3YAWi" +
       "HdRAywBCecfbTdbBdjndSWqzxthDPIHHd5\nHokkvTlj/ta2dRc8O8I+UXjI" +
       "r45LZYv2+UoHmSqNRUlCkB1GnKlVhdKeQqVQDx3G3JlAjgQ2bVa8\nfNpimK" +
       "8B+6mkEXuBtw8G2rBy7Nr7Rovx3jOSqeRuqy0pbjO69SKOSCWQhZbpXF+U0T" +
       "Iez+RiqVHa\nwcA20hAXp6yo8aW4gYlz1BRn37aFECRX7AIGFI62QWBflULP" +
       "9pjanBSaHqKCPXR0pVjL6WQyRsty\napwFH+VivNyuoKyRDKBHNBQ+13noWC" +
       "ZTrFCwQix7Ra5STiEXPczBhRK1pMCam3APE7tDDplWsdgN\nflblM/wICxsd" +
       "WuxTNaNh/eiIRLFa+FUve2Ah9CjGItjiPBO8s1gqeqMJm+Nq08pd2/YzV6Vw" +
       "z0YM\nN4bHE3cvCdMpae9Vk4TiXRLmyz3L7fAJS+8RYzrV/A3YaHwcwKKbk5" +
       "MhdSFBaO2lkzdtisZDudlK\nxDmg3J/KMeGVy7VbWUXbljm+D1g6zLzUXmRm" +
       "FR5A3ThA0V6jVIFI1yZmsrOQCtHzqZhH6yKZEHZA\nMGGBn7frBlPRcQOv1K" +
       "0Y4MjOXhlI2/UyYkga3+7lEKYbkw4wOTbxTYy6Vk/1NJ53kXY+orBrStSC\n" +
       "IINC0o/ietXPZWc33pq6z+TivlMa7gSmgwv5Nuf7RwrlRWvGcZm7c/ga2x4D" +
       "97Bvi8gotLYKpwTq\nEIsid4E5FZZ6dpLqGIfGwnYVbpygY5dKbolF0FFOxs" +
       "urWFpwG2HB5vgsidZEJdOK6+o7qONQtCLR\naE3D3upAHRYswycTWyCg5SYb" +
       "71vTPOoThyeb1XEe7MG5pzH9BDIOumfi6AK2qwRHSss2VF/A2m4S\ntIWNbe" +
       "UlwZLn6SmMJ2uDnRQJOyg6lhCwbF1AZSgn1rdKhEHClD2tjwVRg9tV0Z8mrH" +
       "qu8uMZ55ru\nvGzcJdpzMpCo4QKFNg292xd2tNhMTpJvjlMFdAR5Mz1bal1x" +
       "c6+HFGSIOH1/POFRZiE22EfnlELU\n5byLV5RVF9asoLlD3NB0vBcdm4cPnn" +
       "WQef7Ajgk0RMVIUNhToc9gzlFPDmzDFLRVEVsvdoFwKlft\nPj9wVDyP2gAE" +
       "F2lS1JbbId609g42inKeBtMu48fqmONYoivtI47AE5sE19VK4yar7hQxUNSo" +
       "KlaC\nxxkBYh2EIsbG4xdDTWItrMY+YR3gN3sB77oKNae8Ju/ZcQbRhXigCi" +
       "9yBbrtFjPXkPx0eL5Wa0GT\nbHx2xGmTLXFnn7CwwzTI7KRHs+RIVhi7C9FS" +
       "Qk4ttTtNSLvejyvWdzpX8Dk/16V0Tp/XbGnPF9gR\nTSmjW03XsbIxwGOo0i" +
       "lgz6bCIYoIGufVhbdaO8E6zXdEilH0tCw9cxzBVHf2JVefFH1T8rTmrpsF\n" +
       "qXFuvxNkjXOgJUocUCOnONrzz7m72Ytitei6NiCcrGpZWmozoIjYAxJDYzQI" +
       "MLWzAiAcjmJISDCj\nzUHfROZIN2/6vhKTtZOwaWXop/3AKGaSYgdBth2oa1" +
       "BMfIvfgZUfIiKxBNmxDtOTjksjA3InZC9K\nk1ObbCnaspbVbroNmYbVfWfX" +
       "UacKpOsVlNjdwU794dSkubKMpCyg5U4T9KQGp+oYg7rTHnB7yUzN\nWKlt1N" +
       "tZZu1ONtoM4PtEWYABcTR34joffJZhE/HY1Vs33bPFtIHXhxZWEqNI2b4Agn" +
       "i8QT0l2QpR\nH7QWYlIr7SzMnY3q2hUtmL7ng07P+3UaTqhIEzeOzSzZc7OW" +
       "KFgzuFVbT2hu8JpG66oNoY9JfFXl\nS2HDtminbKYh6838DHV4ftnvbDHbM0" +
       "S+mR/sXWXCwvCQCh/mmCcbelufBgPBM3Cx8jWva0OxQegx\ngcSmE2K9Mx8O" +
       "L7Y0poeum6qJvYLKpafsLVBckGIx7XqlhU+q1/dEd/Ty1NotlKM+PYCp5c2E" +
       "uQ1u\nKmg13kEpcOZVanWu9RlVrnqwXWC9RlOOW+QxyXdOtS6m03izmy0W6E" +
       "SoZjV/pnrS13fhmnORrllS\nEwnd1tKgmS4DBbYFmlNjlfkQMsVGneZn2JH2" +
       "Ew7Qd7ayzwW5TZjjomZ7lhgCdrkeztp5IJzzraTr\nLZZM4Mn22BrAbmxs/b" +
       "g/oMd4jxf9McvmM4KqVyZUGbniuMN5p+y4Y18eO8EIu1it7M1kkuwtYTVJ\n" +
       "kU7rCwPx6bnkMdOj4o/d3hAOdtzuCsfTzoQCE4yyZpkKVCZcCBnGYP0m4xaI" +
       "iqFJcHbNk0Ae7bPd\nbvwZ4JuYh9UUO1sAYRUChzGAUUW59mufJUuHWeuCL6" +
       "Ooli2Wtoa7ibQ4Ll0OBOe0qINCZkJK2EtI\nplfTfLJ3mnyoX8LlZtrqi8Vp" +
       "2Yy7WvR7hTmwlrxWyyNFZajnqNEhJSja10iZSlKYWLjKkGKkDNHV\npGam+N" +
       "ov+XDHbewqJQN7xbs5AKyc6RgTd5HYyLo3jYdHD3tzpP1TcCICV1Hn7eTIo2" +
       "ZcTGQH5lam\ndiDSWjLjVYJKp7yNhhBE6LO+PMiWX8vzZTBWcUywdkdnmzBL" +
       "ywD3Jk5NjsaqXqvH1D+pNee3SAdK\nxyE9ItwCJlQdy9rYPEZibk/Wabg8tB" +
       "wpbXiGAyfjZhVg0tpATb7M9v2hCpDAFwABiybiZCloogms\npZiCZl5bufNF" +
       "r1aKQBr9vo0W+6O4PMNiCWmLoXaJoPQ0Tjt4djC23Xo1D4oDzm962dZ3zJGQ" +
       "h3No\n7U0BEpovdT05KHjdmhE030ygaEnCFNE3O0zapaYDyXRgByzRjO1Dvd" +
       "0sVzt0neynGGDtVuxwQvEb\ncBcs8M0usrJCcWnZniathdaF2lcoVLWKeJiH" +
       "3RJi7NI56SCnifVpFY13aHZCDygGqyWNsjp9KHgx\n3m8PW4NT0hZknbos67" +
       "qFdXAWyasptLdVEEDVfl/CiLHv/QXCs20L8VjZz8eIYQAWv97YJ1ZgTJ1d\n" +
       "rUCH8U9Q7gh+WqlKyJ/sc76EvQhlKe20QwFqel7uQDIHNJWGMYYlpMSZCHq8" +
       "ksbAgYEIRi6JNKNA\nI5zN7P12mnIMvaSJbTGHZ/2as0/nuWVLW3yzGB7bOl" +
       "RdhQS35vmdUKsCJkoMls73LFaNkyZW66F4\nIYcaOATWDXIOVQULIZFbLNcw" +
       "JuCDCwVS5FVMNBTNQLFbGI3fsWy1ySpfyakmO7AEkwrufCWMtwsG\nWKnieU" +
       "gOM58F1hy1VmUvBsM+7GsaqsupqO3NRNN8wfelQurnQyk434QEewYo3ReKVR" +
       "FQ+HnTEzQ9\n3p4WASvgSSiL9eaUuWwIJx6A1Ma28SILdLBlwyebzb6ZZcdJ" +
       "vKQ2qEYg+1Rke86sZNwRgzCFj4eD\n3+8OYzQmV2eo5+s67nY4eZj4O8FECu" +
       "acShEYQdJ5j7ICD2v7fo15AsPsGYjh0XxPZIGqDeZ3OA1j\ngl7od4E0Pucy" +
       "xpfSUEUEXbXI4ArbwUwFdU7H2RtZa2suWh86pQj7qDGcLm6SI5U5qU4o2oKp" +
       "9MDE\nph0UVYRZCeVYKsqQifFJjLFJg0AQJ8n+cuJ7YJo1rpXSR8OVzZjPJ4" +
       "SncpwOzap9opHifA5rWteI\nLbw82NWsX8GIhY/BpdWWDuGu5SLKIj9QkaOL" +
       "TJmEcItF2/FcILI4w4alhXS7WbeekQJfLd1jRi+k\nHTMh93Ge4rpjnIqFU4" +
       "6z5gzVurRoVoe+dyS56i1rqNwDB28gv7GDltLLuGkgj52hcchyRZZVCZEC\n" +
       "a8FeysukNjk4BJDlLo9CZXwmN7ZXCYVoRVHLoPIckufESlgiKuAjPscvrcrE" +
       "937lo9AQO0RYJYxk\naaCuoiwpkUg034k6vrBEPTaA8QzGF86GAbyZbgCl3Y" +
       "jz0Jt7i3m0YRAPq04IU9KS4Zz2Sy/RV0P6\nyLXpMhWG+EoKgM66uSJss3W4" +
       "KDqkHwO+ncxr2HZzZClGUzSUYWjmLrkAMUrDJ7XUWgwRpiNnd+PR\nPA45JY" +
       "mUgORPMMT2dA0Z/LbFtqIh8pA7ZA3QO+FWH1okhuYl0G8NocTQPtXgooOJmR" +
       "XWClXL070a\nbRqyhzHWweiJlAf4LpwLes1tLHoBVMicNazxYXpYbRowtcXl" +
       "bFbFJ60c1DiUE5BcE+40XveT2WHF\n0eyZQn0kmCpNh+i5v4TMqlruAcQBDN" +
       "Ij14szkffEWFK5VGWEEINyY07PTMqusE27jPIyJNMloBOU\nkq/UmVo0ENW3" +
       "aZDTQxIDE1LThaQi8jpwJYkgWBdQTtEYDVNVWXi7qgwMP66XmJN6u5l7RDj3" +
       "4G8Y\n/7De6WixlE1+50WVCcltaYacys8OS2DWneGIqywH7brjVliMk7LSpL" +
       "idLrbeideLmRt2tbPqCG0a\ns1k9PbHWRsUsChaC4WCG5WTrUTqs6WIhcEB2" +
       "1r0jYYnxtij7Hk3GIjaVSqxmO3BR4j291iXDCCeb\nyp4vGbJSt2W5L9KlCC" +
       "RgRmxNF9uh8+Vks1CX+DwVRcXBEAzvc6ttuoAcG5m9hI8rlDrp4lxCSZaN\n" +
       "xKCVjKOYaSRPCQcAQufSweN3nT0TuOE5YJZbES73q2lYGo265WcAOQGHJ7At" +
       "MxYhKMfyk7aSAMKr\n87ZELNDPh4cxE4DP3qwSxVRXOz5nQAM4CJMhYDmEiS" +
       "CqbNfcRGL4Je83ChyAQtAYY2Bj8aDpOSA0\nY0G1Yhg66MvFVu3y5dwKneVy" +
       "PvM3HB3P5+x8jiG5PSdMSWEp1dTj7RwL4MahjR7BZjbjjUkIKTsJ\n8glPcc" +
       "I4qHAcv+IMh4fvnN+4vhF/BM8/hGnN63va9tnX6rco1egxSvX524Fy9M4Pg8" +
       "6vL4+/Y/yX\n137S+uVvXl4eXyZ69ejVOst/LPZOXvwY3nqayeb6pcAt5vOX" +
       "X3rTvccvPvc0vnVvEP/lj5z5wKl/\n8cF//dXZv/ra3afBonHp1U2Z7j4EGb" +
       "39CMu48P/iQ2D7E09gGY+gifPlEj0Xv7vzGEfhPxrhG3bj\nFtd+7/Fr8tMj" +
       "LT42tM8/RIPeep4W375c3vtIGb+bAsNOlfVFi+ugld9McOvRvVMWuk8p9Lmh" +
       "fWVo\nb1/a8xT67nNgmUvfeAKT+ahNq579GOOKpd4AHt/4z5+1/m72M6/fvc" +
       "J9tlXd2O7pr1ie/UjlQ9+e\nXLV99dGakKFhP2RNZp7nz9f37g2AdYsiffEJ" +
       "FMlzmjKsO6p1vPzyucUtzbuPadZx7AVWjJdBk3hp\n/Yj0goAlVpheZvzRp/" +
       "b+lYdw3p0bfPLBNdKWnhPvMnZgTLX1A+eDi4j7X3NucfTgFkd//8dhBPnx\n" +
       "+0VjVWHRZLX3tYfw5v2Lle8POeC9MA3rr71//1v3f+Kbyv0/9P4TyPvPXhHH" +
       "/x8ve+VWwHVh7RPf\nc+SPUMYnwLMbRLj9f3Py1aNSJQAA");
}
