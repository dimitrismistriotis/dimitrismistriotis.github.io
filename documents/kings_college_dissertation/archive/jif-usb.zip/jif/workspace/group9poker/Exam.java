class Exam {
    private IStudent alice;
    private IStudent bob;
    
    Exam Exam$(final IStudent a, final IStudent b) {
        this.jif$init();
        {
            this.alice = a;
            this.bob = b;
        }
        return this;
    }
    
    public void runExam() {
        Question[] pool = questionPool();
        if (pool == null) return;
        int nq = pool.length;
        int totalAlice = 0;
        int totalBob = 0;
        int i;
        for (i = 0; i < nq; i++) {
            Question qi = null;
            try {
                qi = pool[i];
                if (qi == null) return;
            }
            catch (final ArrayIndexOutOfBoundsException ex) { return; }
            String qtxt = qi.getText();
            String[] qvars = qi.getVariants();
            {
                String qtxtA = null;
                String[] qvarsA = null;
                IStudent alice = this.alice;
                int answerA = alice == null
                  ? -1
                  : alice.getAnswer(qtxtA, qvarsA);
                if (qi.isCorrect(answerA)) { totalAlice++; }
            }
            {
                String qtxtB = null;
                String[] qvarsB = null;
                IStudent bob = this.bob;
                int answerB = bob == null ? -1 : bob.getAnswer(qtxtB, qvarsB);
                if (qi.isCorrect(answerB)) { totalBob++; }
            }
        }
        {
            IStudent alice = this.alice;
            if (alice != null) { alice.passResult(totalAlice); }
        }
        {
            IStudent bob = this.bob;
            if (bob != null) { bob.passResult(totalBob); }
        }
    }
    
    private int POOLSIZE;
    
    private Question[] questionPool() {
        Question[] pool = new Question[POOLSIZE];
        try {
            String[] options0 = { "Blue Mountain Caf\ufffd", "Mauritz Kaffe" };
            pool[0] =
              new Question(
                jif.lang.LabelUtil.toLabel(
                  jif.lang.LabelUtil.readerPolicy(
                    jif.principals.Examiner.getInstance(),
                    jif.lang.PrincipalUtil.topPrincipal()),
                  jif.lang.LabelUtil.writerPolicy(
                    jif.lang.PrincipalUtil.bottomPrincipal(),
                    jif.lang.PrincipalUtil.bottomPrincipal()))).Question$(
                "What caf\ufffd in G\ufffdteborg offers Kope Luwak coffee?", options0, 0);
            String[] options1 = { "90SEK", "60SEK" };
            pool[1] =
              new Question(
                jif.lang.LabelUtil.toLabel(
                  jif.lang.LabelUtil.readerPolicy(
                    jif.principals.Examiner.getInstance(),
                    jif.lang.PrincipalUtil.topPrincipal()),
                  jif.lang.LabelUtil.writerPolicy(
                    jif.lang.PrincipalUtil.bottomPrincipal(),
                    jif.lang.PrincipalUtil.bottomPrincipal()))).Question$(
                "What\'s the price of a Kope Luwak espresso?", options1, 0);
        }
        catch (final ArrayIndexOutOfBoundsException ex) { return null; }
        catch (final ArrayStoreException ex) { return null; }
        return pool;
    }
    
    final public static String jlc$CompilerVersion$jif = "3.0.0";
    final public static long jlc$SourceLastModified$jif = 1227640386000L;
    final public static String jlc$ClassType$jif =
      ("H4sIAAAAAAAAALUaC3BU1fXu5p8sTQiBRCBhgSAgmoDyk1A1xAQiC1mSQCF+" +
       "1rdvb5Knb/c93rsb\nNlEU/IE61joKlrYKKIoirVU7OpVq8VN1SrWjTv3UAf" +
       "FT69RPFf9Tnfbc8/5vN7FTbWbu3bf3nXPu\nOeee3z2b/R+QAl0jtRdIvQ1s" +
       "UKV6w1lSb1TQdJqIKvJgNyzFxBeuunX3Hxa++3SQ5EVIiZBm/Yom\nsUFGKi" +
       "IXCANCY5pJcmNE0llThFRIKZ0JKSYJjCbaNCXJyOSICqT6ZIU10gxrVAVNSD" +
       "biZo3RFlnQ\ndUArxFV9PbmEBDIaCVsYJlMGRwhssDTnttnj7jvnwdF5pLyH" +
       "lEupLiYwSWxRUgy26CGhJE3GqaY3\nJxI00UNGpyhNdFFNEmRpCACVVA+p1K" +
       "W+lMDSGtU7qa7IAxywUk+rVMM9rcUICYkKyKSlRaZoBofA\nb69E5YT1raBX" +
       "Fvp0RsY5khrytfF1EK9UAsa0XkGkFkr+hVIqwcgkP4YtY/1yAADUoiQFfdtb" +
       "5acE\nWCCVhuZlIdXX2MU0KdUHoAVKGnZhZPywRAGoWBXEC4U+GmOkxg8XNV" +
       "4BVAkqgqMwMtYPhpTglMb7\nTsl1Ph2FoW+uiX4RDiLPCSrKnP8iQKrzIXXS" +
       "XqrRlEgNxC/TDTe1r0tPDBICwGN9wAZM87SHVkfe\n/f0kA2ZCDpiO+AVUZD" +
       "Hx6/kTa19ofrskj7NRrCq6xA/fIzkab9R805RRwRvG2RT5ywbr5cHOp9Zt\n" +
       "2kffC5LCdlIoKnI6mWonJTSVaDGfi+A5IqVoO8mX4QMk75VkyiUvhGdVYP34" +
       "nFGJ8VcKI8AHI8Wt\nGSHZAG7IISozfC7fEAgANxP9viCDGS1T5ATVYuLet/" +
       "54cevyq7cGbdswd2Akn1MkgQASqfaKxHWU\n4B77/v1NFT8+SX8QXLuHlEjJ" +
       "ZJoJcRk4DwmyrGygiRhDGxjtsjfLZ0NxMBewvJgMhAzPVcmARqb4\nzcJxn3" +
       "YMDiK9aP5Ksq2u9Wf8BLnGqzh1gzXQ34UGb6GZXeeedf7WKXkcaEM+1xOATv" +
       "GEqhy0Y+Lg\nY2MXPXzwqwNBUtADAUk/k/YKaZlFW5Yo6RR4eZW91EkhAKQi" +
       "QpzKEVJm+LkAvmp5W5EqIg4j1RHY\n17R/mcM3IhaooUxziHC0OrDJ+m9XQU" +
       "yMjhm78o7PJ9xjmLFfa1FNEWkCwpODEJt9yuSVu07+CuQC\nDwVuGfDKHb7O" +
       "76Eep2oyPZCRKVkO79+kyQpmXJJ8EK5X0ZKCzMlYOill/ZqywVlBWx2FzxVw" +
       "Rvyc\nFsIo5AON2WXRfJrKz9snLMbJT9q3LHvn0Ixzg+6QWu5KMV2UGQ462j" +
       "GXbo1SWD/80+iN2z7Ycjba\nimEsJIM8jQuASY7JESMaaqpu2j7zFy9bNjjG" +
       "IdqsacIgN8HM5hdqdzwt3ALxA3xal4Yo+m4QNwhy\nv3KsEQ2AJowQ9XzZKV" +
       "vD83qrgiQIR4UGAzkMvaQOIhHHsL6XoGpCtgJLYNTlUCDsNt7ZDUkCo324\n" +
       "bUy8et34+3c9PvaDID+1oCgxUpuVBZSE+5ydaAFnmlYh3KOpmywGB4DERD+J" +
       "NYJtvzwBVPv5MZkZ\nszL09b8mvHgmSl+WoLqoSSoPoeZ2hUw5C5TN0x96lS" +
       "akdBkKBsOnuvFla0bVmny2xVUTzqEaRjo4\no0lFU/slMYy8hJXesGG8YUHr" +
       "SydpioUFvujK5uEZcS4yTYSFuDJAw/HB8EWsX9I3zgRlT0PhLNYa\nWoRUSm" +
       "E+BmPiPzo+PDik0mcMJ57kxcmCnvyr2o/q9583DW0OnYGRgACbTfBrshvYsI" +
       "720js2z9ty\nxTeozaDIePpyghEPgu703puW5ZV2HuDzPD6NBiXV24ph/TSs" +
       "q1SEgig8IEBdBDE/PIWLPgWVvQi9\n1cwhPAd5gm5EEQXZCUtVG5cs2HuY3m" +
       "f4reyOg/5k78N8anvf3J333ltgKM+f6FzGFhMXvjQwuvDX\nO5NBUgQxHc8Q" +
       "qsw1gpzm7t8DFZbeYi5GyCjPe2+1ZJQGTa6qZK4v5rkdI5+z4njpKD4tzAQI" +
       "Ht4y\nxJiG8wwzQzGgJaUEGcF/iK8a+TQHFxZk1dpd6bjOXIVT1eL1p66WOl" +
       "YZKplpqwTK2gaskU1UP972\nme8NzJp92S1oJPlxQUeui0A0nUMyEh6+Ckda" +
       "hq+V2r7G/8bAKOKDkVB7F0snwImsGqUT4aMIPwbq\nF+s9ZvMsCWPigcPHbv" +
       "xwzdDFaCXlyBTad5fB3vFekzaR6ru8cE2eu0FOncTEaUcr/vn5pW/OwqLP\n" +
       "Et+dR1YIalYeWSbo/bBeUPTXx54Yd/7zeSTYRkplRUi0CZi1SQmkPar3Q92V" +
       "UU8/A9UT2lAMc4VZ\nmBznSB3lTDm2+3RRX/GiPfM/zcNkYOdtrrnT7ZtAnU" +
       "sBHnzjIoDabrNPpwrGJOt08DiMMyGGZZ6X\nbZl5/Hk5g5tWOi5LIjzoeGeC" +
       "uBDo0rNdNapJSSh7B8y6/Ia6Pe888FZnVdB1eZmaXU64cFx8h1Se\nvSaPtA" +
       "NCPzlr8v5LOo/EDeOv9Nasral08u+DT9Dpi697I0e5W6LCLUiUVAF9usvI0H" +
       "zb6c652CAN\nrRm4KYGbRq2VmCjM3Tf6dxufe9VP24rqPgouzDlja2rCx2gp" +
       "Ytq5baovt9kIWfkNtTPLmzqyGHSn\nkVuqlaOb9hZ1GHqa6sXMiXH7PV/sGZ" +
       "p+Zx8mHohRzWACNMP3rc/lrH6/ayv5d9OLZYdXmBJCnqif\nza+7uXy2ychs" +
       "6zDeOTGi0bbdKTDm5Spw+MfJHrAF3yHZx//7ZG+nPJ6O4/j1NCNp8rnZlRL5" +
       "1ILf\nz+TTkJUKNvGpnU8bnZifQfRBXFjBp1W4cBkaKK6uxrknO544Tiyrhm" +
       "Lg1PKWKPGM8Q0rx8uRPJK0\nal0+n4jPJ3GKZiEMV0CnFHbOu1nX4fYAZdni" +
       "6q1v/rn2uW6jFPZj5ypPooKkmeXJwarLt139dflS\nzDyloPDeqALWNcjLR/" +
       "+dqcV+yy9OvCnSZwHXZgG3O6+bnEKmHiO33+Ytdtw2P2/Tu58+8JcHp3Op\n" +
       "OGYTj3J+QTqpABdpYxdAqX/r7o+vLL4TZSlQNuDtapKLM9v/HXfm3SsNqfBN" +
       "toND1mRpyyTftCst\nKLVfiRZHowyBvLdaJ8R0K6oryix74/HXr7y55pCFnL" +
       "SRj/cqw43m1scrm8cfmXXi9c9YBNbjSe8w\nyfCPn+fS0I80iTkauuKEra99" +
       "+ptTJro0hGKDEjYgoKEEPt9sMzgtl3RLFMaUpEvAk5+ZXd1814r7\nsgWc6R" +
       "XQh+mWcU7otkf/tu/uXV4Zd7tkvB3n61XT0G/EeZvpZLtVN5D3207z2w7VUp" +
       "bnm+mBvAHi\nL2TbeK/QSufJ+EWfPXFradjxtQlGfs4qsz1oMTF419EtM2vK" +
       "IT8Fe8gP+gW9PQXZk3c0qfZtdbeP\n1NCjq2/98ll2BMO5tyCZ7Cs0QmYkzr" +
       "NKCDMKm3HvtzlL4CI4ZUiBUJ+RAoFnGicmrsp8V/2PBOOK\nsn/6X6OsnRvt" +
       "OPsshn7C54O4+pBHPWGz65GfrZ4X+XQAIndcibt14JBycfzy95UXXhme30oY" +
       "U2F0\n8OHmN2CXw/yW1ICxl2qVb+7a88XmLQuDvP9RMMBvU2BdFQ7cyjTvs1" +
       "+1f1tt2U1Hr0Wb5nUXJ3ok\n2zRwfTmfHgHTKI52dES62ntaDc2oLq1QU7h+" +
       "EA6yBMqDsh9EoOmmrznZboKTq2qH60pjibll7ceh\nq4Qnz7UChASVI1PUk2" +
       "Q6QGXHhf1EVmAT3vKg3YWVifzIwhq/DwezrndevJh46NXyj1rnHnrn+2tN\n" +
       "osvn7kJOGlGImMgeih17ef6rM4w7o7sdZBDr9tx9w7YRlcGoNj/LXEaEx8Sn" +
       "z3JEBf4cH7lMGfEl\nRBUtncJ+hM9C8gcUKUECLuzrbOyA3Td29c6a06y/xV" +
       "ZoTEwdSA7mPXVcA4bDUjtD5Wxv8lg4P4fs\nToFVO+JtYcfZN6ip2c2St9Sy" +
       "2PQ5Nv4owCOzUUke5NNefPmJJwK1wYjykeMwAlhkHPguig+tT1Od\n14lRRZ" +
       "F9xTzf/tQc2xtR3gZrGAYsVxLIpYAcmXcnF646Yyd46/n2HCvZv1Vhi9e42p" +
       "7zYbXwiHJd\nBbZO7dZJif9Hvuzf8Dw/zaHCyzx6aRhOL171nfjt6ps8DNh3" +
       "Vd8JLvWdkKU+z8oKmxn+9wNi/3IV\nWmVah9kZCpzKVRFYgPC8M2S9Hzmz4f" +
       "o59iblMMZZmyBVg7TR4Aiclh1hjAYHhhk+YWMj4o8VdpkU\nWOS2fUfTY82E" +
       "/n1reqlL00uzNG2tuLJ4YLGqqsNENZKbdx4GVv0feF/r4n1tFu/WCgYn9IIW" +
       "VbUO\n31UqGI1Xq0zmmMW2QHlmCTwiZ1k1Ws46yPujDE/BaeO/DGLi++p5S1" +
       "/rfH2f2TYZto/oYKz95dnh\nzLXdPzFuO6IsDA3xvYrA9412g+n77uaWn5pF" +
       "Szr6Uu81l79d7rn8GR2GcqfwqBueDn9eM6rpleUP\nP3yXv/KwYjgn4RLf00" +
       "icO+Ozoi+fPXZG7lv+fwANvzBMCiIAAA==");
    
    public Exam() { super(); }
    
    private void jif$init() { POOLSIZE = 2; }
    
    final public static String jlc$CompilerVersion$jl = "2.0.0";
    final public static long jlc$SourceLastModified$jl = 1227640386000L;
    final public static String jlc$ClassType$jl =
      ("H4sIAAAAAAAAAKV5a+zkWFZfdU/3PGp62enZJzCz2zs7iJlYtMsuu2wzWUUu" +
       "l8vlR1W5/CrbsOr4\nWeXy+1llL5DkCwtZkYeyi0gEJCBQpGQ/hESCT3lIoE" +
       "QKRIqQEsQHSCIQiZQQKUFJiJSEuOrf/378\nu1k+UNL1//59zz333Ht+59zj" +
       "c775+4O7ZTF4kKVRu4vS6mHVZl75ULSK0nOpyCpLpX/xyIF+dvTp\nX/j+X7" +
       "z/yuDj5uDjQSJXVhU4VJpU3qkyB/diL7a9oiRd13PNwf3E81zZKwIrCrqeME" +
       "3MwdtlsEus\nqi68UvLKNGrOhG+XdeYVlzWvXwqDe06alFVRO1ValNXgLeFg" +
       "NRZYV0EECkFZfSQMXvUDL3LLfPBD\ng1vC4K4fWbue8NPC9S7AC0dwfn7fkw" +
       "+DXszCtxzvesqdMEjcavD5mzOe7Ph9vifop74We9U+fbLU\nncTqXwzevhIp" +
       "spIdKFdFkOx60rtp3a9SDb7jj2XaE72eWU5o7bxH1eCzN+nEq6Ge6o3LsZyn" +
       "VINP\n3SS7cDoVg++4obNntLV+9d7//cvi/3pw+yKz6znRWf67/aTP3Zgkeb" +
       "5XeInjXU38w/rh11mjfuf2\nYNATf+oG8RUN+V2/pAr/6Z9+/ormO19Cs7YP" +
       "nlM9cv7P5J13f5383TdeOYvxepaWwRkKz+38olXx\n8chHp6zH4qefcDwPPr" +
       "we/GfSPzf+4t/z/vPtwavs4FUnjeo4YQdveIlLPe6/1veFIPHYwZ2o/9Pv\n" +
       "3A8i77zzO30/s6r9pX/KBle/Yd9unVs1eJ0+WfHDQ+CfKd46nZ8fO9661Uvz" +
       "zk3LiHoYLdLI9YpH\nzt/9nX/5AzT/oz9y+wk2Hq9QDe6cOQ5u3bow+czzWz" +
       "qfkXuG8n/5hx+99Ve+p/zF24NXzMEbQRzX\nlWVHveT3rChKj577qLpg4P4z" +
       "eLuoucfIPbuHS4+8R1HP6ALPfmNNMXjvJiyeGhPb96xe11+ZrAbf\n+Bz9t8" +
       "4aPJ/4J8/cr0Trzy+8ku3eh/KXuT//I++9ciY63jmfU0/6/p/M/ZEjfuJTq5" +
       "//n9/5968Q\nclMgsUgdz+39wNMJj0bjL6z+Dvy/bw/u9uDvzb+yegX2tvS5" +
       "m+B/Dq8fPQZ3NXjvBVu6uchH137i\nfFS3hcGbflrEVnRmc23cw2pfpMenby" +
       "4wePPS/7Y/uvr9v8ftj3ofQKVx1uOreMB4vaxW5bnZFXDO\nj8+fj/XGxi/u" +
       "6A/Yry5+71c/+PLtZz3Xx59xcbJXXdnB/adaUQrP69//1k+If+Mbv//V77uo" +
       "5LFO\nqsGrWW1HgXO6CPrJWz0EPvESm3z42U9+/cc//MnfuNb5J55yJ4vCas" +
       "8qP/2lX3/3b/4L66d6e+1t\nqAw678pWLisNrhc4P//MpQ88M/h49IzAmyYz" +
       "Pzvraz3E9lf+xy//9PDBlRznOd9+4fBq+aJzem7i\nI6f7J+pP/+G/qn77cn" +
       "RPUXLm8e7pxWU16xlI4v+2uf/qP/jb8e3Ba+bgrcsFYyWVZkX1+WDN/ooo\n" +
       "qccvhcHHnht/3t1f+banyHvnJvKeWfYm5p56iL5/pj73X3sWZv1B3Ovbe317" +
       "5dwu7ujKJ90aZOcO\ndiF87/L8ricYeC0rgsY638WDu/2d+/iiu987Nlauat" +
       "dLLh7iY5e34+eWetC3M5M7Ly71584Pohq8\nYqf2ufull/F4u29f7Nv63F7k" +
       "MX2JuOf+R72kr4vrtSCzJv0S1YtFEPduv3l8L/31z/3c7/2j35E+\nefuZy/" +
       "uLL9r8M3OuLvDL2Q6zU7/CF77VChfqXwG+8M0fkn7bvnJbbz/vs+mkjv9j+8" +
       "ved//ZH/sP\nL3H3rwTPHfH58eB0q9fM3fHD0cPR+f/Vi0fxSj/uB4l1uZ6/" +
       "uzfl8hJW9WfzmUPkvH/tYbQ+supv\nwPf7++lar29dzPeMyIdXAchLFu83/W" +
       "1PyYS0j1K+9rt/7df+6hf/Xb8BbnC3OaO73+kzvFb1OYz7\n4W9+4903v/7v" +
       "v3ax0V5h7/6b+7/wr89ct+eH2Ic4Z+nktC4cT7DKapm6QR+RuU8EZLIrd8D1" +
       "92CU\nvlS46v4fLJCSJa9/gmpR46kK+XqNZnipbIKpRE33O5ncxemsDSESOp" +
       "GbgIJieUPNAahwGxvlExt0\niHFR2sNVRKsgS0+gQ8pHhcHzbBoUmoqtMy3H" +
       "tRUkF9uD0oxV0p8rE0IS5z6hJL7t4CDarLC5Ym/t\nemz740QX6+Ha87xxB9" +
       "ugBGzIaHSoJJdtNlCp8trkCEWyDSkbl8tZvuF2q7abn6ZeXSf6eHGyAGAs\n" +
       "b1BaYwNzGoNGGg9Ldc7wAatT5Ioy0Ixz4hU9iiJlP5dY3hxxvGxwB8q2VpTO" +
       "tWuZpXJlYrIqNNqd\nCo3UVvLMDsx0LM2jZDN0VbI4zTVCtGN6OmMtSisNLl" +
       "oy0nFfljMlqarkgB2a5OjO0UxoFxFdZ0Jg\nHOXtSVJ3LTyhmD1Hj5ncMsZD" +
       "7sSORuqKydr9yp3PV3QsZRRJaRoJZBC/BaLlTGYqFcstjCVP7VEN\ngUJbLo" +
       "nCUVnKCPmWlyPJMtNp6pNDe0LQqKFAhTXV5002kkoDDfdFW/lziOYJlSytkR" +
       "4y4TwsgL3G\n5kdnF4qIURkg1JLkTE2Dzdx3Kxu1HHq4pShtX5sR6+o6vFRH" +
       "vKsuUlLjmcTcm2J7lEgm3U51mkJU\ngInX4WmH6ysNmWpkmO/y5XFZGeI+U3" +
       "bR0saGShlB4h6ep1ugDnREmgWCSMkFn4h4sOGLjtV1Wc8L\nKaJ3qxMFKjPF" +
       "g4pRJc6mLHVkVsSRNJc4Ji+00PeGoD8KSdikZlmwBkhNNWeL0wQMFQsiUr8o" +
       "wwO2\nkgoqn5xI0Ge70LIJCR+hknSUGgaWFLQ92gXqLNYZYVZDOPR9ChUoN2" +
       "JTPmEn8TZNOEXWrBnjBwCJ\nsrmWrvFYRzbLEEO1sA3UZs+4miGOkWTOcLjm" +
       "8CxOLlh8Ww0ZeWGSDMayctr5FObT5I5cnUSiCagZ\nI0MKSiqaUQteBaKI4z" +
       "VtjjmM7ZZHFybDBFqGuw0p577FnxZbdYhMMQxsoNVcwQFZxze6UPdYOnAm\n" +
       "l3KOFCKzY9wWTLsLpP2MOR2q8uAL5mh1Wk69Y28Uyz3ZiZoTk1JuI8PO4U7J" +
       "2FjOAp6wRJQvc7gm\ntj4+FRIm7/bQrtM3Y0Rl7Alj6r3puT625fXQseglAJ" +
       "3WpNIwdL5vRwYg7IYGvNRFvTvmx9VUrcgZ\nqYZgCBq8ZUbzLWqkE0lCPHNL" +
       "QHS4J/lNsMk6nta4GBBCsokzdIvSObtDDpC0MIYQJoGxsxyzeytN\n1VMXLK" +
       "jRuphxQEzoG7VdHvYxhqeYyBGnQyzMfQvqrWQbUsdsPaO5imhrWatHGEDVG2" +
       "o4O2o148/4\nhY2tsQntZXDaiiYl8Vq4xgggbDdZrHMcTvOoPjJ5qltGxjqI" +
       "ItDM26MWTbcneN6dtB4prTOcl2yK\nkusVvNUlnyv4jigTYWlzCpGPhUWTjN" +
       "hTtwMmm22N8ksNVpkNMoEPjG6nkLydgfgICFZwhxnOwbaG\nQUyXHLvED5ua" +
       "lA2Mo+WlZeVZDR+wbt4S9upwYFg3Ly2H3a3wxRLdu7nbHasxKZzI8cmKECMF" +
       "YmSz\nOu7bYTPmS3oDk1x63BB6Z/JaM8PHebELNqzUa5HswmVjbdbsfrEohY" +
       "meMhlV7TjBWCmRSs3KVYWZ\nMzWk0jGMDG21xb1qjABjhxAba8bOACildic1" +
       "q7WpKdMA2roWOU/iyNiP+XUWt0dmisxoaQZwK4Or\nmu441cQGXZqhOSw7YU" +
       "TYeNwsdrEcAdtUyFNZTsXUM+G9ekQpVFmNTsQkkq3QnYb8tFwnddOH5SNb\n" +
       "i5MWPmmq0uW0JR1SZJiOorkKltHSaPE9p3slw+CGuijk1s2CVJ039YFHa9p0" +
       "ZKRVDHlezzjyCC6m\nOL0tdYIddzspUkbiXlgZ1nCbSqoc08A0FgOxSwFxFo" +
       "SjHngcioUnJ6aSpi3gFMwJFB/PtqN1YjDS\njqRsxZ8W5b4xShaDR4cS7oiq" +
       "HZ4UL+36o/LErN3taXFXY6NxVm9RU4MX9awTZ5PVNNA1GMn2oCKX\nOSTTu2" +
       "CHs/TUnc5oUGS3grjbas0mIIaQc9yLpIvuYpSmN7pJqZXGoE7ZczLGsY8UXr" +
       "vegWiI4Svc\nShp/zI3H46ja8UvAn8w7Zr5f6s1hc6ybmT5co71N7janhYNv" +
       "8vII7bIuxip8NjdtzwhQpqUOogcD\nkMltGMWa5CaPNGgRuiwKdEhyyPgZUn" +
       "Xkhl1USL9NLmDw47HbdMyOs1SaceZgwOMWoGwW85MZQm7m\nTuzDWmc1BfIE" +
       "KJtMtuvIMPksyvKjwsM7qwxVSBUJDB7GHr7quIyAZSjlxOi0Ub06GJGjRF22" +
       "9H4C\nUKFr7XNAgwuMAXGb5Nf8LNSm2HxUJkc2LplcVRBryYpHOx/OgZIwm2" +
       "VJbcVg54gLuzkdO3c2tyg9\naqeK5aL+dNzMvbCzpElR4w4Ne/Vovk4chbZU" +
       "pwCbBM224PqYC+KQrgBXggzWigxvK9spaE89VVT0\nE4oYLoh1nqwYUphFkh" +
       "qMKDOA5E0cilYx3hCwpqo4SBKqAkfk0kE0cxhPu0SejiNlFsPAWJJ0kAlE\n" +
       "fwl2zio01m5VFImCmRWZqOV0kXQHNp1ZdrESs2PBcOtqhM+C5bJlGNOc6EPb" +
       "jFBwEaI7tNquA1Rg\nD13qMR5VT2fpqFi5KyvjZHmPTfF2ArLWRPRwHJ+bie" +
       "ZOIc+MLV2dIM78hO8h2Rs2siVWfQQkdlGB\nN6iwTkF65q0bYmWVhRWN8BqY" +
       "KUR/q04IjB156HYiUIIaqBo5J+qyYUeLzp44ExTuw6hhIcUIbzC2\nlMNaTB" +
       "2WY8WfuKfa9whNhJEiF3dp3c2igwUX1AneZUaVo7aVNhURsls/XFWKKMRd3j" +
       "ILORmGWp1H\n1tom9ibELHJrUurLQF9gogaWjJkB5gmPF+le6rYktVqK48IB" +
       "o2IxAa22QV1iLZiGq8dTjkrywB92\nFoDVegu3zr6cdP0GFSYY2bbL9xpB5e" +
       "wILH1uUZDzcbswTyCImQyQiNxkjYAHaEWtMrxIzEgSUIgV\nemaAooScyq8a" +
       "JktU3E7MwN/4Uh9fHaYZtEWcaWjx/KQ+FWGyRhFECdpiHws7SOS3vMgs8c2o" +
       "OOG1\nJHL8aNifMZAgB5EbM7wZ0EttRCXzhb2uoURHfIM03SSY5FADFglcby" +
       "eHuWge0DYT05QPY0/njlYh\nVNCYcP1IHnazNkrFmZeTwnblHAQJBNzc0YC2" +
       "JdYNlcjmcaGbO2a8ngB2QvPxIliPx4BRudURFmFQ\nqVEcwDlnkY3X2XDNGM" +
       "phzAEbJc/IqZsZJ5fMdbDAUqARBEQx5WizqmeVlfHCkmjAhe7HY7lc5f50\n" +
       "VaWrGdSHrW2r+BVVVkNe0PxAMhfpsZ02gmtxuDTiJ2nRBicM6acWWIuiGTVP" +
       "BFk6gE5+RMYxVDpF\njDt+rOsB4RDGdGUfZA8/DlufEhPAl0csPgqU0Kprni" +
       "4sggCySuGKdLRn+Bl9MHYpT9NiRZTLbldF\nY0mYLy01oxsyRAFTdyEcQgps" +
       "WO62zkTSN3sg3joqllahD1Y1WOsaYrpYFTbTcTKBdGXEgLRnNpkp\nVNoKnY" +
       "3hEdbBR0xTMzuJgXjakItgKMCK7fHgRq59DqC3vqjPC8s9nKpNxPglkpcdlC" +
       "6VOQIRdLWE\nG55V8LmH70RgtyXE3s2HY2eU+2bl2p447JF3yGGQwKMIni7X" +
       "aNVSJkaVo01shF2x4qnZko/Hi6bq\nIgGhWMRUg6nKARKZzhMmcOKizHANhM" +
       "Xpes0PywSc6JN1mUhNtRbLcp9gFIqsESCbLsQt001Qxi9M\nRAf0DckmrhPY" +
       "FYRw09bxu5ZAVV3fx954lBoqPB8N8fUiXsGUfgTbLcRSpwjONRvALBzXY2FT" +
       "zxqR\nkJbLaaPCU3e+wZy2/8YrIQDyoaqCVWhRjLY2mqg6N07DIdxJR1+J/c" +
       "VuofAsCru0PIGTypo5cB8p\nQBsV2wM0OWmny3xW7gk6Xcdx0SWmnfJKDueL" +
       "ySg7BHYUYY63H+bIJukwldqTssZCohrCm8mG0Rd7\nH6K1mFTGDb8bG1st8D" +
       "v2uM/B2dHrisT1Gm6PTFZ6e4CKZJEUCQBXq2FaNgkWcmsmYth4ufOCPYR5\n" +
       "/qRYIkcsxUrXnM4KojoRR8yQIodJVwdQ0GmLPuFy0o05euojzgLrPwN9OhpK" +
       "fVicOBywXxIUvnNU\nXqUpoe4Ke92SY8WFCWdijSYteNLMVKGPrkxisahrDo" +
       "nYM/VQzdDtqcGjHSIifjlU0rm2BrjKcHxz\nNQky2IHlipBbWNygqwZJj9S6" +
       "U9XQQ1crzxdjjjvy0NE4tKG3PJLRPlz00UmwAyoFWrtDCIkkyZwT\nJ6Xrob" +
       "9x4FMljXdmwZBGqZ0ENjNIJ9adZD5BJkbrIhMwgRdUYzaQtg8ID4EzrDNs/R" +
       "gsOHc4tc01\n5ppc4BOLpu58fHYEO2tBtd1pYkn7tQBhUOIfqklW4rPVfqy5" +
       "OCc0WzfkVaDDUz4+JQBxXAXgmNWG\n21iz9kRoUv3HgibNjZ1I4UtYJhZd3C" +
       "F+ihK93pdL04zbqbbDFAkhAyfaQ/sDaSz2+xAwtssDkuKa\nm4XqcLuWYV/1" +
       "FQOHaTCBCi+PhNGo7lYMXNUChxgCk+flil6ZvO2eEEZrRr43Bwskgap5DW6p" +
       "nZEQ\nLLvVbHU9HENqzrCQno+6OF5u4c0iiinlGJhQCG1LZNKK9aGP6aaWtw" +
       "ZnjBAAQIbKEFj4C9iHFcOs\nUjA1+q8H1E32w07QXbGb1+sJW876wL4xCpJA" +
       "IHgHJBhWW9s+LJnLXTFRaxyKMMLFigRnJJhxcv+Y\nT2tvlhDeclJkUR+hDM" +
       "Vxqzcg32t7lyCS4I9GgbMG1l0aAL07MhksagD/SK6abrqkgnOm50uXDOKj\n" +
       "x0mk+5cU15OC2+Pii3rJFZ1ezJVd558HT/PP3349UAze/eOKYZfM3lf1/3bv" +
       "h61f+fI5oXWeyFeD\nN6o0+57Ia7zoaeL6JpPlpfZ3nc39mVffdu8I+GdvZq" +
       "7v9Mt//lvOfORUv/Tov//G5Dc/uH0zDTws\nvKrug7LnksHvPMmunvnj5+z4" +
       "uT2TXX1SZ0jOD/ulmfnbF+luP8ncfulbJ/Crwd1zyer9p7m6+IkY\nb/btM4" +
       "//vvkyMerz4/1vyf9PWPy1ok7O67+QP2zSwL0hzjlvPe+beG4vE+cvXDLXfx" +
       "px7uW1V57L\njn38E5UvFlsvNZOr3PT3/9fPWP84/bG3bl/S+rZVXmnyZpX6" +
       "xSL0c7Xli/BvPLdF4iVbfJLX3zyW\nL8uyG6fzet/uPy1tHi+mMPOcSEk5q+" +
       "kvjeqR8/Cc8n3wgXNdwtpdl7A+/F5oPP7eB3ltlUFep5X3\nwePKwoOzHh70" +
       "Rvp+kATVBx8++MqD7/MaK/rgOon/FSu2f/DBlx7AH370ZfnBD374TDHsa39q" +
       "dbx+\nvfB56AdOj8urj7f+fDr8qkBz+v8+3V+G2SAAAA==");
}
