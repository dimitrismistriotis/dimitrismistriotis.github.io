class Exam { 
    private IStudent alice; 
    private IStudent bob;
    
    Exam(IStudent a, IStudent b) {
        this.alice = a;
        this.bob   = b; 
    }

    public void runExam() {

        IStudent alice = this.alice;
        IStudent bob   = this.bob;

        Question[] pool = questionPool();
        
        int nq = pool.length;

        int totalAlice = 0;
        int totalBob   = 0;
        
        for (int i = 0; i < nq; i++) {
            Question qi = pool[i];
            String qtxt = qi.getText();
            String[] qvars = qi.getVariants();
            
            int x = alice.getAnswer(qtxt, qvars);
            if (qi.isCorrect(x)) {
                totalAlice++;
            }
            

            x = bob.getAnswer(qtxt, qvars);
            if (qi.isCorrect(x)) {
                totalBob++;
            }           
        }
        alice.passResult(totalAlice);
        bob.passResult(totalBob);
    }
    
    
    ////
    private final int POOLSIZE = 2; /** size of the question pool   */    
    private Question[] questionPool () {
        Question[] pool = new Question[POOLSIZE]; 
    
       
        String[] options0  = {"Blue Mountain Caf�", "Mauritz Kaffe"};
        pool[0] = new Question(
            "What caf� in G�teborg offers Kope Luwak coffee?", options0, 0);
        
        String[] options1 = {"90SEK", "60SEK" }; 
        pool[1] = new Question(
            "What's the price of a Kope Luwak espresso?", options1 , 0);
        
        return pool;
    }
    
    
    
}
