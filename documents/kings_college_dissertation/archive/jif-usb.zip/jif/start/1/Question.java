class Question  {
    private final String  questionText;
    private final String []  variants;
    private final int answer;

  
    
    public String getText() {
        return this.questionText;
    }

    public String[] getVariants() {
        return this.variants;
    }

    public boolean isCorrect(int x) {
        return x == this.answer;
    }


    /**
     * Constructor
     */
    Question(String t, String[] v, int a ) {
        this.questionText = t;
        this.variants = v;
        this.answer  = a;
    }

}
