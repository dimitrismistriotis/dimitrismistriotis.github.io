interface  IStudent {
    int getAnswer(String txt, String[] variants);
    void passResult(int x);
    void tellResult();
}
