class ExamRoom {
    private IStudent alice;
    private IStudent bob;
    private Exam exm;

    ExamRoom() {
        this.alice = new Student("Alice");
        this.bob = new Student("Bob");
        this.exm = new Exam(alice, bob);
    }

    public void startExam() {
        this.exm.runExam();
    }

    public static ExamRoom room;
    public final static void main(String args[]) {
        System.out.println("Starting exam");

        ExamRoom rm = new ExamRoom();
        ExamRoom.room = rm;
        rm.startExam();

        System.out.println("exam finished");

        IStudent a = rm.alice;
        IStudent b = rm.bob;

        a.tellResult();
        b.tellResult();

        System.out.println("done.");
    }
}
