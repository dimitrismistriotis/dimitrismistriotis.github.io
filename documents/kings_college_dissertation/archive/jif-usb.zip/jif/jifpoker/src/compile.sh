$JIF/bin/jifc -d ../bin -classpath $JIF/tests $1 $2 $3 $4 $5 $6 $7 $8 $9
cp binder.py ../bin
cp start.sh ../bin
