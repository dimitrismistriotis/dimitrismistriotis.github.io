To compile the program: 
1. Create a new Jif project in Eclipse. 
2. Copy the src/*.jif files from the tarball to src folder of the new project. 
3. Disable integrity checking in the Jif compiler. 
   In the project properties, under Jif project properties > Error report properties, enter    
   '-nointegrity' (without quotes) next to Additional args to jifc. 

To run the program:
1. Change to the directory where Jif outputs the .class files (default workspace/PROJECT/bin)
2. Run jif -classpath . ExamRoom

The output should appear like the following:
$ jif -classpath . ExamRoom
Starting exam
exam finished
Student Alice has got 2 points
Student Bob has got 2 points
done.

